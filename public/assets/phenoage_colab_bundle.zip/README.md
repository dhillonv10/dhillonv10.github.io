# Colab bundle: reproduce the PhenoAge weight edit

Contents
- `PhenoAge_reproduce.ipynb`: the notebook (GPU runtime, about 10-15 min).
- `phenoage_eval.py`: all logic. It is identical to the sandbox scorer: same chat template, greedy decoding, 6 new tokens,
  first number parsed, unparsable -> 45. It also runs the 165-probe side-effect rule and computes paired bootstrap CIs.
- `data/`: dev (400) and held-out (2,823) prompts with gold PhenoAge, the 165 side-effect probes (built with the same code
  as the sandbox), per-person baseline predictions (copy-age, gradient boosting on 750), and the original model's fingerprint.
- `delta/`: the accepted edit E3 (snapshot 1108-125512_evaluate3). It holds the exact sparse weight change accepted in the sandbox
  (`weight_delta_vs_unedited.pt`) and its sha256 (`DELTA_SHA256.txt`).
- `official/`: the supervisor's official CPU held-out predictions and results. These are the supervisor's official CPU predictions; the notebook reports how often
  the GPU answers agree with them.
- `recipe/`: The agents' instruction-set library (`isa/`), `phenoage_program.py` and vectors. This is
  the human-readable "template" of the weight changes; the delta is what it produces.

Tested locally (CPU): recipe rebuild gives sha256 96c61417... (bit-exact), side effects max KL 0.358 / 0 clear changes. Not run on Colab.
