"""Reproduce the PhenoAge weight-edit result on any machine (Colab GPU or CPU).

Steps (all in `run`):
  1. load the ORIGINAL insilicomedicine/Qwen3-0.6B-Longevity in fp32 and check its fingerprint
  2. score the side-effect probes on the original model (reference)
  3. apply the exact sparse weight change (weight_delta_vs_unedited.pt from the sandbox snapshot) and check its sha256
  4. score the edited model's OWN answers on dev (400) and held-out (2,823): same chat template, greedy, 6 new tokens,
     first number parsed, unparsable -> 45 (identical to the sandbox scorer)
  5. paired bootstrap CIs vs the pre-registered baselines; side-effect rule on the 165 probes
Results -> results.json. The official numbers are the supervisor's CPU run; GPU numerics can flip rare near-ties, so the
agreement with the official predictions is reported when official_preds_*.json are present.
"""
import json, os, re, time, hashlib
import numpy as np, torch
from transformers import AutoTokenizer, AutoModelForCausalLM

def fingerprint(model):
    h = hashlib.sha256()
    for n, p in sorted(model.named_parameters()):
        h.update(n.encode()); h.update(p.detach().float().cpu().numpy().tobytes())
    return h.hexdigest()

def apply_delta(model, path):
    delta = torch.load(path, map_location="cpu"); P = dict(model.named_parameters()); h = hashlib.sha256(); n = 0
    with torch.no_grad():
        for name in sorted(delta):
            idx, val = delta[name]; t = P[name].data; ix = tuple(idx.long().T.to(t.device))
            t[ix] = val.to(t.dtype).to(t.device)
            h.update(name.encode()); h.update(t[ix].float().cpu().numpy().tobytes()); n += val.numel()
    return dict(tensors=len(delta), weights=n, sha256=h.hexdigest())

@torch.no_grad()
def answers(model, tok, prompts, batch=16, log_every=200):
    tok.padding_side = "left"; tok.pad_token = tok.pad_token or tok.eos_token
    out, t0 = [], time.time()
    for s in range(0, len(prompts), batch):
        enc = tok(prompts[s:s + batch], return_tensors="pt", padding=True).to(model.device)
        o = model.generate(**enc, max_new_tokens=6, do_sample=False, pad_token_id=tok.pad_token_id)
        for j in range(o.shape[0]):
            t = tok.decode(o[j, enc.input_ids.shape[1]:], skip_special_tokens=True); m = re.search(r"\d+(\.\d+)?", t)
            out.append(dict(text=t, pred=float(m.group()) if m else 45.0))
        if (s // batch) % max(1, log_every // batch) == 0: print(f"  {len(out)}/{len(prompts)}  {time.time()-t0:.0f}s", flush=True)
    return out

@torch.no_grad()
def probe_logp(model, tok, prompts):
    return torch.stack([torch.log_softmax(model(**tok(p, return_tensors="pt").to(model.device)).logits[0, -1].float(), -1).cpu() for p in prompts])

def side_effects(ref, lp, mc_gold):
    kl = (ref.exp() * (ref - lp)).sum(-1); ch = (lp.argmax(-1) != ref.argmax(-1)).nonzero().flatten().tolist()
    top2 = ref.topk(2, -1).values; gap = top2[:, 0] - top2[:, 1]
    real = [i for i in ch if float(gap[i]) >= 0.15]; tie = [i for i in ch if float(gap[i]) < 0.15]
    def acc(L): return sum(int(int(torch.argmax(L[i, g[0]])) == g[1]) for i, g in enumerate(mc_gold) if g and g[1] is not None)
    return dict(max_kl=float(kl.max()), mean_kl=float(kl.mean()), real_flips=real, near_tie_flips=tie,
                mc_acc_start=acc(ref), mc_acc_edited=acc(lp), primary_pass=bool(len(real) <= 1 and float(kl.max()) <= 0.5))

def boot(err_a, err_b=None, n=2000, seed=0):
    rng = np.random.default_rng(seed); k = len(err_a); idx = rng.integers(0, k, (n, k))
    d = err_a if err_b is None else err_a - err_b
    s = d[idx].mean(1); return [float(np.percentile(s, 2.5)), float(np.percentile(s, 97.5))]

SURGEON_WS = "/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon"

def rebuild_from_recipe(model, recipe_dir):
    """Re-derive the edit from the agents' recipe: finish.json derive_code installs phenoage_program.py (a composition of
    isa/ calls) from the saved vectors in accepted_E3/vec, on the ORIGINAL weights (CPU). Returns the change footprint
    and its sha256, hashed exactly like the sandbox snapshot."""
    import sys
    recipe_dir = os.path.abspath(recipe_dir)
    P = {n: p for n, p in model.named_parameters()}; S0 = {n: p.detach().clone() for n, p in P.items()}
    code = json.load(open(os.path.join(recipe_dir, "finish.json")))["derive_code"].replace(SURGEON_WS, recipe_dir)
    import glob   # path-only patch: the agent's files hold absolute paths to its workspace; point them at this recipe copy
    for f in [os.path.join(recipe_dir, "phenoage_program.py")] + glob.glob(os.path.join(recipe_dir, "isa", "*.py")):
        src = open(f).read()
        if SURGEON_WS in src: open(f, "w").write(src.replace(SURGEON_WS, recipe_dir))
    sys.path.insert(0, recipe_dir)
    with torch.no_grad():
        exec(code, dict(P=P, torch=torch, np=np, model=model, PARAMS={}))
    h = hashlib.sha256(); n = 0; t = 0
    for name in sorted(P):
        cur = P[name].detach().cpu(); ch = cur != S0[name]
        if ch.any(): h.update(name.encode()); h.update(cur[ch].numpy().tobytes()); n += int(ch.sum()); t += 1
    return dict(tensors=t, weights=n, sha256=h.hexdigest())

def run(bundle=".", model_id="insilicomedicine/Qwen3-0.6B-Longevity", delta=None, recipe=None, splits=("dev", "heldout"), batch=16, limit=None, device=None):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    D = os.path.join(bundle, "data"); R = dict(device=device, model_id=model_id)
    tok = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.float32).to(device).eval()
    fp = json.load(open(os.path.join(D, "base_fingerprint.json")))["sha256"] if os.path.exists(os.path.join(D, "base_fingerprint.json")) else None
    R["base_fingerprint"] = fingerprint(model); R["base_fingerprint_matches"] = (fp == R["base_fingerprint"]) if fp else None
    print("base model fingerprint", R["base_fingerprint"][:16], "matches bundle:", R["base_fingerprint_matches"])
    pr = json.load(open(os.path.join(D, "probes.json")))
    print("probe reference (original model) ..."); ref = probe_logp(model, tok, pr["prompts"])
    exp_path = os.path.join(bundle, "delta", "DELTA_SHA256.txt")
    exp = open(exp_path).read().split()[0] if os.path.exists(exp_path) else None
    if recipe:
        model.cpu(); R["recipe"] = rebuild_from_recipe(model, recipe); model.to(device)
        R["recipe"]["sha256_matches_snapshot"] = (exp == R["recipe"]["sha256"]) if exp else None
        print("rebuilt from recipe:", R["recipe"])
    elif delta:
        R["delta"] = apply_delta(model, delta)
        R["delta"]["sha256_matches_snapshot"] = (exp == R["delta"]["sha256"]) if exp else None
        print("applied delta:", R["delta"])
    base =json.load(open(os.path.join(D, "baseline_preds.json")))
    for s in splits:
        rows = [json.loads(l) for l in open(os.path.join(D, f"prompts_{s}.jsonl"))][:limit]
        print(f"scoring {s} ({len(rows)}) ..."); a = answers(model, tok, [r["prompt"] for r in rows], batch=batch)
        p = np.array([x["pred"] for x in a]); y = np.array([r["gold"] for r in rows]); e = np.abs(p - y)
        g = np.array(base[s]["gbm750"][:len(rows)]); c = np.array(base[s]["copy_age"][:len(rows)])
        R[s] = dict(n=len(rows), mae=float(e.mean()), mae_ci=boot(e), bias=float((p - y).mean()), corr=float(np.corrcoef(p, y)[0, 1]),
                    unparsable=sum(1 for x in a if not re.search(r"\d", x["text"])),
                    vs_gbm750=dict(gbm_mae=float(np.abs(g - y).mean()), diff=float((e - np.abs(g - y)).mean()), ci=boot(e, np.abs(g - y))),
                    vs_copy_age=dict(copy_mae=float(np.abs(c - y).mean()), diff=float((e - np.abs(c - y)).mean())))
        off = os.path.join(bundle, "official", f"preds_{s}.npy")
        if os.path.exists(off):
            o = np.load(off)[:len(rows)]; R[s]["agreement_with_official_cpu_preds"] = float((o == p).mean())
        json.dump(a, open(f"answers_{s}.json", "w"))
        print(json.dumps(R[s], indent=1))
    if delta or recipe:
        print("side-effect probes (edited) ..."); R["side_effects"] = side_effects(ref, probe_logp(model, tok, pr["prompts"]), pr["mc_gold"])
        print(json.dumps(R["side_effects"], indent=1))
    json.dump(R, open("results.json", "w"), indent=1); return R
