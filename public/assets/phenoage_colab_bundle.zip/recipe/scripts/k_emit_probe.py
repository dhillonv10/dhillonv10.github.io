# Analysis only (hook, no weight edit): does a dominant PWL write of the lm_head logit vectors at L13 out, at the last
# position, set the next token to round(z)? Sweeps the amplitude multiplier Emul (relative to |x27| at that position).
import sys, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
W = model.lm_head.weight.detach().double(); gf = model.model.norm.weight.detach().double()
dig = [tok.convert_tokens_to_ids(str(d)) for d in range(10)]; eos = tok.convert_tokens_to_ids('<|im_end|>')
targets = dig + [eos]; C = list(targets)
def solve(C):
    Wc = W[C] * gf[None]; G = Wc @ Wc.T + 1e-6 * torch.eye(len(C), dtype=torch.float64)
    T = torch.zeros(len(C), len(targets), dtype=torch.float64)
    for j in range(len(targets)): T[j, j] = 1.0
    return Wc.T @ torch.linalg.solve(G, T)
for it in range(8):
    U = solve(C); Lg = W @ (gf[:, None] * U); bad = set()
    for j in range(len(targets)):
        col = Lg[:, j].clone(); col[targets[j]] = -1e9
        bad |= {t for t in torch.topk(col, 50).indices.tolist() if Lg[t, j] > 0.05}
    new = [t for t in bad if t not in C]
    if not new: break
    C += new
U = U.numpy().T; un = np.linalg.norm(U, axis=1)
print('active set', len(C), '|u| digits', un[:10].round(4), 'eos', un[10].round(4))
def f(z):
    z = min(max(z, 0.0), 9.0); k = int(np.floor(z)); a = z - k
    return U[k] if k == 9 else (1 - a) * U[k] + a * U[k + 1]
state = {}
def hook(m, i, o):
    if 'add' in state:
        h = o[0] if isinstance(o, tuple) else o
        h[0, -1] += torch.as_tensor(state['add'], dtype=h.dtype)
    return o
cap = {}
def hook27(m, i, o):
    h = o[0] if isinstance(o, tuple) else o; cap['n'] = float(h[0, -1].norm())
h1 = model.model.layers[13].register_forward_hook(hook); h2 = model.model.layers[27].register_forward_hook(hook27)
try:
    for pi in [600, 640, 680, 720]:
        p = FIT_PROMPTS[pi]
        for suffix in ['', '4']:
            ids = tok(p + suffix, return_tensors='pt').input_ids
            state.pop('add', None)
            with torch.no_grad(): model(ids)
            n27 = cap['n']
            for Emul in [1.0, 3.0, 10.0]:
                res = []
                for z in [0.2, 2.6, 4.5, 7.4, 9.0]:
                    state['add'] = Emul * n27 * f(z) / np.median(un[:10])
                    with torch.no_grad(): lg = model(ids).logits[0, -1].double()
                    top = int(lg.argmax()); dl = lg[dig]; srt = torch.sort(dl, descending=True).values
                    res.append('%s(%s,%.1f)' % (z, tok.decode([top]).strip() or repr(tok.decode([top])), float(srt[0] - lg[[t for t in range(len(lg)) if t not in dig][:0] or 0].max()) if False else float(srt[0] - srt[1])))
                print(pi, repr(suffix), 'n27 %.0f Emul %g:' % (n27, Emul), ' '.join(res))
finally:
    h1.remove(); h2.remove()
exec(open(WS + '/scripts/k_cleanup.py').read())
