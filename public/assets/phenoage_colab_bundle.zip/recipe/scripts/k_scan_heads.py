# removal scan: zero o_proj columns of a kv-group (2 q-heads) or single q-head; KL on proxy probes vs reference
import sys, importlib, numpy as np, time, json
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.proxy_probes as PP, isa.runner as RN; importlib.reload(PP); importlib.reload(RN)
R = RN.Runner(model, tok)
probes = PP.build(tok, FIT_PROMPTS)
ref = np.load(WS + '/data/proxy_ref_logp.npy')
sel = list(range(0, 65)) + list(range(65, 105, 3))  # 65 MC/chat + 14 age
LAYS = PARAMS.get('layers', [2, 3])
mode = PARAMS.get('mode', 'group')
out = {}
t0 = time.time()
# cache inputs at the first scanned layer, then advance
hs = []; pes = []
for i in sel:
    ids = R.ids(probes[i][1]); h = R.embed(ids); pe = R.pos(ids.shape[1])
    h, _ = R.run(h, 0, LAYS[0], pe); hs.append(h); pes.append(pe)
curL = LAYS[0]
for L in LAYS:
    for j in range(len(sel)):
        if curL < L: hs[j], _ = R.run(hs[j], curL, L, pes[j])
    curL = L
    W = P[f'model.layers.{L}.self_attn.o_proj.weight']
    units = [(g,) for g in range(8)] if mode == 'group' else [(h,) for h in range(16)]
    for u in units:
        cols = slice(256 * u[0], 256 * u[0] + 256) if mode == 'group' else slice(128 * u[0], 128 * u[0] + 128)
        save = W[:, cols].clone(); W[:, cols] = 0
        lp = np.stack([R.logp_last(R.run(hs[j], L, 28, pes[j])[0]).numpy() for j in range(len(sel))])
        W[:, cols] = save
        kl = RN.kl_rows(ref[sel], lp); fr, fn = RN.flips(ref[sel], lp)
        out[f'{L}_{u[0]}'] = dict(maxkl=float(kl.max()), meankl=float(kl.mean()), kl=kl.round(4).tolist(), real=[sel[k] for k in fr], near=[sel[k] for k in fn])
        print(L, u[0], 'maxKL %.4f mean %.5f real %s near %s' % (kl.max(), kl.mean(), [sel[k] for k in fr], [sel[k] for k in fn]), 't=%.0f' % (time.time() - t0), flush=True)
json.dump(out, open(WS + f'/data/scan_{mode}_{LAYS[0]}_{LAYS[-1]}.json', 'w'))
