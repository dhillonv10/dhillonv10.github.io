# offline: conjunction SVMs at L6 pa for (VF token of item i) AND on-prompt, i = 0..12, plus ANS1 ('\n\n' last prompt token)
import os
os.environ['OMP_NUM_THREADS'] = '2'; os.environ['OPENBLAS_NUM_THREADS'] = '2'
import numpy as np, sys, pickle
from sklearn.svm import LinearSVC
LAY = int(sys.argv[1]) if len(sys.argv) > 1 else 6
d = np.load(f'data/s2L{LAY}_pa{LAY}.npz'); X = d['X'].astype(np.float32); meta = d['meta']
XP = np.load(f'data/s2L{LAY}_probes_pa{LAY}.npy').astype(np.float32)
res = pickle.load(open('data/fit_parse.pkl', 'rb'))
pi, t, tid = meta[:, 0], meta[:, 1], meta[:, 2]
lab = np.full(len(meta), -1)
vfmap = {(p, it['vf']): it['item'] for p in np.unique(pi) for it in res[p]['items']}
for r in range(len(meta)):
    lab[r] = vfmap.get((pi[r], t[r]), -1)
last = np.r_[pi[1:] != pi[:-1], True]   # last token of each prompt = ANS1
lab[last] = 13
keep = t >= 58; X, pi, t, lab = X[keep], pi[keep], t[keep], lab[keep]
tr = pi < 600; te = ~tr; ptr = np.arange(len(XP)) % 3 != 0; pte = ~ptr
sc = 32.0 / np.median(np.linalg.norm(X, axis=1))
out = {}
for k in range(14):
    pos = X[tr & (lab == k)]; neg = np.r_[X[tr & (lab != k)][::2], XP[ptr]]
    clf = LinearSVC(C=0.1, class_weight={1: 20, -1: 1}, max_iter=5000, dual=False)
    clf.fit(np.r_[pos, neg] * sc, np.r_[np.ones(len(pos)), -np.ones(len(neg))])
    w = clf.coef_[0] * sc; b = clf.intercept_[0]
    s_on = X[te & (lab == k)] @ w + b; s_off = X[te & (lab != k)] @ w + b; s_p = XP[pte] @ w + b
    print(k, 'n_pos %d test on-min %.3f | on-prompt off-max %.3f | probes(test) max %.3f | errs %d' % (len(pos), s_on.min(), s_off.max(), s_p.max(), (s_on < 0).sum() + (s_off > 0).sum() + (s_p > 0).sum()), flush=True)
    out[f'w{k}'] = w; out[f'b{k}'] = b
sys.path.insert(0, '.')
from isa.fitk import minvar_read
G = np.load('data/gammas.npz'); g = G['G_po'][LAY]; V1 = np.load('vec/s1.npz')
Mn = np.load('data/nat_moments.npz', mmap_mode='r')['M_pa'][LAY].astype(np.float64)
XPd = XP.astype(np.float64)
rFB = minvar_read(Mn + XPd.T @ XPd / len(XPd), g * V1['eFB'], zero=[g * V1['eF'], g * V1['eA']])
fo = X.astype(np.float64) @ rFB; rFB = rFB / np.median(fo)
print('FB read L%d: on min %.3f p1 %.3f | probes max %.3f' % (LAY, (X @ rFB).min(), np.percentile(X @ rFB, 1), np.abs(XPd @ rFB).max()))
Xs = np.r_[X[::3], XP[::3]].astype(np.float64)
out['c'] = np.linalg.solve(Xs.T @ Xs + 30 * np.eye(1024) * 1e-3, Xs.T @ np.ones(len(Xs)))
out['rFB'] = rFB
np.savez(f'vec/s3_ident_L{LAY}.npz', **out)
