import inspect, transformers
from transformers.models.qwen3 import modeling_qwen3 as M
print(transformers.__version__)
print(inspect.getsource(M.Qwen3DecoderLayer.forward))
print(inspect.getsource(M.Qwen3Attention.forward))
src = inspect.getsource(M.Qwen3Model.forward); print(src[:3000])
print(inspect.getsource(M.Qwen3MLP.forward))
print(inspect.getsource(M.apply_rotary_pos_emb)); print(inspect.getsource(M.rotate_half))
