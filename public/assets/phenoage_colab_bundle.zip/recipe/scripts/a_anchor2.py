import numpy as np
d = np.load('data/flag_coll.npz'); meta = d['meta']
j, t, isph = meta[:, 0], meta[:, 1], meta[:, 2]
nn = j.max() + 1; extra = j >= nn - 12
neg = ~((j == 0) & (t < 70)) & ~((isph == 1) & (t < 58))
X = d['pa3'].astype(np.float64)
Xn = X[neg]; mu = Xn.mean(0); C = np.cov(Xn.T)
for sets in [[49], [39, 49], [39, 40, 41, 44, 49], [39, 40, 44, 49], [40, 41, 44, 49]]:
    pos = np.array([np.where((j == 0) & (t == a))[0][0] for a in sets])
    for lam in [1e-3, 1e-2]:
        Ci = np.linalg.inv(C + lam * np.trace(C) / 1024 * np.eye(1024))
        # least squares in whitened space: fit r so that r.(x_a-mu)=1 for all anchors, min r'Cr
        Dp = X[pos] - mu
        A = Dp @ Ci @ Dp.T; r = Ci @ Dp.T @ np.linalg.solve(A, np.ones(len(sets)))
        s = (X - mu) @ r
        print(sets, lam, 'pos', s[pos].round(3), 'neg max %.3f (non-extra %.3f) sd %.4f' % (s[neg].max(), s[neg & ~extra].max(), s[neg].std()),
              'extras', [round(float(s[(j == k)].max()), 2) for k in range(nn - 12, nn)])
