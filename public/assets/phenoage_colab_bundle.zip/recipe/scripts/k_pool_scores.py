# analysis: pool-head logits at ANS1 over the VF keys (scale, spread, dependence on distance), current vec/s6.npz
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.attnprobe as AP
for m in (CO, AP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='pool')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
L = 12; h = PG.POOL['heads'][0]
qk = AP.QKCapture(model, [L]); rows = []
for pi in range(601, 750, 10):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    q = qk.cap[('q', L)]; k = qk.cap[('k', L)]
    pid = torch.arange(T).unsqueeze(0)
    cos, sin = model.model.rotary_emb(torch.zeros(1, T, 1024), pid); cos, sin = cos[0], sin[0]
    qr = AP.rope(q[:, h], cos, sin); kr = AP.rope(k[:, h // 2], cos, sin)
    s = (kr @ qr[-1] / np.sqrt(128.0)).numpy()
    vfs = [it['vf'] for it in res[pi]['items']]; oth = np.setdiff1d(np.arange(T), vfs)
    sv = s[vfs]; d = T - 1 - np.array(vfs)
    rows.append((sv.mean(), sv.std(), np.corrcoef(d, sv)[0, 1], np.polyfit(d, sv, 1)[0], s[oth].max()))
    # unrotated (position-free) score spread
    s0 = (k[vfs, h // 2] @ q[-1, h] / np.sqrt(128.0)).numpy(); rows[-1] += (s0.std(),)
qk.remove()
R = np.array(rows)
print('VF score mean %.1f | sd %.3f | corr(dist) %.2f slope/token %.5f | max non-VF score %.1f | unrotated sd %.3f' % tuple(R.mean(0)))
exec(open(WS + '/scripts/k_cleanup.py').read())
