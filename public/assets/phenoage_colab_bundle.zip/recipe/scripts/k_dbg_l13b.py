# debug: recover the coefficients of the live L13 kink-0 gate row on [rz13, ri13, c0] of the current s7 file
import sys, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import phenoage_program as PG, isa.core as CO
L, nn = PG.NEUR['emit']; V = PG.load(WS)
for f in ['/vec/s7.npz', '/accepted_E2/vec/s7.npz', '/vec/s7_accepted.npz']:
    d = np.load(WS + f); print(f, {k: float(d[k]) for k in ('emK', 'kapE', 'kapS', 'Escale') if k in d.files}, 'rz13 norm', np.linalg.norm(d['rz13']), 'c0 norm', np.linalg.norm(d['c0']))
g = P[CO.pname(L, 'gate')][nn[0]].double().numpy()
A = np.c_[V['rz13'][0], V['ri13'][0], V['c0']]
co, res, *_ = np.linalg.lstsq(A, g, rcond=None)
print('live kink0 gate = %.3f rz + %.3f ri + %.3f c0 ; resid %.3e of norm %.3e' % (co[0], co[1], co[2], np.linalg.norm(A @ co - g), np.linalg.norm(g)))
