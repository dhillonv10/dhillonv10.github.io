#!/bin/bash
# usage: se_tests.sh script params ... (pairs); runs each install (no se_local) then the server side_effects
cd /tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon
while [ $# -gt 1 ]; do
  echo "== $1 $2"
  timeout 2400 scripts/kpy.sh $1 "$2" ${KPYN:-0} | grep -v "^applied\|^$" || echo "install failed"
  timeout 2400 ../venv/bin/python wsp_cli.py side_effects 2>&1 | tail -1 | cut -c1-230
  shift 2
done
echo SE_TESTS_DONE
