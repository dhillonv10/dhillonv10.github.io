# offline: EMIT reads at L27 pa: answer-position type reads, z1 (tens target) and z2 (units target), CONST
import numpy as np
d = np.load('data/ans_l27.npz'); X = d['X'].astype(np.float64); LAB = d['LAB']; XO = d['XO'].astype(np.float64)
XP = np.load('data/probe_rows.npz')['pa27'].astype(np.float64)
pi, k, y, T, U = LAB[:, 0], LAB[:, 1].astype(int), LAB[:, 2], LAB[:, 3], LAB[:, 4]
tr = (pi < 600) | (pi >= 1100); te = ~tr
nO = len(XO); trO = np.arange(nO) % 4 != 0; trP = np.arange(len(XP)) % 4 != 0
Xall = np.r_[X[tr], XO[trO], XP[trP]]
A = Xall.T @ Xall; A += 1e-5 * np.trace(A) / 1024 * np.eye(1024)
def fitcls(target_rows):
    t = np.r_[target_rows[tr], np.zeros(trO.sum() + trP.sum())]; return np.linalg.solve(A, Xall.T @ t)
out = {}
for j, nm in enumerate(['isA1', 'isA2', 'isA3']):
    w = fitcls((k == j).astype(float)); s = X[te] @ w
    print('%s: on-min %.3f | other answer pos max %.3f | other tokens max %.3f | probes max %.3f' % (nm, s[k[te] == j].min(), s[k[te] != j].max(), (XO @ w).max(), (XP @ w).max()))
    out[nm] = w
for j, nm, tgt in [(0, 'z1', (y + 0.5) / 10 - 0.5), (1, 'z2', y - 10 * T)]:
    m = k == j
    Aj = X[m & tr].T @ X[m & tr]; Aj += 1e-6 * np.trace(Aj) / 1024 * np.eye(1024)
    w = np.linalg.solve(Aj, X[m & tr].T @ tgt[m & tr]); e = X[m & te] @ w - tgt[m & te]
    scale = 10 if j == 0 else 1
    print('%s: test err sd %.4f max %.3f (years: sd %.3f)' % (nm, e.std(), np.abs(e).max(), e.std() * scale))
    out[nm] = w
    # emitted digit accuracy (ignoring the other digit)
    pred = np.clip(np.round(X[m & te] @ w), 0, 9); truth = np.clip(np.round(tgt[m & te]), 0, 9)
    print('   digit mismatch rate %.4f' % (pred != truth).mean())
c = np.linalg.solve(Xall.T @ Xall + 1e-3 * np.trace(Xall.T @ Xall) / 1024 * np.eye(1024), Xall.T @ np.ones(len(Xall)))
print('CONST sd: answer %.4f other %.4f probes %.4f' % ((X @ c).std(), (XO @ c).std(), (XP @ c).std()))
out['c27'] = c
np.savez('vec/s7_fit.npz', **out)
