# dump the L12 pool-group weights needed for the offline channel choice (no edit)
import numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
L = 12; h = 0; g = 0
np.savez(WS + '/data/pool_w.npz', Wv=P[f'model.layers.{L}.self_attn.v_proj.weight'][128 * g:128 * g + 128].double().numpy().copy(),
         Wo=P[f'model.layers.{L}.self_attn.o_proj.weight'][:, 256 * g:256 * g + 256].double().numpy().copy(),
         g12=P[f'model.layers.{L}.input_layernorm.weight'].double().numpy().copy())
print('dumped')
