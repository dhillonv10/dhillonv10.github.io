# collect xhat at L27 pa for ANS1/ANS2/ANS3 (prompt + true tens + true units appended) and other tokens; practice + synthetic
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS['upto'])
L = PARAMS.get('L', 27)
pool = PR.item_value_pool(FIT_PROMPTS[:600]); rng = np.random.default_rng(PARAMS.get('seed', 5))
plist = []
for pi in range(PARAMS.get('p0', 0), 750, PARAMS.get('step', 2)):
    items = {PR.ITEM_NAMES[i]: v for i, v in [(it, float(vs)) for it, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])]}
    plist.append((pi, FIT_PROMPTS[pi], PR.phenoage(items)))
for j in range(PARAMS.get('nsynth', 0)):
    sp, y, _ = PR.synth(FIT_PROMPTS[int(rng.integers(0, 600))], pool, rng); plist.append((1000 + j, sp, y))
cap = FK.Capture(model, [('pa', L)])
X, LAB, XO = [], [], []
for pi, prm, y in plist:
    yi = int(np.clip(np.floor(y + 0.5), 0, 99)); T, U = yi // 10, yi % 10
    ids = tok(prm + f'{T}{U}', return_tensors='pt').input_ids
    cap.run(ids); XH = cap[('pa', L)]
    for k, pos in enumerate((-3, -2, -1)):
        X.append(XH[pos].astype(np.float32)); LAB.append([pi, k, y, T, U])
    sel = rng.choice(np.arange(58, ids.shape[1] - 3), size=6, replace=False)
    for t in sel: XO.append(XH[t].astype(np.float32))
    del XH
cap.remove()
np.savez(WS + f'/data/ans_{PARAMS["tag"]}.npz', X=np.stack(X), LAB=np.array(LAB), XO=np.stack(XO))
print(len(X))
exec(open(WS + '/scripts/k_cleanup.py').read())
