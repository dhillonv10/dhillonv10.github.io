# dump read grams (gamma-weighted, raw coordinates) of every reader at layers L0..27 + lm_head, per layer (sum of
# trace-normalised q/k/v and gate/up grams), for choosing write directions that later layers barely read. No edit.
import numpy as np, torch
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
L0 = PARAMS.get('L0', 12); out = {}
with torch.no_grad():
    for L in range(L0, 28):
        gi = P[f'model.layers.{L}.input_layernorm.weight'].double(); gp = P[f'model.layers.{L}.post_attention_layernorm.weight'].double()
        G = torch.zeros(1024, 1024, dtype=torch.float64)
        for mod, g in [('self_attn.q_proj', gi), ('self_attn.k_proj', gi), ('self_attn.v_proj', gi), ('mlp.gate_proj', gp), ('mlp.up_proj', gp)]:
            W = P[f'model.layers.{L}.{mod}.weight'].double() * g[None]
            M = W.T @ W; G += M / torch.trace(M); del W, M
        out[f'L{L}'] = G.float().numpy().copy()
    W = model.lm_head.weight.detach().double() * model.model.norm.weight.detach().double()[None]
    M = W.T @ W; out['lm'] = (M / torch.trace(M)).float().numpy().copy(); del W, M
np.savez(WS + '/data/read_grams.npz', **out); print('saved', len(out))
