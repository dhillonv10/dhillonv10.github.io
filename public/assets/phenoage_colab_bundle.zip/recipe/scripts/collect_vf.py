# collect xhat at VF tokens (and ANS1) for all practice prompts at a hook point, with item / per-offset token labels
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK
for m in (CO, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS['upto'])
side, L = PARAMS['side'], PARAMS['L']
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = {**{15 + d: d for d in range(10)}, 220: 10, 13: 11}
cap = FK.Capture(model, [(side, L)])
import isa.prompts as PR; importlib.reload(PR)
X, lab, ANS, YS = [], [], [], []
plist = [(pi, FIT_PROMPTS[pi], None) for pi in range(0, 750, PARAMS.get('step', 1))]
if PARAMS.get('nsynth', 0):
    pool = PR.item_value_pool(FIT_PROMPTS[:600]); rng = np.random.default_rng(PARAMS.get('seed', 0))
    for j in range(PARAMS['nsynth']):
        base = int(rng.integers(0, 600)); sp, y, _ = PR.synth(FIT_PROMPTS[base], pool, rng)
        plist.append((1000 + j, sp, PR.parse(sp, tok)))
for pi, prm, pr in plist:
    ids = tok(prm, return_tensors='pt').input_ids; cap.run(ids); XH = cap[(side, L)]
    items = (res[pi] if pr is None else pr)['items']
    for it in items:
        vf = it['vf']; offs = [tokk.get(int(ids[0, vf - k]), 12) for k in (1, 2, 3, 4, 5, 6)]
        X.append(XH[vf].astype(np.float32)); lab.append([pi, it['item']] + offs)
    ANS.append(XH[-1].astype(np.float32))
cap.remove()
np.savez(WS + f'/data/vf_{PARAMS["tag"]}.npz', X=np.stack(X), lab=np.array(lab), ANS=np.stack(ANS), prompts=np.array([q for _, q, _ in plist], dtype=object))
print(len(X))
exec(open(WS + '/scripts/k_cleanup.py').read())
