#!/bin/bash
set -e
set -o pipefail
cd /tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon
PY=../venv/bin/python
SY=${SY:-0.3}
scripts/kpy.sh scripts/derive_s6c.py "{\"ncut\":10,\"kmul\":30,\"qmul\":30,\"p0\":52,\"nsynth\":100,\"step\":3,\"Lr\":12,\"rYmode\":\"plain\",\"sY\":$SY}" 6
echo "== SE up to pool (sY $SY)"; timeout 2400 $PY wsp_cli.py side_effects 2>&1 | tail -1 | cut -c1-230
$PY scripts/o_s7d.py 1e-4 12
$PY scripts/o_s7e.py ${AZ:-200}
scripts/kpy.sh scripts/derive_s7e.py "{\"Emul\":15.0,\"step\":2,\"emK\":250,\"kapE\":50}" 30
echo "== SE full"; timeout 2400 $PY wsp_cli.py side_effects 2>&1 | tail -1 | cut -c1-230
echo CHAIN_V11_DONE
