# dump gamma-weighted W_v of L10/L11 (for offline direction design; no edit)
import numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
out = {}
for L in (10, 11):
    g = P[f'model.layers.{L}.input_layernorm.weight'].double().numpy()
    out[f'v{L}'] = (P[f'model.layers.{L}.self_attn.v_proj.weight'].double().numpy() * g[None]).astype(np.float32).copy()
np.savez(WS + '/data/wv_10_11.npz', **out); print('dumped')
