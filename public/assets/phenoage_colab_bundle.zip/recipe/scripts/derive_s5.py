# S5: BITS (L9 MLP) + AFFINE (L10 MLP). Part A fits/installs bits; Part B collects pa10 VF rows (practice+synthetic),
# fits value/item reads and installs the item GATED_LINEAR pairs + CRP kinks. Saves vec/s5.npz.
import sys, importlib, numpy as np, pickle, math
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.se as SE, isa.prompts as PR, isa.quiet as QU
for m in (CO, FK, SE, PR, QU): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = {**{15 + d: d for d in range(10)}, 220: 10, 13: 11}
reg = CO.Registry(P); PG.install(reg, V, upto='shift')
B = np.load(WS + '/vec/s5_bits_fit.npz')
keys = [(k, b) for k in (2, 4, 5, 6) for b in range(4) if f'w{k}_{b}' in B.files]
print('bits', keys)
_NM = np.load(WS + '/data/nat_moments.npz')['M_pa']
Mpa = lambda L: _NM[L].astype(np.float64)

def sample_states(L, n=12):
    cap = FK.Capture(model, [('pa', L)]); VF, DG, OTH, X0 = [], [], [], None
    for pi in range(0, 600, 600 // n):
        ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); XH = cap[('pa', L)]; X0 = XH[0]
        vfs = [it['vf'] for it in res[pi]['items']]
        VF.append(XH[vfs]); DG.append(XH[[t for t in range(58, ids.shape[1]) if int(ids[0, t]) in tokk]])
        OTH.append(XH[[t for t in range(58, ids.shape[1]) if int(ids[0, t]) not in tokk and t not in vfs]])
    cap.remove()
    return np.concatenate(VF), np.concatenate(DG), np.concatenate(OTH), X0

VF9, DG9, OT9, X09 = sample_states(9)
vf9 = FK.minvar_read(Mpa(9) + FK.second_moment(OT9[::5]), VF9.mean(0), zero=[DG9.mean(0), X09])
print('vf9 on VF min %.3f | digit pins max %.3f | other on-prompt max %.3f' % ((VF9 @ vf9).min(), np.abs(DG9 @ vf9).max(), np.abs(OT9 @ vf9).max()))
R9 = np.r_[OT9[::3], VF9, DG9[::3]]; c9 = FK.fit_const(R9)
bit_w = np.stack([B[f'w{k}_{b}'] for k, b in keys])
# soft bits on all on-prompt token kinds (to check the AND gate)
for nm, S_ in [('VF', VF9), ('digit pins', DG9), ('other', OT9)]:
    z = S_ @ bit_w.T + 2 * (S_ @ vf9)[:, None] - 2.5 * (S_ @ c9)[:, None]
    print('bits gate z on %s: max %.3f' % (nm, z.max()))
X0s = np.load(WS + '/data/pos0_states.npy')
prev = [V['eA'], V['eF'], V['eFB'], V['eP'], V['eV'], V['eANS']] + list(V['pin_e']) + list(V['u_items'])
bit_e, _ = QU.quiet_dirs(range(10, 13), len(keys) + 1, exclude=[X0s[L] for L in range(9, 13)] + prev)
bit_e = bit_e[:-1]
# eY: direction with the largest gain through the POOL head's OV (L11 head 0, group 0), orthogonal to every code dir
Lp, hp = PG.POOL['L'], PG.POOL['heads'][0]
gp = P[f'model.layers.{Lp}.input_layernorm.weight'].double().numpy()
OV = P[f'model.layers.{Lp}.self_attn.o_proj.weight'].double().numpy()[:, 128 * hp:128 * hp + 128] @ P[f'model.layers.{Lp}.self_attn.v_proj.weight'].double().numpy()[128 * (hp // 2):128 * (hp // 2) + 128] * gp[None]
Ex = np.linalg.qr(np.array(prev + list(bit_e)).T)[0]
_, sv, Vt = np.linalg.svd(OV @ (np.eye(1024) - Ex @ Ex.T), full_matrices=False)
eY = Vt[0]; print('eY pool OV gain %.3f' % sv[0])
V5 = dict(bit_w=bit_w, vf9=vf9, c9=c9, bit_e=bit_e, Pb=PARAMS.get('Pb', 60.0), kapB=PARAMS.get('kapB', 100.0), bit_keys=np.array(keys), eY=eY)
V.update(V5)
PG.install_bits(reg, V)
# ---- Part B: pa10 VF rows (practice + synthetic) ----
pool = PR.item_value_pool(FIT_PROMPTS[:600]); rng = np.random.default_rng(7)
plist = [(FIT_PROMPTS[pi], res[pi]) for pi in range(0, 750)]
for j in range(PARAMS.get('nsynth', 500)):
    sp, y, _ = PR.synth(FIT_PROMPTS[int(rng.integers(0, 600))], pool, rng); plist.append((sp, PR.parse(sp, tok)))
cap = FK.Capture(model, [('pa', 10)])
X, LAB = [], []
for j, (prm, pr) in enumerate(plist):
    ids = tok(prm, return_tensors='pt').input_ids; cap.run(ids); XH = cap[('pa', 10)]
    for it in pr['items']:
        vf = it['vf']; offs = [tokk.get(int(ids[0, vf - k]), 12) for k in (1, 2, 4, 5, 6)]
        X.append(XH[vf].astype(np.float32)); LAB.append([j, it['item']] + offs + [it['value']])
cap.remove()
X = np.array(X, dtype=np.float64); LAB = np.array(LAB)
tr = (LAB[:, 0] < 600) | (LAB[:, 0] >= 850); te = ~tr
A = X[tr].T @ X[tr] + 1e-6 * np.trace(X[tr].T @ X[tr]) / 1024 * np.eye(1024)
val_r = {}
for c, k in enumerate((1, 2, 4, 5, 6)):
    y = LAB[:, 2 + c]; v = np.where(y < 10, y, 0).astype(float)
    w = np.linalg.solve(A, X[tr].T @ v[tr]); e = X[te] @ w - v[te]; val_r[k] = w
    print('pa10 value read offset %d: test err sd %.4f max %.4f' % (k, e.std(), np.abs(e).max()))
item_r = []
for i in range(13):
    t = (LAB[:, 1] == i).astype(float); w = np.linalg.solve(A, X[tr].T @ t); s = X[te] @ w
    item_r.append(w); print('item %d read: on-min %.3f off-max %.3f' % (i, s[t[te] == 1].min(), s[t[te] == 0].max()))
item_r = np.stack(item_r)
VF10, DG10, OT10, X010 = sample_states(10)
vf10 = FK.minvar_read(Mpa(10) + FK.second_moment(OT10[::5]), VF10.mean(0), zero=[DG10.mean(0), X010])
c10 = FK.fit_const(np.r_[OT10[::3], VF10, DG10[::3]])
# years per digit at each offset per item
place = {1: -2, 2: -1, 4: 0, 5: 1, 6: 2}
item_up = []; mus = []
Yp = {i: [] for i in range(13)}
for pi in range(600):
    for it in res[pi]['items']: Yp[it['item']].append(PR.item_years(PR.ITEM_NAMES[it['item']], it['value']))
for i in range(13):
    nm = PR.ITEM_NAMES[i]; mu = float(np.mean(Yp[i])); mus.append(mu)
    if nm == 'crp':
        up = (PR.item_years('crp', 0.01) - mu) * c10
    elif nm == 'age':
        up = PR.item_years('age', 1.0) * (val_r[1] + 10 * val_r[2]) - mu * c10
    else:
        ypu = PR.item_years(nm, 1.0)
        up = ypu * sum(10.0 ** place[k] * val_r[k] for k in (1, 2, 4, 5, 6)) - mu * c10
    item_up.append(up)
crp_v = sum(10.0 ** place[k] * val_r[k] for k in (1, 2, 4, 5, 6))
kt = 0.01 * 2.0 ** np.arange(12)
f = lambda v: PR.item_years('crp', v)
slopes = [(f(kt[j + 1]) - f(kt[j])) / (kt[j + 1] - kt[j]) for j in range(11)] + [(f(25.0) - f(kt[11])) / (25.0 - kt[11])]
ks = np.diff(np.r_[0.0, slopes])
V5b = dict(item_r=item_r, item_up=np.stack(item_up), vf10=vf10, c10=c10, mu=np.array(mus), crp_v=crp_v, kink_t=kt, kink_s=ks,
           kapI2=PARAMS.get('kapI2', 100.0), kapK=PARAMS.get('kapK', 3000.0), Bk=PARAMS.get('Bk', 300.0), aY=PARAMS.get('aY', 1.0))
V.update(V5b)
np.savez(WS + '/vec/s5.npz', **V5, **V5b)
# offline-style check of the Y the arithmetic should produce (linear part at pa10)
Yhat = []; Ytrue = []
for r in np.where(te)[0][:2000]:
    i = int(LAB[r, 1]); nm = PR.ITEM_NAMES[i]
    if nm == 'crp': continue
    Yhat.append(X[r] @ item_up[i] / (X[r] @ c10)); Ytrue.append(PR.item_years(nm, LAB[r, -1]) - mus[i])
e = np.array(Yhat) - np.array(Ytrue); print('Y (non-CRP) read error at pa10: sd %.4f yr, max %.3f' % (e.std(), np.abs(e).max()))
PG.install_arith(reg, V)
print(reg.footprint()[1])
exec(open(WS + '/scripts/k_cleanup.py').read())
