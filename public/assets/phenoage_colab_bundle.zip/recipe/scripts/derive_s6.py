# S6: SUM_POOL at L11 (DUAL: q-switch at ANS/digit pins, k-switch at VF pins); checks attention mass at ANS1.
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.attn as AT, isa.attnprobe as AP, isa.prims as PRM
for m in (CO, FK, AT, AP, PRM): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = {**{15 + d: d for d in range(10)}, 220: 10, 13: 11}
reg = CO.Registry(P); PG.install(reg, V, upto='kinks')
L = PG.POOL['L']; h = PG.POOL['heads'][0]; g = h // 2
cap = FK.Capture(model, [('in', L)])
VF, DG, AN, OT, X0 = [], [], [], [], None
for pi in range(0, 600, 40):
    ids = tok(FIT_PROMPTS[pi] + str(pi % 10), return_tensors='pt').input_ids   # appended digit = ANS2 state at the end
    cap.run(ids); XH = cap[('in', L)]; X0 = XH[0]
    vfs = [it['vf'] for it in res[pi]['items']]
    VF.append(XH[vfs]); AN.append(XH[-2:-1].copy()); DG.append(XH[[t for t in range(58, ids.shape[1]) if int(ids[0, t]) in tokk]])
    OT.append(XH[[t for t in range(58, ids.shape[1] - 2) if int(ids[0, t]) not in tokk and t not in vfs]])
cap.remove()
VF, DG, AN, OT = map(np.concatenate, (VF, DG, AN, OT))
Mn = np.load(WS + '/data/nat_moments.npz', mmap_mode='r')['M_in'][L].astype(np.float64) + FK.second_moment(OT[::4])
rq = FK.minvar_read(Mn, AN.mean(0), zero=[X0])
# make rq ~1 on digit pins too: solve with two "on" constraints
C = np.c_[AN.mean(0), DG.mean(0), X0]; Z = np.linalg.solve(Mn + 1e-6 * np.trace(Mn) / 1024 * np.eye(1024), C)
rq = Z @ np.linalg.solve(C.T @ Z, np.array([1.0, 1.0, 0.0]))
Ck = np.c_[VF.mean(0), DG.mean(0), AN.mean(0), X0]; Zk = np.linalg.solve(Mn + 1e-6 * np.trace(Mn) / 1024 * np.eye(1024), Ck)
rk = Zk @ np.linalg.solve(Ck.T @ Zk, np.array([1.0, 0.0, 0.0, 0.0]))
print('rq: ANS %.3f digits min %.3f VF max %.3f other max %.3f | rk: VF min %.3f max %.3f, digits max %.3f, ANS %.3f, other max %.3f' % (
    (AN @ rq).min(), (DG @ rq).min(), np.abs(VF @ rq).max(), np.abs(OT @ rq).max(), (VF @ rk).min(), (VF @ rk).max(), np.abs(DG @ rk).max(), np.abs(AN @ rk).max(), np.abs(OT @ rk).max()))
gq = P[f'model.layers.{L}.self_attn.q_norm.weight'].double().numpy(); gk = P[f'model.layers.{L}.self_attn.k_norm.weight'].double().numpy()
# position-free design: energy only in the slowest planes, q and k aligned
pl = np.arange(44, 64)
kd = np.zeros(128); qd = np.zeros(128)
big = np.abs(gk[:64]) >= np.abs(gk[64:])
for j in pl:
    d = j if big[j] else j + 64
    kd[d] = np.sign(gk[d]); qd[d] = np.sign(gq[d]) * np.abs(gk[d]) / max(np.abs(gq[d]), 1e-3)
curve = AT.score_curve(qd, kd, gq, gk, np.arange(0, 800)); print('pool score vs distance: min %.2f max %.2f' % (curve.min(), curve.max()))
Wq = P[f'model.layers.{L}.self_attn.q_proj.weight'].double().numpy()[128 * h:128 * h + 128]
Wk = P[f'model.layers.{L}.self_attn.k_proj.weight'].double().numpy()[128 * g:128 * g + 128]
qt = qd / np.linalg.norm(qd) * PARAMS.get('qmul', 10.0) * np.median(np.linalg.norm(Wq @ AN.T, axis=0))
kt = kd / np.linalg.norm(kd) * PARAMS.get('kmul', 10.0) * np.median(np.linalg.norm(Wk @ VF.T, axis=0))
V6 = dict(pool_rq=rq, pool_rk=rk, pool_dq=qt - Wq @ np.r_[AN, DG].mean(0), pool_dk=kt - Wk @ VF.mean(0))
V.update(V6)
PG.install_pool(reg, V)
qk = AP.QKCapture(model, [L]); mass = []; ent = []
for pi in range(601, 750, 10):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    Pr = qk.probs(L, T).numpy()[h, -1]
    vfs = [it['vf'] for it in res[pi]['items']]
    mass.append(Pr[vfs].sum()); ent.append(Pr[vfs].std() / Pr[vfs].mean())
qk.remove()
print('pool at ANS1: mass on the 10 VF tokens min %.5f median %.5f | weight cv max %.4f' % (min(mass), np.median(mass), max(ent)))
np.savez(WS + '/vec/s6.npz', **V6)
exec(open(WS + '/scripts/k_cleanup.py').read())
