import numpy as np
d = np.load('data/flag_coll.npz'); meta = d['meta']; j, t, isph = meta[:, 0], meta[:, 1], meta[:, 2]
neg = ~((j == 0) & (t < 70)) & ~((isph == 1) & (t < 58))
X = d['pa3'].astype(np.float64); c = np.load('vec/const_L3pa.npy')
Xa = np.c_[X, X @ c]; Xn = Xa[neg]; mu = Xn.mean(0); C = np.cov(Xn.T) + 1e-3 * np.trace(np.cov(Xn.T)) / 1025 * np.eye(1025); Ci = np.linalg.inv(C)
nn = j.max() + 1; extra = j >= nn - 12
out = {}
for a in [40, 41, 49]:
    pos = np.where((j == 0) & (t == a))[0][0]
    r = Ci @ (Xa[pos] - mu); r /= (Xa[pos] - mu) @ r
    rr = r[:1024]; bb = r[1024] - mu @ r
    s = X @ rr + bb * (X @ c)
    others = s[(j == 0) & (t < 70) & (t != a)]
    print(a, 'pos %.3f neg max %.3f non-extra %.3f, other prefix tokens max %.3f, extras' % (s[pos], s[neg].max(), s[neg & ~extra].max(), others.max()), [round(float(s[j == k].max()), 2) for k in range(nn - 12, nn)])
    out[f'r{a}'] = rr; out[f'b{a}'] = bb
np.savez('vec/anchor_dets.npz', **out)
