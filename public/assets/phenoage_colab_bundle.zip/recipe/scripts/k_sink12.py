# analysis: natural attention mass on position 0 per head at L12 over proxy-probe tokens (original weights)
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.attnprobe as AP, isa.proxy_probes as PP
for m in (AP, PP): importlib.reload(m)
L = PARAMS.get('L', 12)
probes = PP.build(tok, FIT_PROMPTS); qk = AP.QKCapture(model, [L]); S = []
for i, pr in enumerate(probes[::2]):
    ids = tok(pr[1], return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    Pr = qk.probs(L, T).numpy(); S.append(Pr[:, 4:, 0])      # [16, T-4]
qk.remove()
S = np.concatenate(S, 1)
for h in range(16): print('head %2d: sink mass min %.3f p1 %.3f p10 %.3f median %.3f' % (h, S[h].min(), np.percentile(S[h], 1), np.percentile(S[h], 10), np.median(S[h])))
exec(open(WS + '/scripts/k_cleanup.py').read())
