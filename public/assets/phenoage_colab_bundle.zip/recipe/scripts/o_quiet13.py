# offline: candidate GATED_Z channel directions at L13: trade natural (probe + prompt tokens) vs answer-state quietness
import sys, numpy as np
sys.path.insert(0, '.')
import isa.quiet as QU
g = np.load('data/gammas.npz')['G_po'][13]
XP = np.load('data/probe_rows.npz')['pa13'].astype(np.float64) / g
d13 = np.load('data/ans_l13.npz'); XA = d13['X'].astype(np.float64) / g; LA = d13['LAB']; XO = d13['XO'].astype(np.float64) / g
mm = np.load('data/nat_moments.npz')['M_pa'][13].astype(np.float64) / np.outer(g, g)
def nrm(M): return M / np.trace(M)
QA = 0
for j in range(3):
    Z = XA[(LA[:, 1] == j) & (LA[:, 0] < 600)]; Z = Z - Z.mean(0); QA = QA + Z.T @ Z / len(Z)
QN = nrm(mm) + nrm(XP.T @ XP / len(XP)) + nrm(XO.T @ XO / len(XO))       # uncentred: off-answer values must be ~0
V = {}
for s in ['s1', 's2', 's3', 's5', 's5arith', 's6', 's7z']:
    dd = np.load(f'vec/{s}.npz'); V.update({k: dd[k] for k in dd.files})
X0 = np.load('data/pos0_states.npy')
used = [V['eY'], V['e_v'], V['e_ind'], V['eP'], V['eV'], V['eANS'], V['e_ans2'], V['eA'], V['eF'], V['eFB'], V['ePD']] + list(V['pin_e']) + list(V['u_items']) + list(V['bit_e']) + list(V['pads']) + [X0[L] for L in range(10, 16)]
E = np.linalg.qr(np.array(used).T)[0]; Pp = np.eye(1024) - E @ E.T
for wA in [0.0, 0.1, 1.0, 10.0]:
    Q = Pp @ (QN + wA * nrm(QA)) @ Pp + 1e3 * E @ E.T
    w, Vv = np.linalg.eigh(Q); e = Vv[:, 0]
    print('wA %5.1f: off-answer |e.x/rms| probes max %.4f p99 %.4f | prompt max %.4f | answer sd %s' % (wA, np.abs(XP @ e).max(), np.percentile(np.abs(XP @ e), 99), np.abs(XO @ e).max(), [round(float((XA[LA[:, 1] == j] @ e).std()), 4) for j in range(3)]))
    if wA == float(sys.argv[1] if len(sys.argv) > 1 else 0.1): np.save('vec/quiet13_dirs.npy', Vv[:, :4].T)
print('current e_z1: probes max %.4f prompt max %.4f' % (np.abs(XP @ V['e_z'][0]).max(), np.abs(XO @ V['e_z'][0]).max()))
