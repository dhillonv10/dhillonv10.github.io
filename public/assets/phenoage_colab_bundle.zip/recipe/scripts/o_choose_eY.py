# choose eY: quiet at the pool's read layer (L11 in) for VF rows (isolate installed, no arith), max pool OV gain
import numpy as np, sys
R = np.load('data/rows_' + (sys.argv[1] if len(sys.argv) > 1 else 'in11') + '.npz'); XV = R['XV'].astype(np.float64); LV = R['LV']
G = np.load('data/gammas.npz'); g = G['G_in'][int(sys.argv[2]) if len(sys.argv) > 2 else 11]
tr = LV[:, 0] < 600; te = (LV[:, 0] >= 600) & (LV[:, 0] < 750)
Y = XV[tr] / g; C = np.cov(Y.T); C /= np.trace(C)
OV = np.load('data/pool_ov.npy')
w, Vv = np.linalg.eigh(C)
Q = Vv[:, :60]
_, sv, Vt = np.linalg.svd(OV @ Q, full_matrices=False)
eY = Q @ Vt[0]; eY /= np.linalg.norm(eY)
p = (XV[te] / g) @ eY
print('eY gain %.3f, held-out VF sd along eY %.5f (normalized-raw units), compare natural-quiet...' % (sv[0], p.std()))
S5 = dict(np.load('vec/s5.npz')); S5['eY'] = eY; np.savez('vec/s5.npz', **S5)   # bits file keeps all its keys
if len(sys.argv) > 3: sys.exit(0)
ev = Q[:, 1] - (Q[:, 1] @ eY) * eY; ev /= np.linalg.norm(ev)
S5 = dict(np.load('vec/s5.npz')); S5['e_v'] = ev; np.savez('vec/s5.npz', **S5); print('e_v saved')
