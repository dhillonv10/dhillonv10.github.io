import numpy as np, sys
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import phenoage_program as PG
Lp, hp = PG.POOL['L'], PG.POOL['heads'][0]
gp = P[f'model.layers.{Lp}.input_layernorm.weight'].double().numpy()
OV = P[f'model.layers.{Lp}.self_attn.o_proj.weight'].double().numpy()[:, 128 * hp:128 * hp + 128] @ P[f'model.layers.{Lp}.self_attn.v_proj.weight'].double().numpy()[128 * (hp // 2):128 * (hp // 2) + 128] * gp[None]
np.save(WS + '/data/pool_ov.npy', OV); print('ok')
