import os
os.environ['OMP_NUM_THREADS'] = '2'; os.environ['OPENBLAS_NUM_THREADS'] = '2'
import numpy as np
from sklearn.svm import LinearSVC
A = np.load('data/ans2_pa6.npz'); XA = A['X'].astype(np.float32); la = A['lab']
d = np.load('data/s2L6_pa6.npz'); X = d['X'].astype(np.float32)[::3]
XP = np.load('data/s2L6_probes_pa6.npy').astype(np.float32)
tr = la[:, 0] < 600; te = ~tr
pos = XA[tr & (la[:, 1] == 1)]; neg = np.r_[XA[tr & (la[:, 1] != 1)], X[::6], XP[::3]]
sc = 32.0 / np.median(np.linalg.norm(X, axis=1))
clf = LinearSVC(C=0.1, class_weight={1: 20, -1: 1}, max_iter=5000, dual=False).fit(np.r_[pos, neg] * sc, np.r_[np.ones(len(pos)), -np.ones(len(neg))])
w = clf.coef_[0] * sc; b = clf.intercept_[0]
s = XA @ w + b
print('ANS2 svm: test on-min %.3f | ANS3 max %.3f | ANS1 max %.3f | on-prompt others max %.3f | probes max %.3f (held-out probes %.3f)' % (
    s[te & (la[:, 1] == 1)].min(), s[la[:, 1] == 2].max(), s[la[:, 1] == 3].max(), (X[1::2] @ w + b).max(), (XP @ w + b).max(), (XP[1::2] @ w + b).max()))
np.savez('vec/s2_ans2_svm.npz', w=w, b=b)
