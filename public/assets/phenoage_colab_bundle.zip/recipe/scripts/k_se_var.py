# local proxy SE for a variant: PARAMS upto, scale {key: factor}, se_idx
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prims as PRM, isa.se as SE
for m in (CO, PRM, SE): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
if PARAMS.get('over'): d_ = np.load(WS + '/' + PARAMS['over']); V.update({k: d_[k] for k in d_.files})
for k, f in PARAMS.get('scale', {}).items(): V[k] = V[k] * f
for k, v in PARAMS.get('set', {}).items(): V[k] = np.float64(v)
reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS.get('upto'))
if PARAMS.get('se', 1): r = SE.se_local(model, tok, FIT_PROMPTS, idx=PARAMS.get('se_idx'))
exec(open(WS + '/scripts/k_cleanup.py').read())
