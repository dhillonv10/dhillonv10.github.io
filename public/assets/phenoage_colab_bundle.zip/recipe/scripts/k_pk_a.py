# PK (a): removal cost of pool q-head 0's natural output: full E3 install + head-0 natural o_proj columns zeroed
# (channel 14 = VTAKE kept or zeroed by PARAMS 'keep14')
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO
importlib.reload(CO)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS.get('upto'))
L = PG.POOL['L']; h = PG.POOL['heads'][0]; ch = int(V['pool_vch'])
for c in range(128):
    if c == ch and PARAMS.get('keep14', 1): continue
    reg.set(CO.pname(L, 'o'), 1, 128 * h + c, np.zeros(1024), owner='pk_zero' if c != ch else 'pool_v')
print('head %d natural o columns zeroed' % h)
exec(open(WS + '/scripts/k_cleanup.py').read())
