# S7: EMIT at L27 MLP. Logit vectors u_d (digits) and u_eos by an active-set least-squares on the lm_head; QUAD read-out
# (logit_d = A*(2 d z - d^2) + B) at ANS1 (tens, z1) and ANS2 (units, z2); EOS at ANS3. Then generate on held-out practice.
import sys, importlib, numpy as np, re
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR
for m in (CO, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
F = np.load(WS + '/vec/s7_fit.npz')
W = model.lm_head.weight.detach().double()          # [V, 1024]
gf = model.model.norm.weight.detach().double()
dig = [tok.convert_tokens_to_ids(str(d)) for d in range(10)]
eos = tok.convert_tokens_to_ids('<|im_end|>')
targets = dig + [eos]
C = list(targets)
def solve(C, tvec):
    Wc = W[C] * gf[None]                              # logits = Wc @ u_raw_normalised
    G = Wc @ Wc.T + 1e-6 * torch.eye(len(C), dtype=torch.float64)
    return Wc.T @ torch.linalg.solve(G, tvec)
U = None
for it in range(6):
    T = torch.zeros(len(C), len(targets), dtype=torch.float64)
    for j in range(len(targets)): T[j, j] = 1.0
    U = solve(C, T)                                    # [1024, 11]: column j gives logit 1 on target j, 0 on other C tokens
    L = W @ (gf[:, None] * U)                         # full-vocab logits per unit vector
    bad = set()
    for j in range(len(targets)):
        col = L[:, j].clone(); col[targets[j]] = -1e9
        top = torch.topk(col, 50).indices.tolist()
        bad |= {t for t in top if L[t, j] > 0.05}
    new = [t for t in bad if t not in C]
    print('iter', it, 'C size', len(C), 'max off-target logit per unit %.3f' % max(float(torch.max(torch.cat([L[:targets[j], j], L[targets[j] + 1:, j]]))) for j in range(len(targets))), 'new', len(new))
    if not new: break
    C += new
U = U.numpy()
ud = U[:, :10].T; ueos = U[:, 10]
d = np.arange(10)
A = PARAMS.get('A', 30.0); Bb = PARAMS.get('B', 20.0)
V7 = dict(isA1=F['isA1'], isA2=F['isA2'], isA3=F['isA3'], z1=F['z1'], z2=F['z2'], c27=F['c27'],
          em_lin=A * (2 * d[:, None] * ud).sum(0), em_const=A * ((Bb - d[:, None] ** 2) * ud).sum(0), em_eos=A * PARAMS.get('Aeos', 3.0) * Bb * ueos,
          kapE=np.float64(PARAMS.get('kapE', 60.0)), Escale=np.float64(PARAMS.get('Escale', 1.0)))
np.savez(WS + '/vec/s7.npz', **V7)
V.update(V7)
reg = CO.Registry(P); PG.install(reg, V)
# test generation on held-out practice
errs = []; outs = []
for pi in range(600, 750, PARAMS.get('step', 5)):
    items = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(items)
    g = generate(FIT_PROMPTS[pi])
    m = re.search(r'-?\d+(\.\d+)?', g); v = float(m.group()) if m else 45.0
    errs.append(abs(v - y)); outs.append((pi, round(y, 1), repr(g)))
print('held-out generate MAE %.3f over %d prompts' % (np.mean(errs), len(errs)))
for o in outs[:12]: print(o)
exec(open(WS + '/scripts/k_cleanup.py').read())
