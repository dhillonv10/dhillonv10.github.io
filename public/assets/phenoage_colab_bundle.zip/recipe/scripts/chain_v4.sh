#!/bin/bash
set -e
set -o pipefail
cd /tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon
PY=../venv/bin/python
scripts/kpy.sh scripts/derive_s6c.py '{"ncut":10,"kmul":30,"qmul":30,"p0":52,"nsynth":100,"step":3,"Lr":12,"rYmode":"plain"}' 6
$PY scripts/o_s7d.py 1e-4 12
$PY scripts/o_s7e.py ${AZ:-200}
scripts/kpy.sh scripts/derive_s7e.py "{\"Emul\":${EMUL:-15.0},\"step\":5}" 14
scripts/kpy.sh scripts/k_se_var.py '{}' 2
echo CHAIN_V4_DONE
