# offline D1: refit the bit SVMs on practice rows + digit-augmented rows (rows_pa9_aug); report held-out errors on the
# practice test set AND on held-out augmented rows (rare digits). usage: o_s5a_svm_aug.py [save]
import os
os.environ['OMP_NUM_THREADS'] = '2'; os.environ['OPENBLAS_NUM_THREADS'] = '2'
import numpy as np, sys
from sklearn.svm import LinearSVC
R = np.load('data/rows_pa9.npz'); XV = R['XV'].astype(np.float32); LV = R['LV']; XN = R['XN'].astype(np.float32)
A = np.load('data/rows_pa9_aug.npz'); XA = A['XV'].astype(np.float32); LA = A['LV']
XP = np.load('data/probe_rows.npz')['pa9'].astype(np.float32)
med = np.median(np.linalg.norm(XV, axis=1))
ok = np.linalg.norm(XV, axis=1) > 0.8 * med; XV, LV = XV[ok], LV[ok]
okA = np.linalg.norm(XA, axis=1) > 0.8 * med; print('aug rows kept %d / %d' % (okA.sum(), len(okA))); XA, LA = XA[okA], LA[okA]
pi = LV[:, 0]; trV = (pi < 600) | (pi >= 1100); prac = (pi >= 600) & (pi < 750)
trA = (LA[:, 0] % 5) != 0; teA = ~trA
sc = 32.0 / med
F = dict(np.load('vec/s5a_fit_svm.npz')); c = F['c9']; keys = []
for col, k in [(3, 2), (4, 4), (5, 5), (6, 6)]:
    y = LV[:, col].astype(int); val = np.where(y < 10, y, 0); ya = LA[:, col].astype(int); vala = np.where(ya < 10, ya, 0)
    for b in range(4):
        t = (val >> b) & 1; ta = (vala >> b) & 1
        if t[trV].sum() < 3: continue
        Xt = np.r_[XV[trV], XA[trA], XN[::2], XP[::2]] * sc
        yt = np.r_[2 * t[trV] - 1, 2 * ta[trA] - 1, -np.ones(len(XN[::2]) + len(XP[::2]))]
        wneg = float(os.environ.get("WNEG", "1")); sw = np.r_[np.ones(trV.sum() + trA.sum()), wneg * np.ones(len(XN[::2]) + len(XP[::2]))]
        clf = LinearSVC(C=0.5, max_iter=30000, dual=False).fit(Xt, yt, sample_weight=sw)
        w = clf.coef_[0] * sc; bb = clf.intercept_[0]
        s = XV @ w + bb; sa = XA @ w + bb
        old = 2 * (XA @ F[f'w{k}_{b}']) - 1     # old soft bit -> svm-like score (soft = 0.5 w + (0.5+0.5b)c)
        print('off%d bit%d: practice-test err %d | aug held-out err %d / %d (old decoder %d) | nonVF max %.3f probes max %.3f' % (
            k, b, ((s[prac] > 0) != (t[prac] == 1)).sum(), ((sa[teA] > 0) != (ta[teA] == 1)).sum(), teA.sum(), ((old[teA] > 0) != (ta[teA] == 1)).sum(),
            (XN @ w + bb).max(), (XP @ w + bb).max()), flush=True)
        if len(sys.argv) > 1: F[f'w{k}_{b}'] = 0.5 * w + (0.5 + 0.5 * bb) * c
if len(sys.argv) > 1: np.savez('vec/s5a_fit_svm.npz', **F); print('saved')
