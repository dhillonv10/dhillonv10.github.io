# collect VF rows (xhat) at L12 in (pipeline up to kinks) + labels, and probe/age-prompt rows at L12 in (all tokens,
# subsampled), for the off-prompt-quiet eY design
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR, isa.proxy_probes as PP
for m in (CO, FK, PR, PP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='kinks')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
cap = FK.Capture(model, [('in', 12)])
XV, LV = [], []
for pi in range(0, 750, 5):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); X = cap[('in', 12)]
    for it in res[pi]['items']:
        XV.append(X[it['vf']].astype(np.float32)); LV.append([pi, it['item'], PR.item_years(PR.ITEM_NAMES[it['item']], it['value']) - V['mu'][it['item']]])
    del X
probes = PP.build(tok, FIT_PROMPTS); XN = []
for i, pr in enumerate(probes):
    ids = tok(pr[1], return_tensors='pt').input_ids; cap.run(ids); X = cap[('in', 12)]
    XN.append(X[1:].astype(np.float32).copy()); del X
cap.remove()
XN = np.concatenate(XN)
np.savez(WS + '/data/vf_in12.npz', XV=np.stack(XV), LV=np.array(LV), XN=XN)
print('saved', len(XV), XN.shape)
exec(open(WS + '/scripts/k_cleanup.py').read())
