import numpy as np, sys
sys.path.insert(0, '.')
from isa.attn import TH
d = np.load('data/qk_L4.npz'); Q, K, T = d['Q'].astype(np.float64), d['K'].astype(np.float64), d['T']
gk = np.load('data/qknorms.npz')['k'][4].astype(np.float64)
def rot(x, pos):  # x [...,128], pos array
    c = np.cos(pos[:, None] * TH[None]); s = np.sin(pos[:, None] * TH[None])
    x1, x2 = x[..., :64], x[..., 64:]
    return np.concatenate([x1 * c - x2 * s, x1 * s + x2 * c], -1)
ANCH = [int(a) for a in sys.argv[1].split(',')] if len(sys.argv) > 1 else [49]
off = 0; prompts = []
for Tn in T:
    prompts.append((Q[off:off + Tn], K[off:off + Tn], Tn)); off += Tn
def alpha(kstar, h):
    """attention mass on anchors (key replaced by kstar) for queries t>=50; returns min, mean"""
    res = []
    for q, k, Tn in prompts:
        pos = np.arange(Tn); qr = rot(q[:, h], pos); kk = k.copy()
        for a in ANCH: kk[a] = kstar
        kr = rot(kk, pos)
        S = qr[50:] @ kr.T / np.sqrt(128)
        S += np.triu(np.full((Tn, Tn), -np.inf), 1)[50:]
        S -= S.max(1, keepdims=True); E = np.exp(S); E /= E.sum(1, keepdims=True)
        res.append(E[:, ANCH].sum(1))
    r = np.concatenate(res); return r.min(), r.mean()
k0 = K[0]
for h in (0, 1): print('head', h, 'kstar=k0: min %.3f mean %.3f' % alpha(k0, h))
# optimise kstar: maximise soft-min of (q_t . R(t-a) kstar - lse_others) ; use mean rotated query direction in slow planes
qs = []
for q, k, Tn in prompts:
    pos = np.arange(50, Tn) - ANCH[-1]
    qs.append(np.stack([rot(q[50:, hh], pos.astype(float)) for hh in (0, 1)], 1).reshape(len(pos), -1))
qs = np.concatenate(qs)  # [N, 2*128]
qm = qs.reshape(-1, 2, 128).mean(0).sum(0)   # combined direction for both heads
# feasible key: k = gk * z, |z|^2 = 128 -> best z ∝ gk * qm
z = gk * qm; z *= np.sqrt(128) / np.linalg.norm(z); ks = gk * z
for h in (0, 1): print('head', h, 'kstar=opt-mean: min %.3f mean %.3f' % alpha(ks, h))
for lam in [0.3, 0.6]:
    k2 = (1 - lam) * k0 / np.linalg.norm(k0 / gk) * np.sqrt(128) + lam * ks
    z2 = k2 / gk; k2 = gk * z2 * np.sqrt(128) / np.linalg.norm(z2)
    for h in (0, 1): print('lam', lam, 'head', h, 'min %.3f mean %.3f' % alpha(k2, h))
np.save('vec/flag_kstar_L4.npy', ks)
