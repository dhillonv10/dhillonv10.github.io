import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.proxy_probes as PP, isa.neg_texts as NT; importlib.reload(PP); importlib.reload(NT)
probes = PP.build(tok, FIT_PROMPTS)
negs = [p for _, p in probes] + [PP.chat(tok, u) for u in NT.NEG_USER]
pheno = [FIT_PROMPTS[i] for i in range(0, 300, 10)]
Lm = model.model.layers
SIDES = [('pa', 1), ('pa', 2), ('in', 2), ('in', 3), ('pa', 3)]
cap = {}
hooks = []
for kind, L in SIDES:
    mod = Lm[L].input_layernorm if kind == 'in' else Lm[L].post_attention_layernorm
    def f(m, i, key=(kind, L)):
        x = i[0][0].double(); cap[key] = (x / x.pow(2).mean(-1, keepdim=True).add(1e-6).sqrt() * m.weight.double()).float()
    hooks.append(mod.register_forward_pre_hook(f))
out = {k: [] for k in SIDES}; meta = []
try:
    with torch.no_grad():
        for j, p in enumerate(pheno + negs):
            ids = tok(p, return_tensors='pt').input_ids
            model(ids)
            isph = j < len(pheno)
            sel = np.arange(ids.shape[1]) if not isph else (np.arange(0, 70) if j == 0 else np.arange(58, ids.shape[1]))
            for k in SIDES: out[k].append(cap[k][sel].numpy().astype(np.float16))
            for t in sel: meta.append((j, int(t), int(isph), int(ids[0, t])))
finally:
    for h in hooks: h.remove()
np.savez(WS + '/data/flag_coll.npz', meta=np.array(meta, dtype=np.int32), **{f'{k}{L}': np.concatenate(out[(k, L)]) for k, L in SIDES})
print('rows', len(meta), 'npheno', len(pheno))
