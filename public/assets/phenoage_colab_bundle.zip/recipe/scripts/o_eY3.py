# offline F1: eY = argmin e'[A_VF + l1*M_off + l2*(R10+R11)]e over dims with |gamma12| >= gmin, orthogonal to codes.
# A_VF: VF rows at L12 in (gamma-divided, = what the e/gamma read sees), M_off: probe-token rows (same coords),
# R: gamma-weighted W_v grams of L10/L11. usage: o_eY3.py l1 l2 [save]
import sys, numpy as np
sys.path.insert(0, '.')
l1, l2 = float(sys.argv[1]), float(sys.argv[2]); save = len(sys.argv) > 3
d = np.load('data/vf_in12.npz'); g = np.load('data/gammas.npz')['G_in'][12]
XV = d['XV'].astype(np.float64) / g; XN = d['XN'].astype(np.float64)[::3] / g; LV = d['LV']
V = {}
for s in ['s1', 's2', 's3', 's5', 's5arith', 's6', 's7z']:
    dd = np.load(f'vec/{s}.npz'); V.update({k: dd[k] for k in dd.files})
X0 = np.load('data/pos0_states.npy')
used = [V['eY'], V['e_v'], V['e_ind'], V['eP'], V['eV'], V['eANS'], V['e_ans2'], V['eA'], V['eF'], V['eFB'], V['ePD']] + list(V['pin_e']) + list(V['u_items']) + list(V['bit_e']) + list(V['pads']) + list(V['e_z']) + list(V['e_i']) + [X0[L] for L in range(5, 16)]
small = np.abs(g) < float(sys.argv[4]) if len(sys.argv) > 4 else np.abs(g) < 0.3
used += list(np.eye(1024)[small])
E = np.linalg.qr(np.array(used).T)[0]; Pp = np.eye(1024) - E @ E.T
def nt(M): return M / np.trace(M)
XVc = XV - XV.mean(0)
AV = nt(XVc.T @ XVc); MO = nt(XN.T @ XN)
W = np.load('data/wv_10_11.npz'); R = 0
for L in (10, 11):
    A = W[f'v{L}'].astype(np.float64); R = R + nt(A.T @ A)
def stats(e, nm):
    print('%s: VF read sd %.5f | off-prompt sd %.4f max %.4f | v-forms %.3e' % (nm, (XV @ e).std(), (XN @ e).std(), np.abs(XN @ e).max(), e @ R @ e))
eo = V['eY']
r = (XV @ eo); Y = LV[:, 2]; k = np.polyfit(Y, r, 1)
print('old eY: VF read resid sd (after Y) %.5f | off-prompt sd %.4f max %.4f | v-forms %.3e | per-yr %.5f' % ((r - np.polyval(k, Y)).std(), (XN @ eo).std(), np.abs(XN @ eo).max(), eo @ R @ eo, k[0]))
w, Vv = np.linalg.eigh(Pp @ (AV + l1 * MO + l2 * R) @ Pp + 1e3 * E @ E.T)
e = Vv[:, 0]; stats(e, 'new eY (l1 %g l2 %g)' % (l1, l2))
if save: np.save('vec/eY3.npy', e); print('saved')
