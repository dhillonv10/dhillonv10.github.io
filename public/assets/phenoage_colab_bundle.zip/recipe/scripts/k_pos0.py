import numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
ids = tok(FIT_PROMPTS[0], return_tensors='pt').input_ids
with torch.no_grad(): hs = model(ids, output_hidden_states=True).hidden_states
X0 = np.stack([h[0, 0].double().numpy() for h in hs]); PRE = np.stack([h[0, :58].double().numpy() for h in hs])
np.save(WS + '/data/pos0_states.npy', X0); np.save(WS + '/data/prefix_states.npy', PRE.astype(np.float32))
print(np.argsort(-np.abs(X0[4]))[:8], np.sort(np.abs(X0[4]))[-8:].round(1))
