import gc, ctypes, sys
gc.collect()
sys.last_traceback = None; sys.last_value = None; sys.last_type = None
gc.collect()
try:
    print('malloc_trim', ctypes.CDLL('libc.so.6').malloc_trim(0))
except Exception as e: print(e)
import resource; print('rss now MB', int(open('/proc/self/statm').read().split()[1]) * 4096 // 2**20)
