# collect xhat at L4 pa and raw |x| at L4 pa, L5 pa for natural (probes) and on-prompt (S1 installed) rows
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.proxy_probes as PP
for m in (CO, FK, PP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='flag_head')   # FB itself not installed
Ls = PARAMS.get('pair', [4, 5])
cap = FK.Capture(model, [('pa', Ls[0]), ('pa', Ls[1])], raw=True)
g = P[f'model.layers.{Ls[0]}.post_attention_layernorm.weight'].double().numpy()
probes = PP.build(tok, FIT_PROMPTS)
XH, N0, N1, ON = [], [], [], []
for j, p in enumerate([q for _, q in probes] + [FIT_PROMPTS[i] for i in range(0, 750, 12)]):
    cap.run(tok(p, return_tensors='pt').input_ids)
    a = cap[('pa', Ls[0])]; b = cap[('pa', Ls[1])]
    s = 1 if j < len(probes) else 58
    XH.append(FK.xhat_np(a[s:], g).astype(np.float32)); N0.append(np.linalg.norm(a[s:], axis=1)); N1.append(np.linalg.norm(b[s:], axis=1)); ON.append(np.full(len(a) - s, j >= len(probes)))
cap.remove()
np.savez(WS + f'/data/norm_{Ls[0]}_{Ls[1]}.npz', XH=np.concatenate(XH), N0=np.concatenate(N0), N1=np.concatenate(N1), ON=np.concatenate(ON))
print('ok')
