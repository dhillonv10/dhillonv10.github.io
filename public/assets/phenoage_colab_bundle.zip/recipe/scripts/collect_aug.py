# D1 augmentation: practice prompts with item numbers re-drawn DIGIT BY DIGIT (same length/format, uniform digits), so
# every (item, offset, digit) combination occurs; VF rows at (side, L) with offset digit labels (rows_pa9 layout).
import sys, importlib, numpy as np, random
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS.get('upto', 'shift'))
side, L = PARAMS.get('side', 'pa'), PARAMS.get('L', 9)
tokk = {**{15 + d: d for d in range(10)}, 220: 10, 13: 11}
rng = random.Random(PARAMS.get('seed', 7))
def redraw(s):
    out = []
    for i, ch in enumerate(s):
        if ch.isdigit():
            lead = (i == 0 and len(s.split('.')[0]) > 1)
            out.append(str(rng.randint(1 if lead else 0, 9)))
        else: out.append(ch)
    return ''.join(out)
cap = FK.Capture(model, [(side, L)]); XV, LV = [], []
for n in range(PARAMS.get('n', 300)):
    pi = rng.randrange(0, 600); p = FIT_PROMPTS[pi]
    parts = PR.parse_text(p)
    for it, vs, a, b in sorted(parts, key=lambda t: -t[2]):
        if it != 0 and rng.random() < 0.7: p = p[:a] + redraw(vs) + p[b:]
    pr = PR.parse(p, tok)
    ids = tok(p, return_tensors='pt').input_ids; cap.run(ids); XH = cap[(side, L)]
    for it in pr['items']:
        vf = it['vf']; offs = [tokk.get(int(ids[0, vf - k]), 12) for k in (1, 2, 4, 5, 6)]
        XV.append(XH[vf].astype(np.float32)); LV.append([2000 + n, it['item']] + offs + [it['value']])
    del XH
cap.remove()
np.savez(WS + f"/data/rows_{PARAMS.get('tag', 'pa9_aug')}.npz", XV=np.stack(XV), LV=np.array(LV))
print('saved', len(XV))
exec(open(WS + '/scripts/k_cleanup.py').read())
