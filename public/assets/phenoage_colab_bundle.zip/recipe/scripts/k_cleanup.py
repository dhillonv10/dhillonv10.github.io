def _cleanup(g):
    import gc, ctypes, sys
    keep = {'torch', 'np', 'tok', 'model', 'P', 'D', 'PARAMS', 'FIT_PROMPTS', 'FIT_Y', 'forward', 'generate', '_cleanup'}
    for k in list(g.keys()):
        if k not in keep and not k.startswith('__'):
            del g[k]
    sys.last_traceback = None; sys.last_value = None
    gc.collect()
    try: ctypes.CDLL('libc.so.6').malloc_trim(0)
    except Exception: pass
_cleanup(globals())
