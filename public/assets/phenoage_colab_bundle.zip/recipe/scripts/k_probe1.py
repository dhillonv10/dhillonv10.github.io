import time
print(model.device, next(model.parameters()).dtype, torch.get_num_threads())
p = FIT_PROMPTS[0]
ids = tok(p).input_ids
print(len(ids))
toks = [tok.decode([i]) for i in ids]
print(list(enumerate(toks))[25:140])
print(list(enumerate(toks))[-12:])
t=time.time()
for i in range(5):
    print(repr(generate(FIT_PROMPTS[i])), FIT_Y[i])
print('gen time', time.time()-t)
t=time.time()
with torch.no_grad():
    ids2 = tok(FIT_PROMPTS[:8], return_tensors='pt', padding=True)
print(tok.padding_side)
