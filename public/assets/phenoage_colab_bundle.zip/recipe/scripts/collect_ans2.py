# rows at (pa, L) for ANS2 tokens (practice prompt + appended digit) and other on-prompt + probe-like digits, S1 installed
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK
for m in (CO, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS.get('upto', 'fb'))
L = PARAMS.get('L', 6)
cap = FK.Capture(model, [('pa', L)])
X, lab = [], []
rng = np.random.default_rng(1)
for pi in range(0, 750, 2):
    d1, d2 = int(rng.integers(0, 10)), int(rng.integers(0, 10))
    ids = tok(FIT_PROMPTS[pi] + f'{d1}{d2}', return_tensors='pt').input_ids; cap.run(ids); XH = cap[('pa', L)]
    X.append(XH[-2].astype(np.float32)); lab.append([pi, 1])     # ANS2
    X.append(XH[-1].astype(np.float32)); lab.append([pi, 2])     # ANS3 (digit after digit)
    X.append(XH[-3].astype(np.float32)); lab.append([pi, 3])     # ANS1
    del XH
cap.remove()
np.savez(WS + f'/data/ans2_pa{L}.npz', X=np.stack(X), lab=np.array(lab)); print(len(X))
exec(open(WS + '/scripts/k_cleanup.py').read())
