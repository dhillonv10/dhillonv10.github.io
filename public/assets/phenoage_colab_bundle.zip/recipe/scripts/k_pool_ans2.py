# analysis: pool-head attention at ANS1 / ANS2 / ANS3 (VF mass, weight cv, where the rest goes)
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.attnprobe as AP, isa.prompts as PR
for m in (CO, AP, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='pool')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
L = 12; h = PG.POOL['heads'][0]
qk = AP.QKCapture(model, [L]); out = {0: [], 1: [], 2: []}
for pi in range(601, 750, 10):
    its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    yi = int(np.clip(np.floor(PR.phenoage(its) + 0.5), 0, 99))
    ids = tok(FIT_PROMPTS[pi] + f'{yi // 10}{yi % 10}', return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    Pr = qk.probs(L, T).numpy()[h]; vfs = [it['vf'] for it in res[pi]['items']]
    for j, pos in enumerate((T - 3, T - 2, T - 1)):
        p = Pr[pos]; oth = np.setdiff1d(np.arange(pos + 1), vfs); top = oth[np.argsort(-p[oth])[:3]]
        out[j].append((p[vfs].sum(), p[vfs].std() / p[vfs].mean(), top[0] - pos, p[top[0]]))
qk.remove()
for j in out:
    R = np.array(out[j]); print('ANS%d: VF mass min %.4f median %.4f | cv median %.4f | top non-VF offset %s mass max %.4f' % (j + 1, R[:, 0].min(), np.median(R[:, 0]), np.median(R[:, 1]), np.unique(R[:, 2])[:5], R[:, 3].max()))
exec(open(WS + '/scripts/k_cleanup.py').read())
