import numpy as np, sys
sys.path.insert(0, '.')
from isa.attn import TH
d = np.load('data/qk_L4.npz'); Q, K, T = d['Q'].astype(np.float64), d['K'].astype(np.float64), d['T']
gk = np.load('data/qknorms.npz')['k'][4].astype(np.float64)
def rot(x, pos):
    c = np.cos(pos[:, None] * TH[None]); s = np.sin(pos[:, None] * TH[None])
    x1, x2 = x[..., :64], x[..., 64:]
    return np.concatenate([x1 * c - x2 * s, x1 * s + x2 * c], -1)
ANCH = [int(a) for a in sys.argv[1].split(',')]
T0 = int(sys.argv[2]) if len(sys.argv) > 2 else 58
# precompute: for each prompt/head/query t>=T0: lse over non-anchor keys, and rotated queries per anchor
LSE = []; QR = []
off = 0
for Tn in T:
    q, k = Q[off:off + Tn], K[off:off + Tn]; off += Tn
    pos = np.arange(Tn)
    for h in (0, 1):
        qr = rot(q[:, h], pos); kr = rot(k, pos)
        S = qr[T0:] @ kr.T / np.sqrt(128); S += np.triu(np.full((Tn, Tn), -np.inf), 1)[T0:]
        S[:, ANCH] = -np.inf
        m = S.max(1); LSE.append(m + np.log(np.exp(S - m[:, None]).sum(1)))
        # score of anchor a with key kstar: (R_{t-a} q_t) . kstar / sqrt(128)
        QR.append(np.stack([rot(q[T0:, h], (np.arange(T0, Tn) - a).astype(float)) for a in ANCH], 1) / np.sqrt(128))
LSE = np.concatenate(LSE); QR = np.concatenate(QR)  # [N, nA, 128]
def stats(ks):
    s = QR @ ks  # [N, nA]
    lse_a = np.log(np.exp(s).sum(1))
    alpha = 1 / (1 + np.exp(LSE - lse_a))
    return alpha
k0 = K[0]
a = stats(k0); print('k0: alpha min %.3f p1 %.3f mean %.3f' % (a.min(), np.percentile(a, 1), a.mean()))
z = k0 / gk; z *= np.sqrt(128) / np.linalg.norm(z)
beta = 2.0
for it in range(400):
    ks = gk * z
    s = QR @ ks; lse_a = np.log(np.exp(s).sum(1)); marg = lse_a - LSE
    w = np.exp(-beta * (marg - marg.min())); w /= w.sum()   # softmin weights
    pa = np.exp(s - lse_a[:, None])  # anchor-softmax weights
    grad_k = np.einsum('n,na,nad->d', w, pa, QR)
    gz = grad_k * gk
    z = z + 0.5 * gz / (np.linalg.norm(gz) + 1e-12) * np.sqrt(128) * 0.05
    z *= np.sqrt(128) / np.linalg.norm(z)
    if it % 100 == 99:
        a = stats(gk * z); print(it, 'alpha min %.3f p1 %.3f mean %.3f  margin min %.2f' % (a.min(), np.percentile(a, 1), a.mean(), marg.min()))
np.save('vec/flag_kstar_L4.npy', gk * z)
