# Direction design v3 (ISA: NULLSPACE_DIRS). Every private direction is chosen so that the modules that must NOT see it
# respond weakly (small quadratic form), and the ones that must see it respond strongly:
#  A (switch/pin dirs: e_sw, e_V, e_ANS, e_ans2, u_items[13]): small for W_q of SHIFT heads 0-4 and W_k of SHIFT groups
#     0-2 at L9, W_k of the POOL group / W_q of the POOL head at L12, and naturally quiet (L7-L12 inputs)
#  B (digit/space/dot codes, 12): small for W_k(SHIFT groups, L9) + quiet, large for W_v(SHIFT groups, L9)
#  C (bits, pads, CRP channels, eY): small for W_v of ALL L10 and L11 heads (no copying between VF tokens), W_k of the
#     POOL group at L12, quiet at L10-L12; eY = the C-direction with the largest POOL OV gain
import sys, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import phenoage_program as PG
def Wg(L, mod, rows, side='in'):
    g = P[f'model.layers.{L}.{"input_layernorm" if side == "in" else "post_attention_layernorm"}.weight'].double().numpy()
    W = P[f'model.layers.{L}.self_attn.{mod}_proj.weight'].double().numpy()[rows]
    return W * g[None]
def form(M): M = M.T @ M if M.shape[0] != M.shape[1] or not np.allclose(M, M.T) else M; return M / np.trace(M) * 1024
NM = np.load(WS + '/data/nat_moments.npz')['M_in']; G = np.load(WS + '/data/gammas.npz')['G_in']
def quiet(L): M = NM[L].astype(np.float64) / np.outer(G[L], G[L]); return M / np.trace(M) * 1024
X0 = np.load(WS + '/data/pos0_states.npy')
V1 = np.load(WS + '/vec/s1.npz')
prev = [V1['eA'], V1['eF'], V1['eFB']] + [X0[L] for L in range(5, 14)]
E = np.linalg.qr(np.array(prev).T)[0]; Pp = np.eye(1024) - E @ E.T
def bottom(Q, n, excl):
    Ex = np.linalg.qr(np.array(excl).T)[0] if len(excl) else np.zeros((1024, 0))
    Pe = np.eye(1024) - Ex @ Ex.T
    w, Vv = np.linalg.eigh(Pe @ Q @ Pe + 1e6 * (np.eye(1024) - Pe))
    return Vv[:, :n].T, w[:n]
ph = PG.POOL['heads'][0]; pg = ph // 2
q9 = form(Wg(9, 'q', slice(0, 640))); k9 = form(Wg(9, 'k', slice(0, 384))); v9 = Wg(9, 'v', slice(0, 384))
k12 = form(Wg(12, 'k', slice(128 * pg, 128 * pg + 128))); q12 = form(Wg(12, 'q', slice(128 * ph, 128 * ph + 128)))
lam = PARAMS.get('lam', 1.0)
QA = q9 + k9 + k12 + q12 + lam * sum(quiet(L) for L in range(7, 13)) / 6
A, wA = bottom(QA, 17, prev)
print('family A eig (relative to mean 1):', wA[[0, -1]].round(5))
QBs = k9 + lam * sum(quiet(L) for L in range(7, 10)) / 3 + 1e-3 * np.eye(1024)
excl = prev + list(A)
Ex = np.linalg.qr(np.array(excl).T)[0]; Pe = np.eye(1024) - Ex @ Ex.T
Vf = form(v9)
# maximise e'Vf e / e'QBs e within the complement of A
from scipy.linalg import eigh as geigh
Mb = Pe @ QBs @ Pe + 1e6 * (np.eye(1024) - Pe); Ma = Pe @ Vf @ Pe
wB, VB = geigh(Ma, Mb)
B = VB[:, -12:].T; B = np.linalg.qr(B.T)[0].T
print('family B: W_v gain (form) %.3f..%.3f, W_k form %.4f..%.4f' % (min(b @ Vf @ b for b in B), max(b @ Vf @ b for b in B), min(b @ k9 @ b for b in B), max(b @ k9 @ b for b in B)))
v10 = form(Wg(10, 'v', slice(0, 1024))); v11 = form(Wg(11, 'v', slice(0, 1024)))
QC = v10 + v11 + k12 + lam * sum(quiet(L) for L in range(10, 13)) / 3
C, wC = bottom(QC, 60, excl + list(B))
print('family C eig:', wC[[0, 31, -1]].round(5), ' (v10 form of first: %.5f)' % (C[0] @ v10 @ C[0]))
gp = G[12]
OV = P[f'model.layers.12.self_attn.o_proj.weight'].double().numpy()[:, 128 * ph:128 * ph + 128] @ P[f'model.layers.12.self_attn.v_proj.weight'].double().numpy()[128 * pg:128 * pg + 128] * gp[None]
Cq = C[:40]
_, sv, Vt = np.linalg.svd(OV @ Cq.T, full_matrices=False)
eY = Vt[0] @ Cq; eY /= np.linalg.norm(eY)
rest = np.linalg.qr(np.c_[eY, Cq.T])[0][:, 1:].T     # C minus eY
print('eY pool OV gain %.3f (v11 form %.5f)' % (sv[0], eY @ v11 @ eY))
D = dict(e_sw=A[0], eV=A[1], eANS=A[2], e_ans2=A[3], u_items=A[4:17], pin_e=B, eP=A[0],
         bit_e=rest[:14], pads=rest[14:28], e_v=rest[28], e_ind=rest[29], eY=eY)
np.savez(WS + '/vec/dirs_v3.npz', **D)
print('saved')
