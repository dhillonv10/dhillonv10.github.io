# analysis: VF-token norm at L12 in per item, and the eY read in raw vs xhat units (pipeline up to kinks)
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='kinks')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
cap = FK.Capture(model, [('in', 12)], raw=True); rows = []
for pi in range(0, 750, 6):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); Xr = cap[('in', 12)]
    for it in res[pi]['items']:
        i = it['item']; x = Xr[it['vf']]
        rows.append((pi, i, PR.item_years(PR.ITEM_NAMES[i], it['value']) - V['mu'][i], np.linalg.norm(x), x @ V['eY']))
    del Xr
cap.remove()
R = np.array(rows); np.save(WS + '/data/vf_rms_l12.npy', R)
for i in range(13):
    m = R[:, 1] == i
    if m.sum(): print('item %2d n %3d |x| mean %.0f sd %.1f | Y range %.1f..%.1f' % (i, m.sum(), R[m, 3].mean(), R[m, 3].std(), R[m, 2].min(), R[m, 2].max()))
exec(open(WS + '/scripts/k_cleanup.py').read())
