# S6 v3: POOL at L12 + VTAKE of one value channel of the pool group (reads eY with gain G, writes a private ePD at the
# answer positions: the natural OV gain made the pooled Y ~1e-6 of the ANS1 norm). Previously (v2): with equal weights (query orthogonal to the item/digit-dependent key deviations), then collect
# answer-position states at L13 pa (ANS1, ANS2 = +tens digit, ANS3 = +units digit) for the EMIT fits.
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.attnprobe as AP, isa.prims as PRM, isa.prompts as PR
for m in (CO, FK, AP, PRM, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = set([15 + d for d in range(10)] + [220, 13])
reg = CO.Registry(P); PG.install(reg, V, upto='kinks')
L = PG.POOL['L']; h = PG.POOL['heads'][0]; g = h // 2
cap = FK.Capture(model, [('in', L)])
VF, DG, AN, OT, X0 = [], [], [], [], None
for pi in range(0, 600, 12):
    ids = tok(FIT_PROMPTS[pi] + str(pi % 10), return_tensors='pt').input_ids
    cap.run(ids); XH = cap[('in', L)]; X0 = XH[0].copy()
    vfs = [it['vf'] for it in res[pi]['items']]
    VF.append(XH[vfs]); AN.append(XH[-2:-1].copy()); DG.append(XH[[t for t in range(58, ids.shape[1]) if int(ids[0, t]) in tokk]])
    OT.append(XH[[t for t in range(58, ids.shape[1] - 2) if int(ids[0, t]) not in tokk and t not in vfs][::4]])
    del XH
cap.remove()
VF, DG, AN, OT = map(np.concatenate, (VF, DG, AN, OT))
Mn = np.load(WS + '/data/nat_moments.npz')['M_in'][L].astype(np.float64) + FK.second_moment(OT)
reg_ = 1e-6 * np.trace(Mn) / 1024 * np.eye(1024)
C = np.c_[AN.mean(0), DG.mean(0), X0]; Z = np.linalg.solve(Mn + reg_, C); rq = Z @ np.linalg.solve(C.T @ Z, np.array([1.0, 1.0, 0.0]))
Ck = np.c_[VF.mean(0), DG.mean(0), AN.mean(0), X0]; Zk = np.linalg.solve(Mn + reg_, Ck); rk = Zk @ np.linalg.solve(Ck.T @ Zk, np.array([1.0, 0.0, 0.0, 0.0]))
gq = P[f'model.layers.{L}.self_attn.q_norm.weight'].double().numpy(); gk = P[f'model.layers.{L}.self_attn.k_norm.weight'].double().numpy()
Wq = P[f'model.layers.{L}.self_attn.q_proj.weight'].double().numpy()[128 * h:128 * h + 128]
Wk = P[f'model.layers.{L}.self_attn.k_proj.weight'].double().numpy()[128 * g:128 * g + 128]
p0 = int(PARAMS.get('p0', 44))       # slow RoPE planes p0..63 (first-order rotation over the VF span ~ theta_p0)
slow = np.zeros(128, bool); slow[p0:64] = True; slow[64 + p0:128] = True
kd = np.where(slow, np.sign(gk), 0.0)
kt = kd / np.linalg.norm(kd) * PARAMS.get('kmul', 10.0) * np.median(np.linalg.norm(Wk @ VF.T, axis=0))
dk = kt - Wk @ VF.mean(0)
kraw = Wk @ VF.T + np.outer(dk, VF @ rk)                    # [128, n]
kpost = gk[:, None] * kraw / np.sqrt((kraw ** 2).mean(0, keepdims=True))
dev = kpost - kpost.mean(1, keepdims=True)
U, S_, _ = np.linalg.svd(dev[slow], full_matrices=False)
ncut = int(PARAMS.get('ncut', 12))
qs = kpost.mean(1)[slow]; qs = qs - U[:, :ncut] @ (U[:, :ncut].T @ qs)
qpost = np.zeros(128); qpost[slow] = qs
qt = qpost / np.where(np.abs(gq) > 1e-3, gq, 1e-3)
qt = qt / np.linalg.norm(qt) * PARAMS.get('qmul', 10.0) * np.median(np.linalg.norm(Wq @ AN.T, axis=0))
dq = qt - Wq @ np.r_[AN, DG].mean(0)
sc = kpost.T @ qpost / np.sqrt(128) * (np.sqrt(128) / np.linalg.norm(qpost / np.where(np.abs(gq) > 1e-3, gq, 1e-3)) * 1.0)
print('pool design: removed %d deviation dirs (sv %s); score spread over VF keys (post-norm q·k, arbitrary scale) sd/mean %.4f' % (ncut, S_[:ncut].round(2), (kpost.T @ qpost).std() / (kpost.T @ qpost).mean()))
V6 = dict(pool_rq=rq, pool_rk=rk, pool_dq=dq, pool_dk=dk)
# --- VTAKE channel and ePD chosen offline (scripts/o_pool_ch.py; in-kernel version crashed the server natively)
CH = np.load(WS + '/vec/s6_ch.npz'); ch = int(PARAMS.get('vch', CH['vch']))
# eY read at VF in xhat: slope per year of item contribution
yi = []
for pi in range(0, 600, 12):
    for it in res[pi]['items']: yi.append(PR.item_years(PR.ITEM_NAMES[it['item']], it['value']) - V['mu'][it['item']])
yi = np.array(yi); gl = P[f'model.layers.{L}.input_layernorm.weight'].double().numpy()
rY = V['eY'] / gl                     # read on xhat that equals eY.x/rms (raw-quiet; eY.xhat itself picks up 4 yr of junk)
if PARAMS.get('rYmode', 'minvar') == 'minvar':
    # natural-quiet AND VF-quiet read with the same response to the eY write: min r'(M_nat + w*Cov_VF)r, r.(g*eY) = g.eY^2...
    Mnat = np.load(WS + '/data/nat_moments.npz')['M_in'][L].astype(np.float64)
    CV = np.cov((VF - np.outer(VF @ rY, gl * V['eY']) / ((gl * V['eY']) @ rY)).T)
    Mq = Mnat / np.trace(Mnat) + PARAMS.get('wVF', 1.0) * CV / np.trace(CV)
    rY = FK.minvar_read(Mq, gl * V['eY'], zero=[X0]) * ((gl * V['eY']) @ rY)
    print('rY minvar: natural sd ratio new/old %.4f' % np.sqrt((rY @ Mnat @ rY) / ((V['eY'] / gl) @ Mnat @ (V['eY'] / gl))))
ey = VF @ rY                          # VF rows are xhat at L12 in (gamma applied)
kY = np.polyfit(yi, ey, 1)[0]
print('eY.xhat at VF per year %.5f (fit resid sd %.2e yr)' % (kY, (ey - np.polyval(np.polyfit(yi, ey, 1), yi)).std() / abs(kY)))
ePD = CH['ePD']
sY = PARAMS.get('sY', 0.3)            # raw write per year of the total Y at the answer positions
G = 10.0 * sY / kY
V6.update(pool_vch=np.int64(ch), pool_vrow=G * rY, ePD=ePD, pool_sY=np.float64(sY))
print('VTAKE gain G %.1f' % G)
V.update(V6); np.savez(WS + '/vec/s6.npz', **V6)
PG.install_pool(reg, V)
qk = AP.QKCapture(model, [L]); mass = []; cv = []
for pi in range(601, 750, 10):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    Pr = qk.probs(L, T).numpy()[h, -1]; vfs = [it['vf'] for it in res[pi]['items']]
    mass.append(Pr[vfs].sum()); cv.append(Pr[vfs].std() / Pr[vfs].mean())
qk.remove()
print('pool at ANS1: VF mass min %.5f | weight cv max %.4f median %.4f' % (min(mass), max(cv), np.median(cv)))
# answer-position states at L13 pa
Lr = PARAMS.get('Lr', 13)
# (no SystemExit in the kernel: it stops the server process)
if PARAMS.get('collect', 1):
    cap = FK.Capture(model, [('pa', Lr)])
    pool_ = PR.item_value_pool(FIT_PROMPTS[:600]); rng = np.random.default_rng(11)
    plist = []
    for pi in range(0, 750, PARAMS.get('step', 3)):
        its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
        plist.append((pi, FIT_PROMPTS[pi], PR.phenoage(its), sum(PR.item_years(n, v) - V['mu'][PR.ITEM_NAMES.index(n)] for n, v in its.items())))
    for j in range(PARAMS.get('nsynth', 100)):
        sp, y, its = PR.synth(FIT_PROMPTS[int(rng.integers(0, 600))], pool_, rng)
        plist.append((1000 + j, sp, y, sum(PR.item_years(n, v) - V['mu'][PR.ITEM_NAMES.index(n)] for n, v in its.items())))
    X, LAB, XO = [], [], []
    for pi, prm, y, S in plist:
        yi = int(np.clip(np.floor(y + 0.5), 0, 99)); T_, U_ = yi // 10, yi % 10
        ids = tok(prm + f'{T_}{U_}', return_tensors='pt').input_ids; cap.run(ids); XH = cap[('pa', Lr)]
        for k, pos in enumerate((-3, -2, -1)):
            X.append(XH[pos].astype(np.float32)); LAB.append([pi, k, y, T_, U_, S])
        for t in rng.choice(np.arange(58, ids.shape[1] - 3), 6, replace=False): XO.append(XH[t].astype(np.float32))
        del XH
    cap.remove()
    np.savez(WS + f'/data/ans_l{Lr}.npz', X=np.stack(X), LAB=np.array(LAB), XO=np.stack(XO))
    print('saved', len(X))
exec(open(WS + '/scripts/k_cleanup.py').read())
