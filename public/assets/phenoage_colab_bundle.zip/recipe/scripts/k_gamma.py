import numpy as np
G_in = np.stack([P[f'model.layers.{L}.input_layernorm.weight'].numpy() for L in range(28)])
G_po = np.stack([P[f'model.layers.{L}.post_attention_layernorm.weight'].numpy() for L in range(28)])
gf = P['model.norm.weight'].numpy()
np.savez('/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon/data/gammas.npz', G_in=G_in, G_po=G_po, gf=gf)
print([k for k in P if 'lm_head' in k or 'embed' in k])
print(torch.equal(model.lm_head.weight, model.model.embed_tokens.weight), model.lm_head.weight.data_ptr()==model.model.embed_tokens.weight.data_ptr())
