import numpy as np
d = np.load('data/flag_coll.npz'); meta = d['meta']
j, t, isph = meta[:, 0], meta[:, 1], meta[:, 2]
npheno = 30
anc_rows = {a: np.where((j == 0) & (t == a))[0][0] for a in range(30, 58)}
neg = ~((j == 0) & (t < 70)) & ~((isph == 1) & (t < 58))   # all probe/neg tokens + PhenoAge tokens >= 58
# tokens of my extra negative texts (last 12 prompts)
nn = j.max() + 1; extra = j >= nn - 12
names = {34:' Ph',35:'eno',36:'Age',37:' (',38:'Le',39:'vine',40:' ',41:'2',42:'0',43:'1',44:'8',45:' phen',46:'otyp',47:'ic',48:' age',49:')',50:' in',51:' years',52:'?',53:' Answer',57:'.nn'}
for key in ['pa1', 'pa2', 'pa3']:
    X = d[key].astype(np.float64)
    Xn = X[neg]; mu = Xn.mean(0); C = np.cov(Xn.T) + 1e-3 * np.trace(np.cov(Xn.T)) / 1024 * np.eye(1024)
    Ci = np.linalg.inv(C)
    out = []
    for a in [34, 35, 36, 38, 39, 45, 46, 48, 49, 51, 52, 57]:
        xa = X[anc_rows[a]]; r = Ci @ (xa - mu); s = (X - mu) @ r / ((xa - mu) @ r)
        sn = s[neg]; se = s[neg & extra]
        out.append(f"{names.get(a,a)}:{sn.max():.2f}/{se.max():.2f}")
    print(key, ' '.join(out))
print('--- per extra prompt max (pa3), and max over non-extra negatives')
X = d['pa3'].astype(np.float64); Xn = X[neg]; mu = Xn.mean(0); C = np.cov(Xn.T) + 1e-3 * np.trace(np.cov(Xn.T)) / 1024 * np.eye(1024); Ci = np.linalg.inv(C)
for a in [35, 36, 39, 46, 48, 49]:
    xa = X[anc_rows[a]]; r = Ci @ (xa - mu); s = (X - mu) @ r / ((xa - mu) @ r)
    per = [round(float(s[(j == k)].max()), 2) for k in range(nn - 12, nn)]
    print(names[a], 'non-extra max %.3f' % s[neg & ~extra].max(), 'extras', per)
