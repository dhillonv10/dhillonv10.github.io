#!/bin/bash
set -e
cd /tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon
PY=../venv/bin/python
$PY wsp_cli.py python scripts/collect_probe_rows.py '{"layers":[9,10,11,12,13],"n":40}' | tail -1
$PY wsp_cli.py python scripts/collect_rows.py '{"upto":"shift","side":"pa","L":9,"tag":"pa9","nsynth":100,"step":2,"nneg":15}' | tail -1
$PY scripts/o_s5a.py 5 | head -1
timeout 3000 $PY scripts/o_s5a_svm.py 2>&1 | grep -v Warn
$PY wsp_cli.py python scripts/derive_s5a2.py '{"v3":1}' | tail -2
echo CHAIN_S5_DONE
