#!/bin/bash
# run a script in the kernel; print the last N lines of its output; exit 1 if the kernel reported an exception
# usage: kpy.sh script.py ['{params}'] [N]
cd /tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon
P="${2:-}"; [ -z "$P" ] && P='{}'
out=$(../venv/bin/python wsp_cli.py python "$1" "$P" 2>&1); rc=$?
printf '%s\n' "$out" | tail -n "${3:-20}"
if [ $rc -ne 0 ] || printf '%s' "$out" | grep -q 'Traceback\|^ERROR'; then echo "KPY_FAIL $1"; exit 1; fi
exit 0
