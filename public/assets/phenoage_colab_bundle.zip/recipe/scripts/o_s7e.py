# offline: GATED_Z stage vectors. e_z, e_i: ANS-quiet directions at L13 (variance of answer-position states in the
# normalised-raw coordinates of the L13 MLP read) + small natural term, orthogonal to every code in use and to ePD.
# cA: CONST fitted on the ANS1/ANS2 rows at L12 pa. Reads isA1/isA2/z1r/z2r from vec/s7_fit_L12d.npz.
import sys, numpy as np
sys.path.insert(0, '.')
import isa.quiet as QU
F = np.load('vec/s7_fit_L12d.npz')
d12 = np.load('data/ans_l12.npz'); X12 = d12['X'].astype(np.float64); L12 = d12['LAB']
d13 = np.load('data/ans_l13.npz'); X13 = d13['X'].astype(np.float64); L13 = d13['LAB']
g13 = np.load('data/gammas.npz')['G_po'][13]
Q = 0
for j in range(3):
    m = (L13[:, 1] == j) & (L13[:, 0] < 600); Z = X13[m] / g13; Z = Z - Z.mean(0); Q = Q + Z.T @ Z / len(Z)
Q = Q / np.trace(Q)
V = {}
for s in ['s1', 's2', 's3', 's5', 's5arith', 's6']:
    dd = np.load(f'vec/{s}.npz'); V.update({k: dd[k] for k in dd.files})
ch = np.load('vec/s6_ch.npz'); X0 = np.load('data/pos0_states.npy')
used = [V['eY'], V['e_v'], V['e_ind'], V['eP'], V['eV'], V['eANS'], V['e_ans2'], V['eA'], V['eF'], V['eFB'], V['ePD'], ch['ePD_old']] + list(V['pin_e']) + list(V['u_items']) + list(V['bit_e']) + list(V['pads']) + [X0[L] for L in range(10, 16)]
E, w = QU.quiet_dirs([13, 14], 4, side='in', exclude=used, extra=[Q / 0.05])
E = E / np.linalg.norm(E, axis=1, keepdims=True)
e_z, e_i = E[[0, 2]], E[[1, 3]]
for nm, v in [('e_z1', E[0]), ('e_i1', E[1]), ('e_z2', E[2]), ('e_i2', E[3])]:
    print('%s: ANS sd along read %s' % (nm, [round(float((X13[(L13[:, 1] == j) & (L13[:, 0] < 600)] @ (v / g13)).std()), 5) for j in range(3)]))
k = L12[:, 1].astype(int); pi = L12[:, 0]
m = (k <= 1) & (pi < 600)
A = X12[m].T @ X12[m]; A += 1e-4 * np.trace(A) / 1024 * np.eye(1024)
cA = np.linalg.solve(A, X12[m].T @ np.ones(m.sum()))
te = (k <= 1) & (pi >= 600) & (pi < 750)
print('cA at ANS1/2 practice test: mean %.5f sd %.5f min %.4f max %.4f' % ((X12[te] @ cA).mean(), (X12[te] @ cA).std(), (X12[te] @ cA).min(), (X12[te] @ cA).max()))
# GATED_Z gates on DESIGNED pin reads (eANS/gamma, e_ans2/gamma: exact codes, tiny off-prompt values)
g12 = np.load('data/gammas.npz')['G_po'][12]; D3 = np.load('vec/dirs_v3.npz'); isA = {}
for nm, e, j in [('isA1', D3['eANS'], 0), ('isA2', D3['e_ans2'], 1)]:
    r = e / g12; isA[nm] = r / (X12[k == j] @ r).mean()
# z reads exactly 0 at the position-0 sink (CONSTs are ~-0.1 there, so the gate is open at pos 0): min-variance
# correction against the ANS rows
X0s = np.load('data/pos0_states.npy')[12]; xh0 = g12 * X0s / np.sqrt((X0s ** 2).mean()); zr = {}
for nm, j in [('z1r', 0), ('z2r', 1)]:
    r = F[nm]; A_ = X12[k == j]; M_ = A_.T @ A_ / len(A_); M_ += 1e-6 * np.trace(M_) / 1024 * np.eye(1024)
    z0 = np.linalg.solve(M_, xh0); zr[nm] = r - (r @ xh0) * z0 / (xh0 @ z0)
    print('%s: pos0 %.3f -> %.1e | ANS change sd %.5f' % (nm, r @ xh0, zr[nm] @ xh0, (A_ @ (zr[nm] - r)).std()))
np.savez('vec/s7z.npz', isA1=isA['isA1'], isA2=isA['isA2'], isA3=F['isA3'], z1r=zr['z1r'], z2r=zr['z2r'], cA=cA, cZ=F['c13'], e_z=e_z, e_i=e_i,
         a_z=np.float64(float(sys.argv[1]) if len(sys.argv) > 1 else 8.0), kapZ=np.float64(300.0))
print('saved')
