import numpy as np
m = np.load('data/nat_moments.npz'); u = np.load('data/nat_usage.npz')
norms = {0:0.8,3:13,6:22,9:28.5,12:45,15:52.6,18:85.7,21:160,24:277,27:478}
for L in range(0, 28, 2):
    M = m['M_in'][L].astype(np.float64); w = np.linalg.eigvalsh(M)
    tot = np.trace(M)
    print(f'L{L:2d} trace(xhat^2)={tot:9.1f} (|xhat|={np.sqrt(tot):6.1f}) quietest sd: {np.sqrt(np.maximum(w[:5],0)).round(4)} rel {np.sqrt(np.maximum(w[0],0)/tot):.2e}  #dirs with sd<1e-3*|xhat|: {(np.sqrt(np.maximum(w,0))<1e-3*np.sqrt(tot)).sum()}')
nact = u['nact']
print('L27 neuron max act sorted', np.sort(nact[27])[:20].round(3))
print('L26', np.sort(nact[26])[:10].round(3))
