# S4: SHIFT heads at L9 (DUAL: q-switch on VF pins, k-switch on all pins), natural W_v/W_o transport the pin codes.
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.se as SE, isa.attn as AT, isa.attnprobe as AP, isa.prims as PRM
for m in (CO, FK, SE, AT, AP, PRM): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
L = PG.SHIFT['L']
V = PG.load(WS)
reg = CO.Registry(P); PG.install(reg, V, upto='ident')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = {**{15 + d: d for d in range(10)}, 220: 10, 13: 11}
gin = P[f'model.layers.{L}.input_layernorm.weight'].double().numpy()
cap = FK.Capture(model, [('in', L)])
VFX, PX, X0 = [], [], None
for pi in range(0, 600, 30):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); XH = cap[('in', L)]
    X0 = XH[0]
    vf = [it['vf'] for it in res[pi]['items']]
    VFX.append(XH[vf])
    pins = [t for t in range(58, ids.shape[1]) if int(ids[0, t]) in tokk]
    PX.append(XH[pins])
VFX = np.concatenate(VFX); PX = np.concatenate(PX)
Mn = np.load(WS + '/data/nat_moments.npz', mmap_mode='r')['M_in'][L].astype(np.float64)
allpin = np.r_[VFX, PX]
rP = FK.minvar_read(Mn, allpin.mean(0), zero=[X0])
rV = FK.minvar_read(Mn, VFX.mean(0), zero=[X0, PX.mean(0)])
print('rP on pinned: min %.3f max %.3f | rV on VF min %.3f max %.3f, on digit pins max %.3f' % ((allpin @ rP).min(), (allpin @ rP).max(), (VFX @ rV).min(), (VFX @ rV).max(), np.abs(PX @ rV).max()))
gq = P[f'model.layers.{L}.self_attn.q_norm.weight'].double().numpy(); gk = P[f'model.layers.{L}.self_attn.k_norm.weight'].double().numpy()
Wq = P[f'model.layers.{L}.self_attn.q_proj.weight'].double().numpy(); Wk = P[f'model.layers.{L}.self_attn.k_proj.weight'].double().numpy()
V4 = dict(rP=rP, rV=rV)
dq, dk = {}, {}
for g, offs in PG.SHIFT['groups'].items():
    qds, kd, m = AT.pos_design_mass(gq, gk, offs, T=800, iters=2000)
    print('group', g, 'offsets', offs, 'design logit margin %.2f' % m)
    Wkg = Wk[128 * g:128 * g + 128]
    kn = np.linalg.norm(Wkg @ allpin.T, axis=0)
    kt = kd / np.linalg.norm(kd) * PARAMS.get('kmul', 10.0) * np.median(kn)
    dk[g] = kt - Wkg @ allpin.mean(0)
    for h, qd in zip((2 * g, 2 * g + 1), qds):
        Wqh = Wq[128 * h:128 * h + 128]
        qn = np.linalg.norm(Wqh @ VFX.T, axis=0)
        qt = qd / np.linalg.norm(qd) * PARAMS.get('qmul', 10.0) * np.median(qn)
        dq[h] = qt - Wqh @ VFX.mean(0)
V4['dk'] = np.stack([dk[g] for g in sorted(dk)]); V4['dq'] = np.stack([dq[h] for h in sorted(dq)])
V4['dk_groups'] = np.array(sorted(dk)); V4['dq_heads'] = np.array(sorted(dq))
V.update(V4)
cap.remove()
PG.install_shift(reg, V)
# attention check at VF tokens
qk = AP.QKCapture(model, [L])
mass = {h: [] for h in dq}
for pi in range(601, 750, 15):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    Pr = qk.probs(L, T).numpy()
    for h in dq:
        g = h // 2; k = PG.SHIFT['groups'][g][h % 2]
        for it in res[pi]['items']:
            vf = it['vf']; mass[h].append(Pr[h, vf, vf - k])
qk.remove()
for h in mass:
    a = np.array(mass[h]); print('head', h, 'target-offset mass: min %.4f p1 %.4f median %.5f' % (a.min(), np.percentile(a, 1), np.median(a)))
np.savez(WS + '/vec/s4.npz', **V4)
if PARAMS.get('se', 0): SE.se_local(model, tok, FIT_PROMPTS)
exec(open(WS + '/scripts/k_cleanup.py').read())
