# natural statistics on proxy probes + practice prompts: second moments of xhat (in / pa sides) per layer,
# per-neuron max |silu(g)*u| * |down| (dormancy), per-head output norms.
import sys, importlib, numpy as np, time
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.proxy_probes as PP; importlib.reload(PP)
probes = PP.build(tok, FIT_PROMPTS)
prompts = [p for _, p in probes] + [FIT_PROMPTS[i] for i in range(0, 600, 10)]
Lm = model.model.layers
M_in = [torch.zeros(1024, 1024, dtype=torch.float64) for _ in range(28)]
M_pa = [torch.zeros(1024, 1024, dtype=torch.float64) for _ in range(28)]
S_in = [torch.zeros(1024, dtype=torch.float64) for _ in range(28)]
NACT = torch.zeros(28, 3072, dtype=torch.float64); NACT_pr = torch.zeros(28, 3072, dtype=torch.float64)
NMEAN = torch.zeros(28, 3072, dtype=torch.float64)
HOUT = torch.zeros(28, 16, dtype=torch.float64); HOUT_pr = torch.zeros(28, 16, dtype=torch.float64)
ntok = [0]; cur_is_probe = [True]
hooks = []
def mk_in(L):
    def f(m, i):
        x = i[0][0, 1:].double(); xh = x / x.pow(2).mean(-1, keepdim=True).add(1e-6).sqrt() * m.weight.double()
        M_in[L].add_(xh.T @ xh); S_in[L].add_(xh.sum(0))
    return f
def mk_pa(L):
    def f(m, i):
        x = i[0][0, 1:].double(); xh = x / x.pow(2).mean(-1, keepdim=True).add(1e-6).sqrt() * m.weight.double()
        M_pa[L].add_(xh.T @ xh)
    return f
DN = [P[f'model.layers.{L}.mlp.down_proj.weight'].norm(dim=0).double() for L in range(28)]
def mk_down(L):
    def f(m, i):
        a = i[0][0, 1:].double().abs() * DN[L]
        NACT[L] = torch.maximum(NACT[L], a.max(0).values); NMEAN[L] += a.sum(0)
        if cur_is_probe[0]: NACT_pr[L] = torch.maximum(NACT_pr[L], a.max(0).values)
    return f
def mk_o(L):
    def f(m, i):
        z = i[0][0, 1:].double().view(-1, 16, 128)
        W = m.weight.double().view(1024, 16, 128)
        o = torch.einsum('thd,ohd->tho', z, W).norm(dim=-1)  # per-head output norm
        HOUT[L] = torch.maximum(HOUT[L], o.max(0).values)
        if cur_is_probe[0]: HOUT_pr[L] += o.sum(0)
    return f
for L in range(28):
    hooks.append(Lm[L].input_layernorm.register_forward_pre_hook(mk_in(L)))
    hooks.append(Lm[L].post_attention_layernorm.register_forward_pre_hook(mk_pa(L)))
    hooks.append(Lm[L].mlp.down_proj.register_forward_pre_hook(mk_down(L)))
    hooks.append(Lm[L].self_attn.o_proj.register_forward_pre_hook(mk_o(L)))
t = time.time()
try:
    with torch.no_grad():
        for j, p in enumerate(prompts):
            cur_is_probe[0] = j < len(probes)
            ids = tok(p, return_tensors='pt').input_ids
            ntok[0] += ids.shape[1] - 1
            model(ids)
finally:
    for h in hooks: h.remove()
print('time', time.time() - t, 'tokens', ntok[0])
n = ntok[0]
np.savez(WS + '/data/nat_moments.npz', M_in=np.stack([m.numpy() / n for m in M_in]).astype(np.float32),
         M_pa=np.stack([m.numpy() / n for m in M_pa]).astype(np.float32), S_in=np.stack([s.numpy() / n for s in S_in]))
np.savez(WS + '/data/nat_usage.npz', nact=NACT.numpy(), nact_pr=NACT_pr.numpy(), nmean=NMEAN.numpy() / n, hout=HOUT.numpy(), hout_pr=HOUT_pr.numpy())
