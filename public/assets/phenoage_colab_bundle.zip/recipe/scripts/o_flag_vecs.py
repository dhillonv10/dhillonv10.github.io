# offline: anchor detector at L3 pa (token 49 ')'), CONST at L3 pa, quiet direction e_A for L4..L9 inputs
import numpy as np
d = np.load('data/flag_coll.npz'); meta = d['meta']; j, t, isph = meta[:, 0], meta[:, 1], meta[:, 2]
neg = ~((j == 0) & (t < 70)) & ~((isph == 1) & (t < 58))
X = d['pa3'].astype(np.float64)
# CONST: ridge of 1 on all natural rows (exclude pos0 which is not in rows except j==0 t==0 -> exclude t==0)
m = t > 0
Xc = X[m]; c = np.linalg.solve(Xc.T @ Xc + 1e-2 * np.trace(Xc.T @ Xc) / 1024 * np.eye(1024), Xc.T @ np.ones(len(Xc)))
cv = Xc @ c; print('CONST L3pa: mean %.4f sd %.4f min %.3f max %.3f' % (cv.mean(), cv.std(), cv.min(), cv.max()))
# detector in raw xhat coordinates with intercept on CONST: s = r.x + b*(c.x)
Xa = np.c_[X, X @ c]
Xn = Xa[neg]; mu = Xn.mean(0); C = np.cov(Xn.T) + 1e-3 * np.trace(np.cov(Xn.T)) / 1025 * np.eye(1025)
pos = np.where((j == 0) & (t == 49))[0][0]
Ci = np.linalg.inv(C); r = Ci @ (Xa[pos] - mu); r /= (Xa[pos] - mu) @ r
s = (Xa - mu) @ r
# fold centering into the CONST coefficient: s = r[:1024].x + r[1024]*(c.x) - mu.r  ~ r.x + (r[1024] - mu.r)*(c.x)
rr = r[:1024]; bb = r[1024] - mu @ r
s2 = X @ rr + bb * (X @ c)
print('anchor score at 49: %.4f; neg max %.3f (sd %.4f); folded version: pos %.4f neg max %.3f' % (s[pos], s[neg].max(), s[neg].std(), s2[pos], s2[neg].max()))
nn = j.max() + 1
print('extras', [round(float(s2[j == k].max()), 2) for k in range(nn - 12, nn)])
print('PhenoAge prompt tokens (other than anchors) max', s2[(isph == 1) & (t >= 58)].max().round(3), ' fixed-prefix tokens', s2[(j == 0) & (t < 70) & (t != 49)].max().round(3))
np.save('vec/flag_det_L3.npy', np.r_[rr, bb]); np.save('vec/const_L3pa.npy', c)
# quiet direction for e_A: minimise sum over L4..L10 of normalised natural second moment (raw residual direction):
mm = np.load('data/nat_moments.npz'); G = np.load('data/gammas.npz')
Q = np.zeros((1024, 1024))
for L in range(4, 11):
    M = mm['M_in'][L].astype(np.float64)  # moments of xhat (with gamma); direction e (raw) appears in xhat as gamma*e
    g = G['G_in'][L]; Mr = M / np.outer(g, g)  # back to normalized-raw coordinates
    Q += Mr / np.trace(Mr)
w, V = np.linalg.eigh(Q)
eA = V[:, 0]
print('quiet eA eig', w[:3], 'top dims', np.argsort(-np.abs(eA))[:5], np.sort(np.abs(eA))[-5:].round(3))
np.save('vec/flag_eA.npy', eA); np.save('vec/quiet_L4_10.npy', V[:, :64].T.astype(np.float32))
