import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prims as PRM
for m in (CO, PRM): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P)
for kk in PARAMS.get('drop', []): V.pop(kk, None)
only = PARAMS.get('only')
if only:
    for name, fn in PG.STAGES:
        if name in only: fn(reg, V)
else:
    PG.install(reg, V, upto=PARAMS.get('upto'))
print(reg.footprint()[1])
if PARAMS.get('zero_pins'):
    L, nns = PG.NEUR['pins']
    sel = PARAMS.get('zero_sel', list(range(len(nns))))
    for i, nn in enumerate(nns):
        if i not in sel: continue
        for j in nn: reg.set(CO.pname(L, 'down'), 1, j, np.zeros(1024), 'zero')
    print('pins neurons zeroed')
for L, j in PARAMS.get('zero_neurons', []):
    reg.set(CO.pname(L, 'down'), 1, j, np.zeros(1024), 'zero')
if PARAMS.get('se'):
    import isa.se as SE; importlib.reload(SE)
    SE.se_local(model, tok, FIT_PROMPTS, idx=PARAMS.get('se_idx'))
exec(open(WS + '/scripts/k_cleanup.py').read())
