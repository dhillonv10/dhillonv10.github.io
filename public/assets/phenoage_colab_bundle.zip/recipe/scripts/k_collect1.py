import sys, pickle, numpy as np, time
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
LAY = [1, 2, 3, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22]
rng = np.random.default_rng(0)
digit_ids = {tok.convert_tokens_to_ids(str(d)): d for d in range(10)}
semi = tok.convert_tokens_to_ids(';')
rows_meta = []; H = {L: [] for L in LAY}
t = time.time()
for pi in range(0, 750, 6):  # 125 prompts
    r = res[pi]; ids = r['ids']; T = len(ids)
    vf = {it['vf']: it['item'] for it in r['items']}
    item_tok = {}
    for it in r['items']:
        for k, ti in enumerate(it['toks']): item_tok[ti] = it['item']
    sel = []
    for t_ in range(T):
        cat = None
        if t_ in vf: cat = ('vf', vf[t_])
        elif ids[t_] == semi: cat = ('semi', -1)
        elif ids[t_] in digit_ids and rng.random() < 0.35: cat = ('dig', digit_ids[ids[t_]])
        elif rng.random() < 0.06: cat = ('oth', -1)
        if cat: sel.append((t_, cat))
    with torch.no_grad():
        hs = model(torch.tensor([ids]), output_hidden_states=True).hidden_states
    tt = [s[0] for s in sel]
    for L in LAY: H[L].append(hs[L][0, tt].numpy().astype(np.float16))
    for t_, cat in sel:
        rows_meta.append((pi, t_, cat[0], cat[1], ids[t_], item_tok.get(t_, -1)))
print('time', time.time() - t, len(rows_meta))
meta = np.array([(a, b, {'vf': 0, 'semi': 1, 'dig': 2, 'oth': 3}[c], d, e, f) for a, b, c, d, e, f in rows_meta], dtype=np.int32)
np.savez(WS + '/data/coll1.npz', meta=meta, lay=np.array(LAY), **{f'h{L}': np.concatenate(H[L]) for L in LAY})
