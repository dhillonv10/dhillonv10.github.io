# feasibility: leak of DUAL-q switches (q_raw += dq * (r.xhat)) on proxy probes. r = min-variance read of a quiet dir.
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prims as PRM, isa.se as SE, isa.quiet as QU
for m in (CO, PRM, SE, QU): importlib.reload(m)
L = PARAMS.get('L', 11); heads = PARAMS.get('heads', [0, 1, 2, 3, 4]); scale = PARAMS.get('scale', 1.0)
g = P[f'model.layers.{L}.input_layernorm.weight'].double().numpy()
V, w = QU.quiet_dirs([L], 4, exclude=[np.load(WS + '/data/pos0_states.npy')[L]])
eG = V[0]
Mn = np.load(WS + '/data/nat_moments.npz', mmap_mode='r')['M_in'][L].astype(np.float64)
Mn = Mn + 1e-6 * np.trace(Mn) / 1024 * np.eye(1024)
xon = 32.0 * g * eG
r = np.linalg.solve(Mn, xon); r /= r @ xon
print('read sd off (pred) %.5f' % np.sqrt(r @ Mn @ r))
# typical raw q norm per head on a probe-like prompt
ids = tok(FIT_PROMPTS[0], return_tensors='pt').input_ids
cap = {}
hk = model.model.layers[L].self_attn.q_proj.register_forward_hook(lambda m, i, o: cap.__setitem__('q', o.detach()[0]))
hx = model.model.layers[L].input_layernorm.register_forward_hook(lambda m, i, o: cap.__setitem__('x', o.detach()[0].double().numpy()))
with torch.no_grad(): model(ids)
hk.remove(); hx.remove()
offv = cap['x'][1:] @ r; print('actual off read on a PhenoAge prompt (no G): sd %.5f max %.5f' % (offv.std(), np.abs(offv).max()))
qn = cap['q'].view(-1, 16, 128).norm(dim=-1).median(0).values.numpy()
reg = CO.Registry(P)
rng = np.random.default_rng(0)
for h in heads:
    dq = rng.standard_normal(128); dq *= scale * qn[h] / np.linalg.norm(dq)
    PRM.qswitch(reg, L, h, dq, r, owner='test')
SE.se_local(model, tok, FIT_PROMPTS)
