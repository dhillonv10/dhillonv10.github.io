# install BITS from vec/s5a_fit.npz (offline fit), choose bit/eY directions, save vec/s5.npz (bits part); quick check
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.quiet as QU
for m in (CO, QU): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
F = np.load(WS + '/vec/' + PARAMS.get('fit', 's5a_fit_svm.npz')); keys = [tuple(k) for k in F['keys']]
X0s = np.load(WS + '/data/pos0_states.npy')
prev = [V['eA'], V['eF'], V['eFB'], V['eP'], V['eV'], V['eANS']] + list(V['pin_e']) + list(V['u_items'])
bit_e, _ = QU.quiet_dirs(range(10, 13), len(keys), exclude=[X0s[L] for L in range(9, 13)] + prev)
Lp, hp = PG.POOL['L'], PG.POOL['heads'][0]
gp = P[f'model.layers.{Lp}.input_layernorm.weight'].double().numpy()
OV = P[f'model.layers.{Lp}.self_attn.o_proj.weight'].double().numpy()[:, 128 * hp:128 * hp + 128] @ P[f'model.layers.{Lp}.self_attn.v_proj.weight'].double().numpy()[128 * (hp // 2):128 * (hp // 2) + 128] * gp[None]
Ex = np.linalg.qr(np.array(prev + list(bit_e)).T)[0]
_, sv, Vt = np.linalg.svd(OV @ (np.eye(1024) - Ex @ Ex.T), full_matrices=False)
V5 = dict(bit_w=np.stack([F[f'w{k}_{b}'] for k, b in keys]), vf9=F['vf9'], c9=F['c9'], bit_e=bit_e, Pb=PARAMS.get('Pb', 60.0),
          kapB=PARAMS.get('kapB', 150.0), bitM=PARAMS.get('M', 3.0), bit_keys=np.array(keys), eY=Vt[0])
print('eY pool gain %.3f' % sv[0])
np.savez(WS + '/vec/s5.npz', **V5)
print('saved', len(keys), 'bits')
exec(open(WS + '/scripts/k_cleanup.py').read())
