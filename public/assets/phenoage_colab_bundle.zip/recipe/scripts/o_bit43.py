# offline: refit the offset-4 bit-3 SVM (digit 8/9 at offset 4 misread; pid 650 RDW 18.00 -> 10.0)
import os
os.environ['OMP_NUM_THREADS'] = '2'
import numpy as np, sys
from sklearn.svm import LinearSVC
R = np.load('data/rows_pa9.npz'); XV = R['XV'].astype(np.float32); LV = R['LV']; XN = R['XN'].astype(np.float32)
XP = np.load('data/probe_rows.npz')['pa9'].astype(np.float32)
nv = np.linalg.norm(XV, axis=1); ok = nv > 0.8 * np.median(nv); XV, LV = XV[ok], LV[ok]
pi = LV[:, 0]; trV = (pi < 600) | (pi >= 1100); teV = ~trV; prac = (pi >= 600) & (pi < 750)
sc = 32.0 / np.median(np.linalg.norm(XV, axis=1))
F = dict(np.load('vec/s5a_fit_svm.npz')); c = F['c9']
y = LV[:, 4].astype(int); val = np.where(y < 10, y, 0); t = (val >> 3) & 1
print('digit counts at offset 4 (train):', np.bincount(val[trV], minlength=10))
s_old = XV @ ((F['w4_3'] - (0.5) * c) * 2)   # approx svm score from soft bit: soft = 0.5w + (0.5+0.5b)c -> svm ~ 2*soft - 1
for C, cw in [(0.5, None), (2.0, 'balanced'), (10.0, 'balanced')]:
    Xt = np.r_[XV[trV], XN[::2], XP[::2]] * sc; yt = np.r_[2 * t[trV] - 1, -np.ones(len(XN[::2]) + len(XP[::2]))]
    clf = LinearSVC(C=C, max_iter=50000, dual=False, class_weight=cw).fit(Xt, yt)
    w = clf.coef_[0] * sc; bb = clf.intercept_[0]; s = XV @ w + bb
    print('C %g cw %s: train err %d test err %d (practice %d) | on-min %.3f off-max %.3f | nonVF max %.3f probes max %.3f' % (
        C, cw, ((s[trV] > 0) != (t[trV] == 1)).sum(), ((s[teV] > 0) != (t[teV] == 1)).sum(), ((s[prac] > 0) != (t[prac] == 1)).sum(),
        s[t == 1].min(), s[t == 0].max(), (XN @ w + bb).max(), (XP @ w + bb).max()))
    if len(sys.argv) > 1 and C == float(sys.argv[1]):
        F['w4_3'] = 0.5 * w + (0.5 + 0.5 * bb) * c; np.savez('vec/s5a_fit_svm.npz', **F); print('saved')
