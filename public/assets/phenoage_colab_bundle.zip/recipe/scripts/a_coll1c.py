import numpy as np
d = np.load('data/coll1.npz'); g = np.load('data/gammas.npz')
meta = d['meta']; LAY = d['lay']
pi, cat, lab, item = meta[:, 0], meta[:, 2], meta[:, 3], meta[:, 5]
tr = pi < 600; te = ~tr
def xhat(h, gam):
    h = h.astype(np.float64); return gam * h / np.sqrt((h ** 2).mean(1, keepdims=True) + 1e-6)
def ridge(X, Y, lam):
    mu = X.mean(0); Xc = X - mu; A = Xc.T @ Xc + lam * np.trace(Xc.T @ Xc) / X.shape[1] * np.eye(X.shape[1])
    W = np.linalg.solve(A, Xc.T @ (Y - Y.mean(0))); b = Y.mean(0) - mu @ W; return W, b
for L in LAY:
    X = xhat(d[f'h{L}'], g['G_in'][L])
    m2 = (cat == 0) | (cat == 1)
    cls = np.where(cat[m2] == 0, lab[m2], 13)
    Y2 = np.eye(14)[cls]
    for lam in [1e-3, 1e-2]:
        W, b = ridge(X[m2 & tr], Y2[tr[m2]], lam)
        P2 = X[m2 & te] @ W + b; c2 = cls[te[m2]]
        on = P2[np.arange(len(c2)), c2]; P2o = P2.copy(); P2o[np.arange(len(c2)), c2] = -9
        off = P2o[:, :13].max(1)
        print(f'L{L:2d} lam {lam:g} ident acc {(P2.argmax(1)==c2).mean():.4f} on-min(items) {on[c2<13].min():.3f} off-max {off.max():.3f} ntr {tr[m2].sum()}')
