import numpy as np
R = np.load('data/rows_pa11n.npz'); XV = R['XV'].astype(np.float64); LV = R['LV']; XN = R['XN'].astype(np.float64)
G = np.load('data/gammas.npz'); g = G['G_po'][11]
tr = LV[:, 0] < 600
Y = np.r_[XV[tr], XN] / g; C = (Y - Y.mean(0)).T @ (Y - Y.mean(0)) / len(Y); C /= np.trace(C)
S5 = dict(np.load('vec/s5.npz')); eY = S5['eY']
P_ = np.eye(1024) - np.outer(eY, eY)
w, Vv = np.linalg.eigh(P_ @ C @ P_ + 10 * np.outer(eY, eY))
ev = Vv[:, 0]
te = (LV[:, 0] >= 600) & (LV[:, 0] < 750)
print('e_v quiet: held-out VF sd %.5f, non-VF sd %.5f (normalized-raw)' % (((XV[te] / g) @ ev).std(), ((XN / g) @ ev).std()))
S5['e_v'] = ev; S5['e_ind'] = Vv[:, 1]; np.savez('vec/s5.npz', **S5)
print('e_ind held-out VF sd %.5f' % (((XV[te] / g) @ Vv[:, 1]).std()))
