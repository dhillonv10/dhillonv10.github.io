# debug: full install; for given prompts show the top next tokens at ANS1 and the L13 channel ratio
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR, isa.fitk as FK
for m in (CO, PR, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V)
capr = FK.Capture(model, [('pa', 13), ('out', 13), ('out', 27)], raw=True)
for pi in PARAMS.get('pids', [600, 610, 640]):
    its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(its)
    for suf in ['', PARAMS.get('suf', {}).get(str(pi), '')]:
        ids = tok(FIT_PROMPTS[pi] + suf, return_tensors='pt').input_ids
        with torch.no_grad(): lg = model(ids).logits[0, -1]
        capr.run(ids); B = capr[('pa', 13)][-1]; O = capr[('out', 13)][-1]; Z = capr[('out', 27)][-1]
        j = 0 if suf == '' else 1
        top = torch.topk(lg, 4)
        print(pi, repr(suf), 'y %.1f | ratio %.3f ri %.3f | |x13pa| %.0f |x13out| %.0f |x27| %.0f | top %s' % (y, (B @ V['e_z'][j]) / (B @ V['e_i'][j]), B @ V['e_i'][j], np.linalg.norm(B), np.linalg.norm(O), np.linalg.norm(Z),
              [(tok.decode([int(t)]), round(float(v), 1)) for t, v in zip(top.indices, top.values)]))
        if suf == '': print('   generate:', repr(generate(FIT_PROMPTS[pi])))
capr.remove()
exec(open(WS + '/scripts/k_cleanup.py').read())
