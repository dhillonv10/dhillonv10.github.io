# debug: compare live L12 pa answer states with the collected data/ans_l12.npz rows (same prompts)
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR, isa.fitk as FK
for m in (CO, PR, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='pool')
d = np.load(WS + '/data/ans_l12.npz'); Xc = d['X']; LAB = d['LAB']
g = P['model.layers.12.post_attention_layernorm.weight'].double().numpy(); rPD = V['ePD'] / g
cap = FK.Capture(model, [('pa', 12)])
for pi in (600, 630, 660, 690, 720):
    its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(its); yi = int(np.clip(np.floor(y + 0.5), 0, 99))
    ids = tok(FIT_PROMPTS[pi] + f'{yi // 10}{yi % 10}', return_tensors='pt').input_ids
    cap.run(ids); X = cap[('pa', 12)]
    for j, pos in enumerate((-3, -2)):
        r = np.where((LAB[:, 0] == pi) & (LAB[:, 1] == j))[0][0]
        print(pi, j, 'live-vs-collected |diff| %.4f (|x| %.2f) | sP live %.4f coll %.4f | z live %.3f coll %.3f' % (
            np.linalg.norm(X[pos] - Xc[r]), np.linalg.norm(Xc[r]), X[pos] @ rPD, Xc[r] @ rPD, X[pos] @ V['z1r' if j == 0 else 'z2r'], Xc[r] @ V['z1r' if j == 0 else 'z2r']))
cap.remove()
exec(open(WS + '/scripts/k_cleanup.py').read())
