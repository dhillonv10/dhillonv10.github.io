# offline: AFFINE stage fit at L10 pa (bits installed): value reads per offset, item reads, VF read, CONST, item up-vectors, CRP kinks
import numpy as np, sys, pickle
sys.path.insert(0, '.')
import isa.prompts as PR
LAY = 10
R = np.load(f'data/rows_pa{LAY}.npz'); XV = R['XV'].astype(np.float64); LV = R['LV']; XN = R['XN'].astype(np.float64)
XP = np.load('data/probe_rows.npz')[f'pa{LAY}'].astype(np.float64)
nv = np.linalg.norm(XV, axis=1); okp = nv > 0.8 * np.median(nv)   # drop rows whose VF pin did not fire (7 synthetic rows)
XV, LV = XV[okp], LV[okp]
pi = LV[:, 0]; trV = (pi < 600) | (pi >= 1050); teV = (pi >= 600) & (pi < 750)   # test = held-out practice only
trN = np.arange(len(XN)) % 4 != 0; trP = np.arange(len(XP)) % 4 != 0
AV = XV[trV].T @ XV[trV]; AV += 1e-6 * np.trace(AV) / 1024 * np.eye(1024)
S5 = np.load('vec/s5.npz'); keys = [tuple(k) for k in S5['bit_keys']]
G = np.load('data/gammas.npz'); gg = G['G_po'][LAY]
val_r = {}
colk = {1: 2, 2: 3, 4: 4, 5: 5, 6: 6}
for k in (1, 2, 4, 5, 6):
    y = LV[:, colk[k]].astype(int); v = np.where(y < 10, y, 0).astype(float)
    if k == 1:
        w = np.linalg.solve(AV, XV[trV].T @ v[trV])
    else:   # value = sum_b 2^b * (ridge bit read), bit reads trained on practice VF rows
        w = np.zeros(1024)
        for i, (kk, b) in enumerate(keys):
            if kk != k: continue
            t = ((np.where(y < 10, y, 0)) >> b) & 1
            w += (2 ** b) * np.linalg.solve(AV, XV[trV].T @ t[trV].astype(float))
        val_r[(k, 'off')] = 0.0
    e_ = XV[teV] @ w - v[teV] - val_r.get((k, 'off'), 0.0); val_r[k] = w
    print('value read offset %d: test err sd %.4f max %.4f' % (k, e_.std(), np.abs(e_).max()))
Xtr = np.r_[XV[trV], XN[trN], XP[trP]]
A = Xtr.T @ Xtr; A += 1e-5 * np.trace(A) / 1024 * np.eye(1024)
def fit(tV):
    return np.linalg.solve(A, Xtr.T @ np.r_[tV[trV], np.zeros(trN.sum() + trP.sum())])
vf = fit(np.ones(len(XV)))
print('vf10: VF test min %.3f max %.3f | nonVF max %.3f | probes max %.3f' % ((XV[teV] @ vf).min(), (XV[teV] @ vf).max(), np.abs(XN @ vf).max(), np.abs(XP @ vf).max()))
item_r = []
for i in range(13):
    t = (LV[:, 1] == i).astype(float); w = fit(t); s = XV[teV] @ w
    z = lambda X: X @ w + X @ vf - 1.5
    item_r.append(w); print('item %2d: test on-min %.3f off-max %.3f | gate z nonVF max %.3f probes max %.3f' % (i, s[t[teV] == 1].min(), s[t[teV] == 0].max(), z(XN).max(), z(XP).max()))
c = np.linalg.solve(Xtr.T @ Xtr + 1e-3 * np.trace(Xtr.T @ Xtr) / 1024 * np.eye(1024), Xtr.T @ np.ones(len(Xtr)))
print('CONST: VF sd %.4f nonVF sd %.4f probes sd %.4f' % ((XV @ c).std(), (XN @ c).std(), (XP @ c).std()))
res = pickle.load(open('data/fit_parse.pkl', 'rb'))
Yp = {i: [] for i in range(13)}
for p in range(600):
    for it in res[p]['items']: Yp[it['item']].append(PR.item_years(PR.ITEM_NAMES[it['item']], it['value']))
mus = [float(np.mean(Yp[i])) for i in range(13)]
place = {1: -2, 2: -1, 4: 0, 5: 1, 6: 2}
for k in (2, 4, 5, 6): val_r[k] = val_r[k] - val_r[(k, 'off')] * c
allowed = np.load('vec/s5_allowed.npy'); allowed[:, 1] = True
item_up = []
for i in range(13):
    nm = PR.ITEM_NAMES[i]
    if nm == 'crp': up = (PR.item_years('crp', 0.01) - mus[i]) * c
    elif nm == 'age': up = PR.item_years('age', 1.0) * (val_r[1] + 10 * val_r[2]) - mus[i] * c
    else: up = PR.item_years(nm, 1.0) * sum(10.0 ** place[k] * val_r[k] for k in place if allowed[i, k]) - mus[i] * c
    item_up.append(up)
crp_v = sum(10.0 ** place[k] * val_r[k] for k in place if allowed[6, k])
E = []
for r in np.where(teV)[0]:
    i = int(LV[r, 1]); nm = PR.ITEM_NAMES[i]
    if nm == 'crp': continue
    E.append((XV[r] @ item_up[i]) / (XV[r] @ c) - (PR.item_years(nm, LV[r, -1]) - mus[i]))
E = np.array(E); print('Y (non-CRP) test error: sd %.4f yr, max %.3f, per-prompt sum sd ~ %.3f' % (E.std(), np.abs(E).max(), E.std() * 3))
crpi = np.where(LV[:, 1] == 6)[0]; ec = XV[crpi] @ crp_v - LV[crpi, -1]; print('CRP value read err sd %.5f max %.4f' % (ec.std(), np.abs(ec).max()))
kt = 0.01 * 2.0 ** np.arange(12)
f = lambda v: PR.item_years('crp', v)
slopes = [(f(kt[j + 1]) - f(kt[j])) / (kt[j + 1] - kt[j]) for j in range(11)] + [(f(25.0) - f(kt[11])) / (25.0 - kt[11])]
np.savez('vec/s5b_fit.npz', item_r=np.stack(item_r), item_up=np.stack(item_up), vf10=vf, c10=c, mu=np.array(mus), crp_v=crp_v, kink_t=kt, kink_s=np.diff(np.r_[0.0, slopes]))
