import numpy as np
u = np.load('data/nat_usage.npz'); m = np.load('data/nat_moments.npz')
nact, nmean, hout, houtp = u['nact'], u['nmean'], u['hout'], u['hout_pr']
print('neurons: per layer, #neurons with max|act*down| < thr (over 165 prompts, all tokens)')
for L in range(28):
    a = nact[L]; med = np.median(a)
    print(L, 'median max %.3f' % med, ' <0.05: %d  <0.2: %d  <0.5: %d  <1: %d' % ((a < 0.05).sum(), (a < 0.2).sum(), (a < 0.5).sum(), (a < 1).sum()), 'min5', np.sort(a)[:5].round(3))
print('heads: mean output norm on probes (per token) normalized by layer median')
ntok = 1
for L in range(28):
    h = houtp[L]; print(L, (h / np.median(h)).round(2).tolist())
