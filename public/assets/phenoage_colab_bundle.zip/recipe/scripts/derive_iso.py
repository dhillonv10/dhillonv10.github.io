# VF_ISOLATE at L10: q-switch all heads at VF tokens toward the pos-0 key (slow planes); check mass on pos0 and bit cleanliness
import sys, os, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.attnprobe as AP
for m in (CO, FK, AP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); L = PARAMS.get('L', 10)
PG.install(reg, V, upto=PARAMS.get('upto', 'bits'))
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = set([15 + d for d in range(10)] + [220, 13])
cap = FK.Capture(model, [('in', L)]); qk = AP.QKCapture(model, [L])
VF, DG, OT, X0 = [], [], [], None
K0 = None
for pi in range(0, 600, 40):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); XH = cap[('in', L)]; X0 = XH[0].copy()
    K0 = qk.cap[('k', L)][0].numpy().copy()   # post-norm keys at pos0, [8,128]
    vfs = [it['vf'] for it in res[pi]['items']]
    VF.append(XH[vfs]); DG.append(XH[[t for t in range(58, ids.shape[1]) if int(ids[0, t]) in tokk]])
    OT.append(XH[[t for t in range(58, ids.shape[1]) if int(ids[0, t]) not in tokk and t not in vfs][::5]])
VF, DG, OT = map(np.concatenate, (VF, DG, OT))
Mn = np.load(WS + '/data/nat_moments.npz')['M_in'][L].astype(np.float64) + FK.second_moment(OT)
C = np.c_[VF.mean(0), DG.mean(0), X0]; Z = np.linalg.solve(Mn + 1e-6 * np.trace(Mn) / 1024 * np.eye(1024), C)
r = Z @ np.linalg.solve(C.T @ Z, np.array([1.0, 0.0, 0.0]))
print('iso read: VF min %.3f max %.3f | digit pins max %.3f | other max %.3f' % ((VF @ r).min(), (VF @ r).max(), np.abs(DG @ r).max(), np.abs(OT @ r).max()))
import isa.attn as AT; importlib.reload(AT)
gq = P[f'model.layers.{L}.self_attn.q_norm.weight'].double().numpy(); gk = P[f'model.layers.{L}.self_attn.k_norm.weight'].double().numpy()
Wq = P[f'model.layers.{L}.self_attn.q_proj.weight'].double().numpy(); Wk = P[f'model.layers.{L}.self_attn.k_proj.weight'].double().numpy()
qds, kd, mg = AT.pos_design_mass(gq, gk, [0], T=800, iters=2000); print('self design logit margin %.2f' % mg)
dq, dk = [], []
for g in range(8):
    Wkg = Wk[128 * g:128 * g + 128]
    kt = kd / np.linalg.norm(kd) * PARAMS.get('kmul', 10.0) * np.median(np.linalg.norm(Wkg @ VF.T, axis=0))
    dk.append(kt - Wkg @ VF.mean(0))
for h in range(16):
    Wqh = Wq[128 * h:128 * h + 128]
    qt = qds[0] / np.linalg.norm(qds[0]) * PARAMS.get('qmul', 10.0) * np.median(np.linalg.norm(Wqh @ VF.T, axis=0))
    dq.append(qt - Wqh @ VF.mean(0))
V.update(**{f'iso_dq_{L}': np.stack(dq), f'iso_dk_{L}': np.stack(dk), f'iso_r_{L}': r})
import isa.prims as PRM
for g in range(8): PRM.keyswitch(reg, L, g, V[f'iso_dk_{L}'][g], r, owner=f'isok{L}_{g}')
for h in range(16): PRM.qswitch(reg, L, h, V[f'iso_dq_{L}'][h], r, owner=f'iso{L}_{h}')
m0 = np.zeros(16); n = 0
for pi in range(600, 750, 15):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    Pr = qk.probs(L, T).numpy()
    for it in res[pi]['items']: m0 += Pr[:, it['vf'], it['vf']]; n += 1
print('SELF mass at VF tokens per head:', (m0 / n).round(4).tolist())
cap.remove(); qk.remove()
old = dict(np.load(WS + '/vec/s5iso.npz')) if os.path.exists(WS + '/vec/s5iso.npz') else {}
old = {k: v for k, v in old.items() if not k.startswith('iso_') or k.endswith(('_10', '_11')) and not k.endswith(f'_{L}')}
old.update(**{f'iso_dq_{L}': np.stack(dq), f'iso_dk_{L}': np.stack(dk), f'iso_r_{L}': r}); np.savez(WS + '/vec/s5iso.npz', **old)
exec(open(WS + '/scripts/k_cleanup.py').read())
