# S7 v2: GATED_Z (L12) + PWL EMIT (L13). Logit vectors u_d by an active-set least-squares on the lm_head; L13 reads
# rz13/ri13 = e_z/gamma, e_i/gamma scaled so ri13 ~ 1 at the answer positions; amplitude relative to |x27|; then
# generate on held-out practice (pids 600-749).
import sys, importlib, numpy as np, re
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR, isa.fitk as FK
for m in (CO, PR, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
W = model.lm_head.weight.detach().double(); gf = model.model.norm.weight.detach().double()
dig = [tok.convert_tokens_to_ids(str(d)) for d in range(10)]; eos = tok.convert_tokens_to_ids('<|im_end|>')
targets = dig + [eos]; C = list(targets)
def solve(C):
    Wc = W[C] * gf[None]; G = Wc @ Wc.T + 1e-6 * torch.eye(len(C), dtype=torch.float64)
    T = torch.zeros(len(C), len(targets), dtype=torch.float64)
    for j in range(len(targets)): T[j, j] = 1.0
    return Wc.T @ torch.linalg.solve(G, T)
for it in range(8):
    U = solve(C); Lg = W @ (gf[:, None] * U); bad = set()
    for j in range(len(targets)):
        col = Lg[:, j].clone(); col[targets[j]] = -1e9
        bad |= {t for t in torch.topk(col, 50).indices.tolist() if Lg[t, j] > 0.05}
    new = [t for t in bad if t not in C]
    if not new: break
    C += new
U = U.numpy().T; un = np.linalg.norm(U, axis=1); del W, Lg
print('lm_head active set %d, |u| median %.4f' % (len(C), np.median(un[:10])))
reg = CO.Registry(P); PG.install(reg, V, upto='emit_z')
g13 = P['model.layers.13.post_attention_layernorm.weight'].double().numpy()
cap = FK.Capture(model, [('pa', 13), ('out', 27)]); cap27 = FK.Capture(model, [('out', 27)], raw=True)
rows = []; n27 = []
for pi in range(600, 750, 10):
    its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(its); yi = int(np.clip(np.floor(y + 0.5), 0, 99))
    ids = tok(FIT_PROMPTS[pi] + f'{yi // 10}{yi % 10}', return_tensors='pt').input_ids
    cap.run(ids); X = cap[('pa', 13)]
    cap27.run(ids); n27 += list(np.linalg.norm(cap27[('out', 27)][-3:-1], axis=1))
    for j, pos in enumerate((-3, -2)):
        rows.append((j, float(X[pos] @ (V['e_z'][j] / g13)), float(X[pos] @ (V['e_i'][j] / g13)), (y + 0.5) / 10 - 0.5 if j == 0 else y - 10 * (yi // 10)))
    del X
cap.remove(); cap27.remove(); reg.restore()
R = np.array(rows); s0 = [R[R[:, 0] == j, 2].mean() for j in (0, 1)]
# ANSWER-ZERO CONST c0 (fit on the installed states at L13 pa): 0 at ANS1/ANS2, 1 at ANS3 and every other token
reg = CO.Registry(P); PG.install(reg, V, upto='emit_z')
cap = FK.Capture(model, [('pa', 13)]); XA, XN = [], []; rng = np.random.default_rng(5)
for pi in range(0, 600, 12):
    its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(its); yi = int(np.clip(np.floor(y + 0.5), 0, 99))
    ids = tok(FIT_PROMPTS[pi] + f'{yi // 10}{yi % 10}', return_tensors='pt').input_ids; cap.run(ids); X = cap[('pa', 13)]
    XA += [X[-3].copy(), X[-2].copy()]; XN += [X[-1].copy()] + [X[t].copy() for t in rng.choice(np.arange(1, ids.shape[1] - 3), 20, replace=False)]
    del X
cap.remove(); reg.restore()
XA = np.array(XA); XN = np.array(XN); XPb = np.load(WS + '/data/probe_rows.npz')['pa13'].astype(np.float64)[::2]
Xc = np.r_[XA, XN, XPb]; tc = np.r_[np.zeros(len(XA)), np.ones(len(XN) + len(XPb))]
Ac = Xc.T @ Xc; Ac += 1e-4 * np.trace(Ac) / 1024 * np.eye(1024)
c0 = np.linalg.solve(Ac, Xc.T @ tc)
print('c0: answers |.| max %.5f sd %.5f | other prompt tokens min %.3f | probes min %.3f' % (np.abs(XA @ c0).max(), (XA @ c0).std(), (XN @ c0).min(), (XPb @ c0).min()))
for j in (0, 1):
    m = R[:, 0] == j; z = R[m, 1] / R[m, 2]
    print('ANS%d: ri %.4f +- %.4f | z = rz/ri err vs target: mean %+.3f sd %.3f max %.3f' % (j + 1, R[m, 2].mean(), R[m, 2].std(), (z - R[m, 3]).mean(), (z - R[m, 3]).std(), np.abs(z - R[m, 3]).max()))
x27 = float(np.median(n27)); E = PARAMS.get('Emul', 5.0) * x27 / np.median(un[:10])
c13 = np.load(WS + '/vec/s7_fit_L13c.npz')['c13']
V7 = dict(rz13=np.stack([V['e_z'][j] / g13 / s0[j] for j in (0, 1)]), ri13=np.stack([V['e_i'][j] / g13 / s0[j] for j in (0, 1)]), c13=c13, em_u=U, kapE=np.float64(PARAMS.get('kapE', 50.0)),
          kapS=np.float64(PARAMS.get('kapS', 100.0)), emK=np.float64(PARAMS.get('emK', 4000.0)), c0=c0, Escale=np.float64(E), Aeos=np.float64(PARAMS.get('Aeos', 0.0)))
print('|x27| median %.0f -> Escale %.1f' % (x27, E))
for t in (0, 1):
    gmax = lambda X: np.max([V7['kapE'] * (X @ V7['rz13'][t] - j * (X @ V7['ri13'][t])) for j in range(10)], 0) - V7['emK'] * (X @ c0)
    print('ANS%d guard: max kink gate off-answer: prompt tokens %.1f probes %.1f | guard shift at answers (z units) max %.4f' % (t + 1, gmax(XN).max(), gmax(XPb).max(), (V7['emK'] * np.abs(XA[t::2] @ c0) / V7['kapE']).max()))
np.savez(WS + '/vec/s7.npz', **V7); V.update(V7)
reg = CO.Registry(P); PG.install(reg, V)
errs = []; outs = []
for pi in range(600, 750, PARAMS.get('step', 5)):
    items = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(items); g = generate(FIT_PROMPTS[pi])
    m = re.search(r'-?\d+(\.\d+)?', g); v = float(m.group()) if m else 45.0
    errs.append(abs(v - y)); outs.append((pi, round(y, 1), repr(g)))
print('held-out generate MAE %.3f over %d prompts (median %.2f, max %.2f)' % (np.mean(errs), len(errs), np.median(errs), np.max(errs)))
for o in outs[:10]: print(o)
exec(open(WS + '/scripts/k_cleanup.py').read())
