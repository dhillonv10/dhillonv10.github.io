import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prims as PRM, isa.proxy_probes as PP, isa.attnprobe as AP
for m in (CO, PRM, PP, AP): importlib.reload(m)
reg = CO.Registry(P)
det = np.load(WS + '/vec/flag_det_L3.npy'); rr, bb = det[:1024], det[1024]
c3 = np.load(WS + '/vec/const_L3pa.npy'); Q = np.load(WS + '/vec/quiet_L4_10b.npy').astype(np.float64); eA = Q[0]
eF = Q[1]
th, kap, Aamp = 0.6, 200.0, PARAMS.get('Aamp', 40.0)
PRM.step(reg, 3, (2761, 78), kap * (rr + (bb - th) * c3), c3, c3, Aamp * eA, A=10.0, owner='flag_anchor')
Lm = model.model.layers
HL = PARAMS.get('L', 9); GRP = PARAMS.get('g', 7); CH = PARAMS.get('ch', 62)
g9 = P[f'model.layers.{HL}.input_layernorm.weight'].double().numpy()
cap = {}
h1 = Lm[HL].input_layernorm.register_forward_pre_hook(lambda m, i: cap.__setitem__('in9', i[0][0].detach().double()))
h2 = Lm[HL].post_attention_layernorm.register_forward_pre_hook(lambda m, i: cap.__setitem__('pa9', i[0][0].detach().double()))
def xh(x, g): return (g * x / np.sqrt((x ** 2).mean(-1, keepdims=True) + 1e-6))
try:
    with torch.no_grad(): model(tok(FIT_PROMPTS[0], return_tensors='pt').input_ids)
    X = cap['in9'].numpy(); XH = xh(X, g9)
    rms49 = np.sqrt((X[49] ** 2).mean())
    rt = (eA / g9) / (eA @ X[49] / rms49)
    x0h = XH[0]; rt = rt - (rt @ x0h) / (x0h @ x0h) * x0h; rt = rt / (rt @ XH[49])
    if PARAMS.get('minvar', 1):
        Mn = np.load(WS + '/data/nat_moments.npz', mmap_mode='r')['M_in'][HL].astype(np.float64)
        Mn = Mn + 1e-6 * np.trace(Mn) / 1024 * np.eye(1024)
        Cm = np.c_[XH[49], x0h]; Z = np.linalg.solve(Mn, Cm)
        rt = Z @ np.linalg.solve(Cm.T @ Z, np.array([1.0, 0.0]))
        print('minvar read: rt.x49 %.3f rt.x0 %.2e, predicted sd %.4f' % (rt @ XH[49], rt @ x0h, np.sqrt(rt @ Mn @ rt)))
    print('rt.x0h after projection', rt @ x0h)
    print('rt.xh49', rt @ XH[49], 'eA raw at 49 %.2f, |x49| %.1f, rt at other prefix tokens max %.4f' % (eA @ X[49], np.linalg.norm(X[49]), np.abs(XH[1:49] @ rt).max()))
    # background on probes (no anchor there) with anchor installed
    probes = PP.build(tok, FIT_PROMPTS)
    bg = []
    for kind, p in probes:
        with torch.no_grad(): model(tok(p, return_tensors='pt').input_ids)
        bg.append(np.abs(xh(cap['in9'].numpy(), g9)[1:] @ rt).max())
    bg = np.array(bg); print('rt background on probes: max %.4f median %.4f' % (bg.max(), np.median(bg)))
    # key switch + vtake
    Wk = P[f'model.layers.{HL}.self_attn.k_proj.weight'][128*GRP:128*GRP+128].double().numpy()
    delta = Wk @ XH[0] * PARAMS.get('kscale', 1.0) - Wk @ XH[49]
    PRM.keyswitch(reg, HL, GRP, delta, rt, owner='flag_key')
    M = PARAMS.get('M', 40.0)
    PRM.vtake(reg, HL, GRP, CH, rt, {2*GRP: M * eF, 2*GRP+1: M * eF}, owner='flag_vtake')
    # measure F (raw along eF at L9 MLP input) on practice prompts and probes
    fmin = []; fpost = []
    for pi in range(0, 750, 15):
        ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids
        with torch.no_grad(): model(ids)
        f = cap['pa9'].numpy() @ eF / M
        fmin.append(f[50:].min()); fpost.append(f[50:].mean())
    fpr = []
    for kind, p in probes:
        with torch.no_grad(): model(tok(p, return_tensors='pt').input_ids)
        fpr.append(np.abs(cap['pa9'].numpy()[1:] @ eF / M).max())
    fmin = np.array(fmin); fpr = np.array(fpr)
    print('F on PhenoAge (t>=50): min %.4f  mean-of-mins %.4f  mean %.4f' % (fmin.min(), fmin.mean(), np.mean(fpost)))
    print('F off (probes): max %.4f  median %.4f  argmax probe %d' % (fpr.max(), np.median(fpr), fpr.argmax()))
    print('nat eF background check: pa9 eF raw on PhenoAge prompt before t<49:', np.abs(cap['pa9'].numpy()[1:49] @ eF / M).max() if False else '')
finally:
    h1.remove(); h2.remove()
print(CO.Registry.footprint(reg)[1])
import isa.se as SE; importlib.reload(SE)
if PARAMS.get('se', 0):
    SE.se_local(model, tok, FIT_PROMPTS)
    if PARAMS.get('se_vonly', 0):
        reg.restore(); reg2 = CO.Registry(P)
        PRM.step(reg2, 3, (2761, 78), kap * (rr + (bb - th) * c3), c3, c3, Aamp * eA, A=10.0, owner='flag_anchor')
        PRM.vtake(reg2, HL, GRP, CH, rt, {2*GRP: M * eF, 2*GRP+1: M * eF}, owner='flag_vtake')
        print('vtake only:'); SE.se_local(model, tok, FIT_PROMPTS)
