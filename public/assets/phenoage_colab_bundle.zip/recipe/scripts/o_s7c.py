# offline: EMIT reads at L13 pa for the PWL emission: isA12 (ANS1 or ANS2), isA3, zr (z1 at ANS1, z2 at ANS2), c13.
# Run outside the server.  usage: o_s7c.py [Lr] [lamz]
import numpy as np, sys
Lr = int(sys.argv[1]) if len(sys.argv) > 1 else 13
lamz = float(sys.argv[2]) if len(sys.argv) > 2 else 1e-4
d = np.load(f'data/ans_l{Lr}.npz'); X = d['X'].astype(np.float64); LAB = d['LAB']; XO = d['XO'].astype(np.float64)
XP = np.load('data/probe_rows.npz')[f'pa{Lr}'].astype(np.float64)
# rows are xhat (gamma applied) as captured by isa.fitk.Capture
pi, k, y, T, U = LAB[:, 0], LAB[:, 1].astype(int), LAB[:, 2], LAB[:, 3], LAB[:, 4]
tr = (pi < 600) | (pi >= 1030); te = ~tr
trO = np.arange(len(XO)) % 4 != 0; trP = np.arange(len(XP)) % 4 != 0
Xall = np.r_[X[tr], XO[trO], XP[trP]]
A = Xall.T @ Xall; A += 1e-5 * np.trace(A) / 1024 * np.eye(1024)
out = {}
for nm, sel in [('isA12', lambda kk: (kk <= 1)), ('isA3', lambda kk: kk == 2)]:
    t = np.r_[sel(k[tr]).astype(float), np.zeros(trO.sum() + trP.sum())]
    w = np.linalg.solve(A, Xall.T @ t); s = X[te] @ w; on = sel(k[te])
    print('%s: on test min %.4f max %.4f sd %.4f | other answer pos |max| %.4f | other tokens max %.4f | probes max %.4f' % (
        nm, s[on].min(), s[on].max(), s[on].std(), np.abs(s[~on]).max(), (XO[~trO] @ w).max(), (XP[~trP] @ w).max()))
    out[nm] = w
z = np.where(k == 0, (y + 0.5) / 10 - 0.5, y - 10 * T)
m = k <= 1
for lam in [1e-6, 1e-5, 1e-4, 1e-3]:
    Aj = X[m & tr].T @ X[m & tr]; Aj += lam * np.trace(Aj) / 1024 * np.eye(1024)
    w = np.linalg.solve(Aj, X[m & tr].T @ z[m & tr]); e = X[m & te] @ w - z[m & te]
    e1 = e[k[m & te] == 0]; e2 = e[k[m & te] == 1]
    print('zr lam %g: test err sd tens-z %.4f (max %.3f) units-z %.4f (max %.3f) | train sd %.4f | XO |z| p99 %.1f max %.1f, probes max %.1f' % (
        lam, e1.std(), np.abs(e1).max(), e2.std(), np.abs(e2).max(), (X[m & tr] @ w - z[m & tr]).std(),
        np.percentile(np.abs(XO @ w), 99), np.abs(XO @ w).max(), np.abs(XP @ w).max()))
    if lam == lamz: out['zr'] = w
# digit decisions
w = out['zr']; s = X[m & te] @ w
dec = np.clip(np.round(s), 0, 9); tgt = np.where(k[m & te] == 0, T[m & te], U[m & te])
print('digit decisions wrong: %d / %d' % ((dec != tgt).sum(), len(tgt)))
c = np.linalg.solve(Xall.T @ Xall + 1e-3 * np.trace(Xall.T @ Xall) / 1024 * np.eye(1024), Xall.T @ np.ones(len(Xall)))
print('CONST: answer %.4f+-%.4f other %.4f+-%.4f probes %.4f+-%.4f' % ((X @ c).mean(), (X @ c).std(), (XO @ c).mean(), (XO @ c).std(), (XP @ c).mean(), (XP @ c).std()))
out['c13'] = c
np.savez(f'vec/s7_fit_L{Lr}c.npz', **out)
print('saved')
