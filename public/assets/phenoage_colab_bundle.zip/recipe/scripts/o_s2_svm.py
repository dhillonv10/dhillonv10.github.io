# offline: direct linear SVM for the conjunction (digit d AND on-prompt) at L5 pa; negatives = other on-prompt tokens + all probe tokens
import os
os.environ['OMP_NUM_THREADS'] = '2'; os.environ['OPENBLAS_NUM_THREADS'] = '2'
import numpy as np, sys
from sklearn.svm import LinearSVC
LAY = int(sys.argv[2]) if len(sys.argv) > 2 else 5
d = np.load(f'data/s2L{LAY}_pa{LAY}.npz' if LAY != 5 else 'data/s2_pa5.npz'); X = d['X'].astype(np.float32); meta = d['meta']
XP = np.load(f'data/s2L{LAY}_probes_pa{LAY}.npy' if LAY != 5 else 'data/s2_probes_pa5.npy').astype(np.float32)
pi, t, tid = meta[:, 0], meta[:, 1], meta[:, 2]
keep = t >= 58; X, pi, t, tid = X[keep], pi[keep], t[keep], tid[keep]
dig = np.where((tid >= 15) & (tid <= 24), tid - 15, -1); dig[tid == 220] = 10; dig[tid == 13] = 11
tr = pi < 600; te = ~tr
ptr = np.arange(len(XP)) % 3 != 0; pte = ~ptr
sc = 1.0 / np.median(np.linalg.norm(X, axis=1)) * 32
out = {}
for k in range(12):
    pos = X[tr & (dig == k)]; neg = np.r_[X[tr & (dig != k)][::2], XP[ptr]]
    Xt = np.r_[pos, neg] * sc; yt = np.r_[np.ones(len(pos)), -np.ones(len(neg))]
    clf = LinearSVC(C=PARAMS_C if (PARAMS_C := float(sys.argv[1]) if len(sys.argv) > 1 else 0.1) else 0.1, class_weight={1: 5, -1: 1}, max_iter=5000, dual=False)
    clf.fit(Xt, yt)
    w = clf.coef_[0] * sc; b = clf.intercept_[0]
    s_on = X[te & (dig == k)] @ w + b; s_off = X[te & (dig != k)] @ w + b; s_p = XP[pte] @ w + b; s_ptr = XP[ptr] @ w + b
    print(k, 'test on-min %.3f | on-prompt off-max %.3f | probes(test) max %.3f (train %.3f) | errs %d' % (s_on.min(), s_off.max(), s_p.max(), s_ptr.max(), (s_on < 0).sum() + (s_off > 0).sum() + (s_p > 0).sum()), flush=True)
    out[f'w{k}'] = w; out[f'b{k}'] = b
c = np.linalg.solve(np.r_[X[::3], XP[::3]].T @ np.r_[X[::3], XP[::3]] + 1e-3 * np.eye(1024) * 30, np.r_[X[::3], XP[::3]].T @ np.ones(len(X[::3]) + len(XP[::3])))
print('CONST sd on-prompt %.4f probes %.4f' % ((X @ c).std(), (XP @ c).std()))
out['c5'] = c
sys.path.insert(0, '.')
from isa.fitk import minvar_read
G = np.load('data/gammas.npz'); g = G['G_po'][LAY]; V1 = np.load('vec/s1.npz')
Mn = np.load('data/nat_moments.npz', mmap_mode='r')['M_pa'][LAY].astype(np.float64)
XPd = XP.astype(np.float64)
rFB = minvar_read(Mn + XPd.T @ XPd / len(XPd), g * V1['eFB'], zero=[g * V1['eF'], g * V1['eA']])
fo = X.astype(np.float64) @ rFB; rFB = rFB / np.median(fo)
print('FB read L%d: on min %.3f p1 %.3f | probes max %.3f' % (LAY, (X @ rFB).min(), np.percentile(X @ rFB, 1), np.abs(XPd @ rFB).max()))
out['rFB'] = rFB
np.savez(f'vec/s2_svm_L{LAY}.npz', **out)
