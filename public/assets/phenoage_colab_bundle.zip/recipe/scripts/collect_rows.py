# collect xhat rows at (side, L) on PhenoAge prompts (practice + synthetic): VF rows (all) + non-VF on-prompt rows
# (subsampled), with labels; saves data/rows_{tag}.npz. Memory-safe (copies only).
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS['upto'])
side, L = PARAMS['side'], PARAMS['L']
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = {**{15 + d: d for d in range(10)}, 220: 10, 13: 11}
pool = PR.item_value_pool(FIT_PROMPTS[:600]); rng = np.random.default_rng(PARAMS.get('seed', 3))
plist = [(pi, FIT_PROMPTS[pi], res[pi]) for pi in range(PARAMS.get('p0', 0), PARAMS.get('p1', 750), PARAMS.get('step', 1))]
for j in range(PARAMS.get('nsynth', 0)):
    sp, y, _ = PR.synth(FIT_PROMPTS[int(rng.integers(0, 600))], pool, rng); plist.append((1000 + j, sp, PR.parse(sp, tok)))
cap = FK.Capture(model, [(side, L)])
XV, LV, XN, LN = [], [], [], []
for pi, prm, pr in plist:
    ids = tok(prm, return_tensors='pt').input_ids; cap.run(ids); XH = cap[(side, L)]
    vfs = set()
    for it in pr['items']:
        vf = it['vf']; vfs.add(vf); offs = [tokk.get(int(ids[0, vf - k]), 12) for k in (1, 2, 4, 5, 6)]
        XV.append(XH[vf].astype(np.float32)); LV.append([pi, it['item']] + offs + [it['value']])
    cand = [t for t in range(58, ids.shape[1]) if t not in vfs]
    sel = rng.choice(cand, size=min(PARAMS.get('nneg', 15), len(cand)), replace=False)
    for t in sel:
        XN.append(XH[t].astype(np.float32)); LN.append([pi, t, int(ids[0, t]), int(int(ids[0, t]) in tokk)])
    del XH
cap.remove()
np.savez(WS + f'/data/rows_{PARAMS["tag"]}.npz', XV=np.stack(XV), LV=np.array(LV), XN=np.stack(XN), LN=np.array(LN))
print(len(XV), len(XN))
exec(open(WS + '/scripts/k_cleanup.py').read())
