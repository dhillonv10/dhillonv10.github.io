# offline: EMIT reads at L13 pa: type reads (ANS1/ANS2/ANS3), y read (ridge + low-rank), CONST
import numpy as np, sys
Lr = int(sys.argv[1]) if len(sys.argv) > 1 else 13
d = np.load(f'data/ans_l{Lr}.npz'); X = d['X'].astype(np.float64); LAB = d['LAB']; XO = d['XO'].astype(np.float64)
XP = np.load('data/probe_rows.npz')[f'pa{Lr}'].astype(np.float64)
pi, k, y, T, U, S = LAB[:, 0], LAB[:, 1].astype(int), LAB[:, 2], LAB[:, 3], LAB[:, 4], LAB[:, 5]
tr = (pi < 600) | (pi >= 1030); te = ~tr
trO = np.arange(len(XO)) % 4 != 0; trP = np.arange(len(XP)) % 4 != 0
Xall = np.r_[X[tr], XO[trO], XP[trP]]
A = Xall.T @ Xall; A += 1e-5 * np.trace(A) / 1024 * np.eye(1024)
out = {}
for j, nm in enumerate(['isA1', 'isA2', 'isA3']):
    t = np.r_[(k[tr] == j).astype(float), np.zeros(trO.sum() + trP.sum())]
    w = np.linalg.solve(A, Xall.T @ t); s = X[te] @ w
    print('%s: on-min %.3f | other answer pos max %.3f | other tokens max %.3f | probes max %.3f' % (nm, s[k[te] == j].min(), s[k[te] != j].max(), (XO[~trO] @ w).max(), (XP[~trP] @ w).max()))
    out[nm] = w
for j, nm in [(0, 'y1'), (1, 'y2')]:
    m = k == j
    tgt = y if j == 0 else y - 10 * T
    for lam in [1e-6, 1e-4, 1e-2]:
        Aj = X[m & tr].T @ X[m & tr]; Aj += lam * np.trace(Aj) / 1024 * np.eye(1024)
        w = np.linalg.solve(Aj, X[m & tr].T @ tgt[m & tr]); e = X[m & te] @ w - tgt[m & te]
        print('%s lam %g: test err sd %.3f yr, max %.3f | train sd %.3f' % (nm, lam, e.std(), np.abs(e).max(), (X[m & tr] @ w - tgt[m & tr]).std()))
    out[nm] = w
c = np.linalg.solve(Xall.T @ Xall + 1e-3 * np.trace(Xall.T @ Xall) / 1024 * np.eye(1024), Xall.T @ np.ones(len(Xall)))
print('CONST sd: answer %.4f other %.4f probes %.4f' % ((X @ c).std(), (XO @ c).std(), (XP @ c).std()))
out['c'] = c
np.savez(f'vec/s7_fit_L{Lr}.npz', **out)
