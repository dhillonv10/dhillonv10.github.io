# LOG_PWL v2: DESIGNED reads of the exact L10 channels (no ridge): rv11 = (e_v/gamma11)/k_v, rind11 = (e_ind/gamma11)/k_i,
# scaled on the CRP VF rows; guard kinkG*(rind11 - c11). Checks precision at the CRP VF token and the gate off-prompt.
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='arith')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
g11 = P['model.layers.11.post_attention_layernorm.weight'].double().numpy()
cap = FK.Capture(model, [('pa', 11)])
XC, TC, XN = [], [], []
rng = np.random.default_rng(0)
for pi in range(0, 600, 3):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); XH = cap[('pa', 11)]
    vfs = {it['vf']: it for it in res[pi]['items']}
    for t, it in vfs.items():
        if it['item'] == 6: XC.append(XH[t].copy()); TC.append(it['value'])
    if pi % 12 == 0:
        for t in rng.choice(np.arange(58, ids.shape[1]), 10, replace=False):
            if t not in vfs or vfs[t]['item'] != 6: XN.append(XH[t].copy())
    del XH
cap.remove()
XC = np.array(XC); TC = np.array(TC); XN = np.array(XN)
XP = np.load(WS + '/data/probe_rows.npz')['pa11'].astype(np.float64)
ri = V['e_ind'] / g11; ri = ri / (XC @ ri).mean()
rv = V['e_v'] / g11; k = np.polyfit(TC, XC @ rv, 1); rv = rv / k[0]
off = (XC @ rv - TC)
print('rind: CRP mean %.4f sd %.5f | prompt others |.| max %.4f | probes |.| max %.4f' % ((XC @ ri).mean(), (XC @ ri).std(), np.abs(XN @ ri).max(), np.abs(XP @ ri).max()))
print('rv: CRP err sd %.5f max %.4f (intercept %.4f) | prompt others |.| max %.4f | probes |.| max %.4f' % (off.std(), np.abs(off).max(), k[1] / k[0], np.abs(XN @ rv).max(), np.abs(XP @ rv).max()))
c11 = V['c11']; G = PARAMS.get('kinkG', 2000.0); kap = V['kapK']
gate_off = lambda X: max([(kap * (X @ rv - t * (X @ c11)) + G * (X @ ri - X @ c11)).max() for t in V['kink_t']])
print('max kink gate: prompt others %.1f probes %.1f | guard shift at CRP (mg/dL) max %.5f' % (gate_off(XN), gate_off(XP), (G * np.abs(XC @ ri - XC @ c11) / kap).max()))
V8 = dict(rv11=rv, c11=c11, rind11=ri, kinkG=np.float64(G))
np.savez(WS + '/vec/s5kinks.npz', **V8); V.update(V8)
PG.install_kinks(reg, V)
cap = FK.Capture(model, [('in', 12)], raw=True); rows = []
for pi in range(600, 750, 3):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); Xr = cap[('in', 12)]
    for it in res[pi]['items']:
        i = it['item']; rows.append((i, float(Xr[it['vf']] @ V['eY']), PR.item_years(PR.ITEM_NAMES[i], it['value']) - V['mu'][i]))
    del Xr
cap.remove()
rows = np.array(rows); m = rows[:, 0] == 6; e = rows[m, 1] / V['aY'] - rows[m, 2]
print('CRP Y err at L12 in: mean %+.3f sd %.3f max-dev %.3f' % (e.mean(), e.std(), np.abs(e - e.mean()).max()))
exec(open(WS + '/scripts/k_cleanup.py').read())
