# debug: z at L12 pa (reads) vs written channel ratio at L13 in / L13 pa (raw), ANS1/ANS2, full install
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR, isa.fitk as FK
for m in (CO, PR, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS.get('upto', 'emit_z'))
cap = FK.Capture(model, [('pa', 12)]); capr = FK.Capture(model, [('in', 13), ('pa', 13)], raw=True)
rows = []
for pi in range(600, 750, 10):
    its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(its); yi = int(np.clip(np.floor(y + 0.5), 0, 99))
    ids = tok(FIT_PROMPTS[pi] + f'{yi // 10}{yi % 10}', return_tensors='pt').input_ids
    cap.run(ids); capr.run(ids); X = cap[('pa', 12)]; A = capr[('in', 13)]; B = capr[('pa', 13)]
    for j, pos in enumerate((-3, -2)):
        zt = (y + 0.5) / 10 - 0.5 if j == 0 else y - 10 * (yi // 10)
        zr = V['z1r'] if j == 0 else V['z2r']; isA = V['isA1'] if j == 0 else V['isA2']
        rows.append((pi, j, zt, X[pos] @ zr, X[pos] @ isA, X[pos] @ V['cZ'], (A[pos] @ V['e_z'][j]) / (A[pos] @ V['e_i'][j]), (B[pos] @ V['e_z'][j]) / (B[pos] @ V['e_i'][j]), A[pos] @ V['e_i'][j], np.linalg.norm(A[pos])))
cap.remove(); capr.remove()
R = np.array(rows)
for r in R:
    if abs(r[3] - r[2]) > 0.3: print('outlier pi %d ANS%d target %.2f z %.2f' % (r[0], r[1] + 1, r[2], r[3]))
R = R[:, 1:]
for j in (0, 1):
    m = R[:, 0] == j
    print('ANS%d: L12pa z err sd %.3f | isA %.3f..%.3f | cZ %.4f..%.4f | L13in ratio err mean %+.3f sd %.3f | L13pa ratio err sd %.3f | e_i raw %.2f+-%.2f | |x13| %.0f' % (
        j + 1, (R[m, 2] - R[m, 1]).std(), R[m, 3].min(), R[m, 3].max(), R[m, 4].min(), R[m, 4].max(), (R[m, 5] - R[m, 1]).mean(), (R[m, 5] - R[m, 1]).std(), (R[m, 6] - R[m, 1]).std(), R[m, 7].mean(), R[m, 7].std(), R[m, 8].mean()))
exec(open(WS + '/scripts/k_cleanup.py').read())
