# offline: pool VTAKE channel choice (smallest natural importance) and the private answer direction ePD
import sys, numpy as np
sys.path.insert(0, '.')
import isa.quiet as QU
W = np.load('data/pool_w.npz'); Wv, Wo = W['Wv'], W['Wo']
Mx = np.load('data/nat_moments.npz')['M_in'][12].astype(np.float64)
imp = np.einsum('ci,ci->c', Wv @ Mx, Wv) * (np.linalg.norm(Wo[:, :128], axis=0) ** 2 + np.linalg.norm(Wo[:, 128:], axis=0) ** 2)
o = np.argsort(imp); print('lowest-importance channels', o[:6], (imp[o[:6]] / np.median(imp)).round(4))
V = {}
for s in ['s1', 's2', 's3', 's5', 's5arith']:
    d = np.load(f'vec/{s}.npz'); V.update({k: d[k] for k in d.files})
X0 = np.load('data/pos0_states.npy')
used = [V['eY'], V['e_v'], V['e_ind'], V['eP'], V['eV'], V['eANS'], V['e_ans2'], V['eA'], V['eF'], V['eFB']] + list(V['pin_e']) + list(V['u_items']) + list(V['bit_e']) + list(V['pads']) + [X0[L] for L in range(10, 16)]
ePD = QU.quiet_dirs([12, 13, 14], 1, side='in', exclude=used)[0][0]; ePD /= np.linalg.norm(ePD)
np.savez('vec/s6_ch.npz', vch=np.int64(o[0]), ePD=ePD)
print('saved ch', o[0])
