import numpy as np, sys
from scipy.optimize import linprog
d = np.load('data/s2_pa5.npz'); X = d['X'].astype(np.float64); meta = d['meta']
XP = np.load('data/s2_probes_pa5.npy').astype(np.float64)
V = np.load('vec/s1.npz'); rFB = V['rFB5']; S = np.load('vec/s2_svm.npz')
pi, t, tid = meta[:, 0], meta[:, 1], meta[:, 2]
keep = t >= 58; X, pi, t, tid = X[keep], pi[keep], t[keep], tid[keep]
dig = np.where((tid >= 15) & (tid <= 24), tid - 15, -1)
f_on = X @ rFB / 5.0; f_off = XP @ rFB / 5.0   # FB normalised so on ~ 1
print('FB on min %.3f off max %.3f' % (f_on.min(), np.abs(f_off).max()))
res = []
for k in range(10):
    w, b = S[f'w{k}'], S[f'b{k}']
    s_on = X @ w + b; s_p = XP @ w + b
    A = (dig == k)
    sets = [(s_on[A], f_on[A], +1), (s_on[~A], f_on[~A], -1), (s_p, f_off, -1)]
    rows = []
    for s, f, sg in sets:
        rows.append(np.c_[-sg * s, -sg * f, sg * np.ones(len(s)), np.ones(len(s))])
    rows = np.concatenate(rows)
    r = linprog([0, 0, 0, -1], A_ub=rows, b_ub=np.zeros(len(rows)), A_eq=[[1, 1, 0, 0]], b_eq=[1], bounds=[(0, None), (0, None), (None, None), (None, None)], method='highs')
    a_, b_, t_, m_ = r.x
    print(k, 'margin %.3f a %.3f b %.3f t %.3f' % (m_, a_, b_, t_))
    res.append((a_, b_, t_, m_))
np.save('vec/s2_lp2.npy', np.array(res))
