# collect L5 pa xhat (S1 installed) on PhenoAge prompts for digit detectors
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK
for m in (CO, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto=PARAMS.get('upto', 'fb'))
side, L = PARAMS.get('side', 'pa'), PARAMS.get('L', 5)
cap = FK.Capture(model, [(side, L)])
X = []; meta = []
for pi in range(0, 750, PARAMS.get('step', 5)):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids
    cap.run(ids); x = cap[(side, L)]
    X.append(x[50:].astype(np.float16))
    for t in range(50, ids.shape[1]): meta.append((pi, t, int(ids[0, t])))
cap.remove()
np.savez(WS + f'/data/{PARAMS.get("tag", "s2")}_{side}{L}.npz', X=np.concatenate(X), meta=np.array(meta, dtype=np.int32))
print(len(meta))
import isa.proxy_probes as PP; importlib.reload(PP)
probes = PP.build(tok, FIT_PROMPTS)
cap = FK.Capture(model, [(side, L)])
XP = []
for kind, p in probes:
    cap.run(tok(p, return_tensors='pt').input_ids); XP.append(cap[(side, L)][1:].astype(np.float16))
cap.remove()
np.save(WS + f'/data/{PARAMS.get("tag", "s2")}_probes_{side}{L}.npy', np.concatenate(XP))
exec(open(WS + '/scripts/k_cleanup.py').read())
