import os
os.environ['OMP_NUM_THREADS'] = '2'; os.environ['OPENBLAS_NUM_THREADS'] = '2'
import numpy as np
from sklearn.svm import LinearSVC
R = np.load('data/rows_pa9.npz'); XV = R['XV'].astype(np.float32); LV = R['LV']; XN = R['XN'].astype(np.float32)
XP = np.load('data/probe_rows.npz')['pa9'].astype(np.float32)
nv = np.linalg.norm(XV, axis=1); ok = nv > 0.8 * np.median(nv); XV, LV = XV[ok], LV[ok]
pi = LV[:, 0]; trV = (pi < 600) | (pi >= 1100); teV = ~trV; prac_te = (pi >= 600) & (pi < 750)
sc = 32.0 / np.median(np.linalg.norm(XV, axis=1))
F = np.load('vec/s5a_fit.npz'); vf = F['vf9']; c = F['c9']
out = {'vf9': vf, 'c9': c}; keys = []
for col, k in [(3, 2), (4, 4), (5, 5), (6, 6)]:
    y = LV[:, col].astype(int); val = np.where(y < 10, y, 0)
    for b in range(4):
        t = ((val >> b) & 1)
        if t[trV].sum() < 3: continue
        Xt = np.r_[XV[trV], XN[::2], XP[::2]] * sc; yt = np.r_[2 * t[trV] - 1, -np.ones(len(XN[::2]) + len(XP[::2]))]
        clf = LinearSVC(C=0.5, max_iter=20000, dual=False).fit(Xt, yt)
        w = clf.coef_[0] * sc; bb = clf.intercept_[0]
        s = XV @ w + bb
        e_tr = ((s[trV] > 0) != (t[trV] == 1)).sum(); e_te = ((s[teV] > 0) != (t[teV] == 1)).sum(); e_pr = ((s[prac_te] > 0) != (t[prac_te] == 1)).sum()
        print('off%d bit%d: train err %d, test err %d (practice test %d) | on-min %.3f off-max(VF) %.3f | nonVF max %.3f probes max %.3f' % (
            k, b, e_tr, e_te, e_pr, s[trV & (t == 1)].min(), s[trV & (t == 0)].max(), (XN @ w + bb).max(), (XP @ w + bb).max()), flush=True)
        # as soft bit: map score to [0,1]-ish: soft = 0.5 + 0.5*score (intercept via CONST)
        out[f'w{k}_{b}'] = 0.5 * w + (0.5 + 0.5 * bb) * c; keys.append((k, b))
out['keys'] = np.array(keys)
np.savez('vec/s5a_fit_svm.npz', **out)
