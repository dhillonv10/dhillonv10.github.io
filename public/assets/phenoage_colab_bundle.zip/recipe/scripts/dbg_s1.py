import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.proxy_probes as PP, isa.attnprobe as AP
for m in (CO, FK, PP, AP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='fb')
Lm = model.model.layers
cap = FK.Capture(model, [('pa', 4), ('in', 4)], raw=True)
qk = AP.QKCapture(model, [4])
ao = {}
hk = Lm[4].self_attn.o_proj.register_forward_hook(lambda m, i, o: ao.__setitem__('o', o.detach()[0].double().numpy()))
mo = {}
hm = Lm[4].mlp.register_forward_hook(lambda m, i, o: mo.__setitem__('o', o.detach()[0].double().numpy()))
gpa = P['model.layers.4.post_attention_layernorm.weight'].double().numpy()
def report(p, tag):
    ids = tok(p, return_tensors='pt').input_ids; T = ids.shape[1]
    cap.run(ids)
    X = cap[('pa', 4)]; XH = FK.xhat_np(X, gpa)
    Pr = qk.probs(4, T).numpy()
    alpha = Pr[6][:, [40, 41, 49]].sum(1) + Pr[7][:, [40, 41, 49]].sum(1) if T > 50 else np.zeros(T)
    Fraw = ao['o'] @ V['eF']; Fread = XH @ V['rF']; cread = XH @ V['c4']; fbraw = mo['o'] @ V['eFB']
    nrm = np.linalg.norm(X, axis=1)
    g = V['kapF'] * (Fread - V['thF'] * cread)
    sel = np.argsort(Fread[58:] if tag == 'on' else -np.abs(Fread[1:]))[:6] + (58 if tag == 'on' else 1)
    for t in sel:
        print(tag, t, repr(tok.decode([int(ids[0, t])])), 'alpha %.3f Fraw %.3f |x| %.1f Fread %.4f c %.3f gate %.1f FBraw %.3f' % (alpha[t] if T > 50 else 0, Fraw[t], nrm[t], Fread[t], cread[t], g[t], fbraw[t]))
report(FIT_PROMPTS[0], 'on'); report(FIT_PROMPTS[7], 'on')
probes = PP.build(tok, FIT_PROMPTS)
for i in [34, 40, 0, 70]: report(probes[i][1], 'off')
cap.remove(); qk.remove(); hk.remove(); hm.remove()
