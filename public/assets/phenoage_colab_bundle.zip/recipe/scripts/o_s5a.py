# offline: BITS stage fit at L9 pa: soft bit reads (VF target bit, non-VF on-prompt 0, probes 0), VF read, CONST; gate check
import numpy as np, sys
LAY = 9
R = np.load(f'data/rows_pa{LAY}.npz'); XV = R['XV'].astype(np.float64); LV = R['LV']; XN = R['XN'].astype(np.float64)
XP = np.load('data/probe_rows.npz')[f'pa{LAY}'].astype(np.float64)
nv = np.linalg.norm(XV, axis=1); okp = nv > 0.8 * np.median(nv)   # drop rows whose VF pin did not fire (7 synthetic rows)
XV, LV = XV[okp], LV[okp]
pi = LV[:, 0]; trV = (pi < 600) | (pi >= 1100); teV = ~trV
trN = np.arange(len(XN)) % 4 != 0; trP = np.arange(len(XP)) % 4 != 0
Xtr = np.r_[XV[trV], XN[trN], XP[trP]]
wts = np.r_[np.ones(trV.sum()) * 3, np.ones(trN.sum()), np.ones(trP.sum())]
A = (Xtr * wts[:, None]).T @ Xtr; A += 1e-5 * np.trace(A) / 1024 * np.eye(1024)
def fit(tV):
    t = np.r_[tV[trV], np.zeros(trN.sum()), np.zeros(trP.sum())]
    return np.linalg.solve(A, (Xtr * wts[:, None]).T @ t)
vf = fit(np.ones(len(XV)))
print('vf read: VF test min %.3f max %.3f | nonVF max %.3f | probes max %.3f' % ((XV[teV] @ vf).min(), (XV[teV] @ vf).max(), np.abs(XN @ vf).max(), np.abs(XP @ vf).max()))
c = np.linalg.solve(Xtr.T @ Xtr + 1e-3 * np.trace(Xtr.T @ Xtr) / 1024 * np.eye(1024), Xtr.T @ np.ones(len(Xtr)))
M = float(sys.argv[1]) if len(sys.argv) > 1 else 3.0
out = dict(vf9=vf, c9=c)
keys = []
for col, k in [(3, 2), (4, 4), (5, 5), (6, 6)]:
    y = LV[:, col].astype(int); val = np.where(y < 10, y, 0)
    for b in range(4):
        tb = ((val >> b) & 1).astype(float)
        if tb[trV].sum() < 3: continue
        w = fit(tb)
        z = lambda X: X @ w + M * (X @ vf) - (M + 0.5) * (X @ c)
        zV = z(XV[teV]); on = zV[tb[teV] == 1]; off = zV[tb[teV] == 0]
        print('off%d bit%d: VF test on-min %.3f off-max %.3f | nonVF max %.3f | probes max %.3f' % (k, b, on.min() if len(on) else 9, off.max(), z(XN).max(), z(XP).max()))
        out[f'w{k}_{b}'] = w; keys.append((k, b))
out['keys'] = np.array(keys)
np.savez('vec/s5a_fit.npz', **out)
# diagnostics: where do VF test errors occur
vfs = XV @ vf
bad = teV & (vfs < 0.8)
print('low vf test rows', bad.sum(), 'practice', (bad & (pi < 1000)).sum(), 'items', np.bincount(LV[bad, 1].astype(int), minlength=13))
w = out['w4_2']; y = LV[:, 4].astype(int); tb = ((np.where(y < 10, y, 0) >> 2) & 1)
zz = XV @ w + M * vfs - (M + 0.5) * (XV @ c)
err = teV & (((tb == 1) & (zz < 0)) | ((tb == 0) & (zz > 0)))
print('off4 bit2 errors', err.sum(), 'practice', (err & (pi < 1000)).sum(), 'items', np.bincount(LV[err, 1].astype(int), minlength=13), 'digits', np.bincount(y[err], minlength=13))
