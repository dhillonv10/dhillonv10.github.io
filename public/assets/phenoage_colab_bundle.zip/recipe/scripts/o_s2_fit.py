# offline: S2 digit capture at L5 pa (S1 installed): digit detectors + AND(FB) linear-separability LP per digit
import numpy as np, sys
sys.path.insert(0, '.')
from scipy.optimize import linprog
d = np.load('data/s2_pa5.npz'); X = d['X'].astype(np.float64); meta = d['meta']
XP = np.load('data/s2_probes_pa5.npy').astype(np.float64)
V = np.load('vec/s1.npz'); rFB = V['rFB5']
pi, t, tid = meta[:, 0], meta[:, 1], meta[:, 2]
keep = t >= 58; X, pi, t, tid = X[keep], pi[keep], t[keep], tid[keep]
f_on = X @ rFB; f_off = XP @ rFB
print('FB read on: min %.3f p1 %.3f med %.3f max %.3f | probes: max %.3f' % (f_on.min(), np.percentile(f_on, 1), np.median(f_on), f_on.max(), np.abs(f_off).max()))
dig = np.where((tid >= 15) & (tid <= 24), tid - 15, -1)
tr = pi < 600; te = ~tr
# detectors fitted on on-prompt rows AND probe rows (probe rows labelled by their own token ids)
dp = None
Y = np.stack([(dig == k).astype(float) for k in range(10)], 1)
mu = X[tr].mean(0); Xc = X[tr] - mu
A = Xc.T @ Xc; A += 1e-4 * np.trace(A) / 1024 * np.eye(1024)
W = np.linalg.solve(A, Xc.T @ (Y[tr] - Y[tr].mean(0))); b = Y[tr].mean(0) - mu @ W
S = X @ W + b; SP = XP @ W + b
res = {}
for k in range(10):
    on = (dig == k)
    s1, f1 = S[on & tr, k], f_on[on & tr]
    s2, f2 = S[~on & tr, k], f_on[~on & tr]
    s3, f3 = SP[:, k], f_off
    # LP: maximise m s.t. a*s+b*f-t >= m (on), <= -m (off sets); a+b=1, a,b>=0
    rows = np.r_[np.c_[-s1, -f1, np.ones(len(s1)), np.ones(len(s1))], np.c_[s2, f2, -np.ones(len(s2)), np.ones(len(s2))], np.c_[s3, f3, -np.ones(len(s3)), np.ones(len(s3))]]
    r = linprog([0, 0, 0, -1], A_ub=rows, b_ub=np.zeros(len(rows)), A_eq=[[1, 1, 0, 0]], b_eq=[1], bounds=[(0, None), (0, None), (None, None), (None, None)], method='highs')
    a_, b_, t_, m_ = r.x
    # test-set check
    on_te = a_ * S[on & te, k] + b_ * f_on[on & te] - t_; off_te = a_ * S[~on & te, k] + b_ * f_on[~on & te] - t_
    print(k, 'LP margin %.4f a %.3f b %.3f t %.3f | test on-min %.4f off-max %.4f' % (m_, a_, b_, t_, on_te.min(), off_te.max()))
    res[k] = (a_, b_, t_, m_)
np.savez('vec/s2_fit.npz', W=W, b=b, lp=np.array([res[k] for k in range(10)]))
