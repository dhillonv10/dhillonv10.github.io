# S7 (L12/L13): PWL one-hot EMIT (layer = phenoage_program.NEUR['emit'][0]). Logit vectors u_d / u_eos by an active-set least-squares on the lm_head (min-norm,
# exactly 1 on the target, 0 on every token of the active set); reads from vec/s7_fit_L13c.npz; amplitude set relative
# to the residual norm at L27 out at the answer positions; then generate on held-out practice.
import sys, importlib, numpy as np, re
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR, isa.fitk as FK
for m in (CO, PR, FK): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
Lr = PG.NEUR['emit'][0]
F = np.load(WS + f'/vec/s7_fit_L{Lr}d.npz')
W = model.lm_head.weight.detach().double()
gf = model.model.norm.weight.detach().double()
dig = [tok.convert_tokens_to_ids(str(d)) for d in range(10)]
eos = tok.convert_tokens_to_ids('<|im_end|>')
targets = dig + [eos]; C = list(targets)
def solve(C, tvec):
    Wc = W[C] * gf[None]
    G = Wc @ Wc.T + 1e-6 * torch.eye(len(C), dtype=torch.float64)
    return Wc.T @ torch.linalg.solve(G, tvec)
for it in range(8):
    T = torch.zeros(len(C), len(targets), dtype=torch.float64)
    for j in range(len(targets)): T[j, j] = 1.0
    U = solve(C, T); Lg = W @ (gf[:, None] * U)
    bad = set()
    for j in range(len(targets)):
        col = Lg[:, j].clone(); col[targets[j]] = -1e9
        bad |= {t for t in torch.topk(col, 50).indices.tolist() if Lg[t, j] > 0.05}
    new = [t for t in bad if t not in C]
    if not new: break
    C += new
mx = max(float(torch.max(torch.cat([Lg[:targets[j], j], Lg[targets[j] + 1:, j]]))) for j in range(len(targets)))
U = U.numpy().T                                     # [11, 1024]
un = np.linalg.norm(U, axis=1)
print('active set %d, max off-target logit per unit %.3f, |u| median %.4f' % (len(C), mx, np.median(un)))
# residual norm at L27 out at the answer positions (pipeline up to pool)
reg = CO.Registry(P); PG.install(reg, V, upto='pool')
cap = FK.Capture(model, [('out', 27)], raw=True); nrm = []
for pi in range(600, 750, 15):
    ids = tok(FIT_PROMPTS[pi] + '45', return_tensors='pt').input_ids; cap.run(ids)
    nrm += list(np.linalg.norm(cap[('out', 27)][-3:], axis=1))
cap.remove(); reg.restore()
x27 = float(np.median(nrm)); E = PARAMS.get('Emul', 5.0) * x27 / np.median(un[:10])
print('|x27| at answer positions: median %.1f (min %.1f max %.1f) -> Escale %.1f' % (x27, min(nrm), max(nrm), E))
V7 = dict(isA1=F['isA1'], isA2=F['isA2'], isA3=F['isA3'], z1r=F['z1r'], z2r=F['z2r'], c13=F['c13'], em_u=U,
          kapE=np.float64(PARAMS.get('kapE', 50.0)), kapS=np.float64(PARAMS.get('kapS', 50.0)), emM=np.float64(PARAMS.get('M', 30.0)),
          Escale=np.float64(E), Aeos=np.float64(PARAMS.get('Aeos', 0.0)))
np.savez(WS + '/vec/s7.npz', **V7)
V.update(V7)
reg = CO.Registry(P); PG.install(reg, V)
errs = []; outs = []
for pi in range(600, 750, PARAMS.get('step', 5)):
    items = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(items)
    g = generate(FIT_PROMPTS[pi])
    m = re.search(r'-?\d+(\.\d+)?', g); v = float(m.group()) if m else 45.0
    errs.append(abs(v - y)); outs.append((pi, round(y, 1), repr(g)))
print('held-out generate MAE %.3f over %d prompts' % (np.mean(errs), len(errs)))
for o in outs[:12]: print(o)
exec(open(WS + '/scripts/k_cleanup.py').read())
