import numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
np.savez(WS + '/data/qknorms.npz', q=np.stack([P[f'model.layers.{L}.self_attn.q_norm.weight'].numpy() for L in range(28)]), k=np.stack([P[f'model.layers.{L}.self_attn.k_norm.weight'].numpy() for L in range(28)]))
print(model.model.rotary_emb.inv_freq[:3], model.model.rotary_emb.inv_freq[-3:])
