# DERIVE CODE of the accepted edit (E3). Installs phenoage_program (a composition of isa/ calls) from the vector files in
# accepted_E3/vec (identical to vec/ at acceptance). Works on either base: if the live weights are the ORIGINAL model
# it installs from scratch; if they already contain the accepted edit (the server resets to the accepted state), it
# first removes the additive (DUAL) q/k deltas so that nothing is added twice. Every vector was derived by the
# scripts/derive_*.py and scripts/o_*.py files (closed-form fits; no gradient descent).
import sys, importlib, numpy as np, torch
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prims as PRM
for m in (CO, PRM): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(PG.ACCEPTED)
# detect the base: an EMIT neuron's gate row is a pure 'set' slice; if it already equals the program's row, the live
# weights contain the accepted edit
L, nn = PG.NEUR['emit']
probe = CO.Registry({k: v.clone() for k, v in P.items() if k == CO.pname(L, 'gate') or k == CO.pname(L, 'up') or k == CO.pname(L, 'down')})
PG.install_emit(probe, V)
has_edit = torch.allclose(probe.P[CO.pname(L, 'gate')][nn[0]], P[CO.pname(L, 'gate')][nn[0]])
del probe
reg = CO.Registry(P)
PG.install(reg, V, base=PG.ACCEPTED if has_edit else None)
fp, own = reg.footprint()
print('base had accepted edit: %s | slices touched: %d | changed scalars this install: %d' % (has_edit, len(reg.orig), sum(fp.values())))
