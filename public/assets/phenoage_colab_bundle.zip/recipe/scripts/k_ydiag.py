import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='kinks')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
cap = FK.Capture(model, [('pa', 10), ('in', 11), ('in', 12)], raw=True)
g10 = P['model.layers.10.post_attention_layernorm.weight'].double().numpy()
rows = []
for pi in range(600, 750, 3):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids)
    a = cap[('pa', 10)]; b = cap[('in', 11)]; c = cap[('in', 12)]
    xh = FK.xhat_np(a, g10)
    for it in res[pi]['items']:
        i = it['item']; t = it['vf']
        up = xh[t] @ V['item_up'][i]; cc = xh[t] @ V['c10']
        rows.append([i, PR.item_years(PR.ITEM_NAMES[i], it['value']) - V['mu'][i], up, cc, (b[t] - a[t]) @ V['eY'], b[t] @ V['eY'], c[t] @ V['eY'], np.linalg.norm(a[t])])
    del a, b, c, xh
cap.remove()
np.save(WS + '/data/ydiag.npy', np.array(rows)); print('ok')
exec(open(WS + '/scripts/k_cleanup.py').read())
