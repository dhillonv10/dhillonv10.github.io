import os, re, collections
print(os.getcwd())
# formats
cnt = collections.Counter()
for p in FIT_PROMPTS:
    for m in re.finditer(r'([A-Z][A-Za-z \-]+?) \(([^)]*)\) (\d+\.\d+)', p):
        cnt[(m.group(1), m.group(2))] += 1
for k,v in sorted(cnt.items()): print(k, v)
q = collections.Counter(p.split('\n')[3] for p in FIT_PROMPTS)
print(q.most_common(3))
print(collections.Counter(len(tok(p).input_ids) for p in FIT_PROMPTS).most_common(5), max(len(tok(p).input_ids) for p in FIT_PROMPTS))
print(FIT_PROMPTS[5][300:1500])
