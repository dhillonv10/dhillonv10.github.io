# off-prompt leak of every DUAL switch: |delta| * |r.xhat| relative to the natural raw q/k norm, on proxy-probe tokens
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.fitk as FK, isa.proxy_probes as PP
for m in (FK, PP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
probes = PP.build(tok, FIT_PROMPTS)
sw = []   # (name, layer, kind, head/group, delta, read)
for g, d in zip(V['dk_groups'], V['dk']): sw.append(('shift_k%d' % g, 9, 'k', int(g), d, V['rP']))
for h, d in zip(V['dq_heads'], V['dq']): sw.append(('shift_q%d' % h, 9, 'q', int(h), d, V['rP'] if int(h) in PG.SHIFT['q_all'] else V['rV']))
for L in PG.ISO_LAYERS:
    if f'iso_dk_{L}' in V:
        for g in range(8): sw.append(('iso%d_k%d' % (L, g), L, 'k', g, V[f'iso_dk_{L}'][g], V[f'iso_r_{L}']))
        for h in range(16): sw.append(('iso%d_q%d' % (L, h), L, 'q', h, V[f'iso_dq_{L}'][h], V[f'iso_r_{L}']))
if 'pool_dk' in V:
    sw.append(('pool_k', PG.POOL['L'], 'k', 0, V['pool_dk'], V['pool_rk'])); sw.append(('pool_q', PG.POOL['L'], 'q', 0, V['pool_dq'], V['pool_rq']))
sw.append(('flag_k', 4, 'k', 3, V['kdelta'], V['rt']))
layers = sorted(set(s[1] for s in sw))
cap = FK.Capture(model, [('in', L) for L in layers])
stats = {s[0]: [] for s in sw}
for kind, p in probes[::2]:
    cap.run(tok(p, return_tensors='pt').input_ids)
    for name, L, kd, idx, d, r in sw:
        X = cap[('in', L)][1:]
        W = P[f'model.layers.{L}.self_attn.{kd}_proj.weight'][128 * idx:128 * idx + 128].double().numpy()
        nat = np.linalg.norm(X @ W.T, axis=1); leak = np.abs(X @ r) * np.linalg.norm(d)
        stats[name].append((leak / nat).max())
cap.remove()
for name in stats: print(name, 'max rel leak %.4f' % max(stats[name]))
exec(open(WS + '/scripts/k_cleanup.py').read())
