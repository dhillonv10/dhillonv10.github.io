cfg = model.config
print({k: getattr(cfg, k) for k in ['num_hidden_layers','hidden_size','num_attention_heads','num_key_value_heads','head_dim','intermediate_size','rms_norm_eps','max_position_embeddings','tie_word_embeddings']})
print(getattr(cfg,'rope_scaling',None), getattr(cfg,'rope_parameters',None))
import numpy as np
for L in [0,1,2,5,10,15,20,25,27]:
    g1 = P[f'model.layers.{L}.input_layernorm.weight'].numpy(); g2 = P[f'model.layers.{L}.post_attention_layernorm.weight'].numpy()
    qn = P[f'model.layers.{L}.self_attn.q_norm.weight'].numpy(); kn = P[f'model.layers.{L}.self_attn.k_norm.weight'].numpy()
    print(L, 'in', np.percentile(np.abs(g1),[0,1,10,50,90,100]).round(3), 'post', np.percentile(np.abs(g2),[0,1,50,100]).round(3), 'qn', np.percentile(qn,[0,50,100]).round(2), 'kn', np.percentile(kn,[0,50,100]).round(2))
gf = P['model.norm.weight'].numpy(); print('final', np.percentile(np.abs(gf),[0,1,10,50,90,100]).round(3))
print(model.model.layers[0].self_attn.__class__, model.config._attn_implementation)
ids = tok(FIT_PROMPTS[0], return_tensors='pt')
with torch.no_grad():
    hs = model(**ids, output_hidden_states=True).hidden_states
for L in range(0,29,3):
    h = hs[L][0]
    n = h.norm(dim=-1)
    print(L, 'norm pos0 %.1f'%n[0], 'median %.1f'%n[1:].median(), 'max(non0) %.1f'%n[1:].max(), 'top dims', torch.topk(h[1:].abs().mean(0),3).indices.tolist(), torch.topk(h[1:].abs().mean(0),3).values.round().tolist())
