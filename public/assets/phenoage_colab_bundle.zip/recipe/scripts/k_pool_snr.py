# analysis: magnitude of the pooled Y signal at ANS1 vs the ANS1 state norm (pipeline up to pool)
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='pool')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
h = PG.POOL['heads'][0]; g = h // 2
Wo = P['model.layers.12.self_attn.o_proj.weight'].double().numpy()[:, 128 * h:128 * h + 128]
Wv = P['model.layers.12.self_attn.v_proj.weight'].double().numpy()[128 * g:128 * g + 128]
g12 = P['model.layers.12.input_layernorm.weight'].double().numpy()
d = Wo @ (Wv @ (g12 * V['eY']))
print('|OV eY| (per unit of eY in xhat) %.3f' % np.linalg.norm(d))
cap = FK.Capture(model, [('in', 12), ('pa', 12)], raw=True)
rows = []
for pi in range(600, 750, 6):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids)
    Xi = cap[('in', 12)]; Xp = cap[('pa', 12)]
    vfs = [it['vf'] for it in res[pi]['items']]
    its = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(its)
    nvf = np.linalg.norm(Xi[vfs], axis=1); yv = Xi[vfs] @ V['eY'] / V['aY']
    delta = Xp[-1] - Xi[-1]
    rows.append((y, nvf.mean(), np.linalg.norm(Xi[-1]), np.linalg.norm(delta), delta @ d / (d @ d), yv.sum()))
    del Xi, Xp
cap.remove()
R = np.array(rows)
print('VF |x| L12 in mean %.0f | ANS1 |x| %.0f | attn delta at ANS1 |.| %.1f' % (R[:, 1].mean(), R[:, 2].mean(), R[:, 3].mean()))
print('pooled coefficient along OV eY vs sum of item Y (yr): corr %.4f, slope %.5f' % (np.corrcoef(R[:, 4], R[:, 5])[0, 1], np.polyfit(R[:, 5], R[:, 4], 1)[0]))
print('per-year signal at ANS1 raw: %.4f  -> relative to |x_ANS1| %.2e' % (np.polyfit(R[:, 5], R[:, 4], 1)[0] * np.linalg.norm(d), np.polyfit(R[:, 5], R[:, 4], 1)[0] * np.linalg.norm(d) / R[:, 2].mean()))
print('true y vs item-sum corr %.4f' % np.corrcoef(R[:, 0], R[:, 5])[0, 1])
exec(open(WS + '/scripts/k_cleanup.py').read())
