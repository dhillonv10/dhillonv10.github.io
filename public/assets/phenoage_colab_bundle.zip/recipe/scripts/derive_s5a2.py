# BITS with ACCUMULATOR down-vectors: STEP(bit k,b) writes aA * sum_i W[i,k] * 2^b * f_i (exact per-item partial sums of
# years over offsets 2,4,5,6) into VF-quiet directions f_i; eY = VF-quiet direction with max POOL OV gain.
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR
for m in (CO, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
F = np.load(WS + '/vec/s5a_fit_svm.npz'); keys = [tuple(k) for k in F['keys']]
R = np.load(WS + '/data/rows_pa9.npz'); XV = R['XV'].astype(np.float64); LV = R['LV']
G = np.load(WS + '/data/gammas.npz'); g9 = G['G_po'][9]
Y = XV[LV[:, 0] < 600] / g9; C = np.cov(Y.T); C /= np.trace(C)
X0 = np.load(WS + '/data/pos0_states.npy')
prev = [V['eA'], V['eF'], V['eFB'], V['eP'], V['eV'], V['eANS']] + list(V['pin_e']) + list(V['u_items']) + [X0[L] for L in (9, 10, 11)]
E = np.linalg.qr(np.array(prev).T)[0]; Pp = np.eye(1024) - E @ E.T
w, Vv = np.linalg.eigh(Pp @ C @ Pp + 10 * E @ E.T)
Q = Vv[:, :120]                      # 120 VF-quiet directions
acc = Q[:, :13].T                    # f_i (item 6 = CRP unused: CRP digits get their own dirs)
crp_acc = Q[:, 120 - 3:].T if False else None
Lp, hp = PG.POOL['L'], PG.POOL['heads'][0]
gp = P[f'model.layers.{Lp}.input_layernorm.weight'].double().numpy()
OV = P[f'model.layers.{Lp}.self_attn.o_proj.weight'].double().numpy()[:, 128 * hp:128 * hp + 128] @ P[f'model.layers.{Lp}.self_attn.v_proj.weight'].double().numpy()[128 * (hp // 2):128 * (hp // 2) + 128] * gp[None]
crp_acc = Q[:, 13:16].T             # CRP digit accumulators for offsets 2, 4, 5 (digit units)
Qr = Q[:, 16:]
_, sv, Vt = np.linalg.svd(OV @ Qr, full_matrices=False)
eY = Qr @ Vt[0]; eY /= np.linalg.norm(eY)
print('eY: pool OV gain %.3f (unrestricted top was 2.38); VF sd %.5f' % (sv[0], np.sqrt(eY @ C @ eY)))
# NORM-PRESERVING BIT CODES: bit (k,b) writes s*(e_kb - pad_kb); one PAD STEP writes s*sum(pad_kb) at every VF token in
# the same MLP, so |write|^2 = 14 s^2 for every digit pattern (no rms modulation at the VF token).
nb = len(keys)
bit_e = Q[:, 16:16 + nb].T; pads = Q[:, 16 + nb:16 + 2 * nb].T
sk = PARAMS.get('sk', {'2': 150.0, '4': 250.0, '5': 600.0, '6': 600.0})
sv_ = np.array([sk[str(k)] for k, b in keys])
downs = [sv_[i] * (bit_e[i] - pads[i]) for i in range(nb)]
pad_down = (sv_[:, None] * pads).sum(0); s_ = 0.0
acc = None; crp_acc = None; Wik = np.zeros((13, 7)); aA = 0.0; aC = 0.0
Qr = Q[:, 16 + 2 * nb:]
_, sv, Vt = np.linalg.svd(OV @ Qr, full_matrices=False)
eY = Qr @ Vt[0]; eY /= np.linalg.norm(eY)
print('eY: pool OV gain %.3f; VF sd %.5f' % (sv[0], np.sqrt(eY @ C @ eY)))
if PARAMS.get('v3', 0):
    D3 = np.load(WS + '/vec/dirs_v3.npz'); bit_e = D3['bit_e'][:nb]; pads = D3['pads'][:nb]; eY = D3['eY']
    downs = [sv_[i] * (bit_e[i] - pads[i]) for i in range(nb)]; pad_down = (sv_[:, None] * pads).sum(0)
    extra = dict(e_v=D3['e_v'], e_ind=D3['e_ind'])
else:
    extra = {}
V5 = dict(**extra, bit_w=np.stack([F[f'w{k}_{b}'] for k, b in keys]), vf9=F['vf9'], c9=F['c9'], bit_down=np.stack(downs), bit_e=bit_e, pads=pads, pad_down=pad_down, bit_s=np.float64(s_),
          kapB=np.float64(PARAMS.get('kapB', 400.0)), bitM=np.float64(PARAMS.get('M', 5.0)), bit_keys=np.array(keys), eY=eY)
np.savez(WS + '/vec/s5.npz', **V5)
print('norms of bit downs', np.linalg.norm(V5['bit_down'], axis=1).round(1))
exec(open(WS + '/scripts/k_cleanup.py').read())
