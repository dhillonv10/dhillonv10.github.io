import sys, importlib
sys.path.insert(0, '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon')
import isa.prompts as PR; importlib.reload(PR)
import numpy as np, collections, pickle
res = [PR.parse(p, tok) for p in FIT_PROMPTS]
err = []
cnt = collections.Counter(); vfc = collections.Counter(); offc = collections.Counter()
for r, y in zip(res, FIT_Y):
    its = {PR.ITEM_NAMES[i['item']]: i['value'] for i in r['items']}
    cnt[len(r['items'])] += 1
    err.append(PR.phenoage(its) - y)
    for i in r['items']:
        vfc[(PR.ITEM_NAMES[i['item']], tok.decode([r['ids'][i['vf']]]))] += 1
        # digits contiguous single tokens?
        offc[(len(i['toks']), len(i['vstr']), i['vf'] - i['toks'][-1])] += 1
        prev = tok.decode([r['ids'][i['toks'][0]-1]])
        vfc[('prev', prev)] += 1
err = np.array(err); print('n items', cnt, 'formula err max', np.abs(err).max(), 'Y0', PR.Y0)
for k, v in sorted(vfc.items()): print(k, v)
print(offc)
pickle.dump(res, open(PR.WS + '/data/fit_parse.pkl', 'wb'))
