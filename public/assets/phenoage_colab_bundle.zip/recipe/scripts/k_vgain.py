import numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
L = 9
g = P[f'model.layers.{L}.input_layernorm.weight'].double().numpy()
Wv = P[f'model.layers.{L}.self_attn.v_proj.weight'].double().numpy()[:384]
Wo = P[f'model.layers.{L}.self_attn.o_proj.weight'].double().numpy()
# OV per head h in 0..4: Wo[:, 128h:128h+128] @ Wv[group rows]
OV = [Wo[:, 128 * h:128 * h + 128] @ Wv[128 * (h // 2):128 * (h // 2) + 128] * g[None] for h in range(5)]
D = np.load(WS + '/vec/s2_pin_dirs.npy')
for h in range(5):
    s = np.linalg.svd(OV[h], compute_uv=False)
    cur = np.linalg.norm(OV[h] @ D[1:13].T, axis=0)
    print('head', h, 'OV top sv', s[:3].round(2), 'median sv %.3f' % np.median(s[:128]), '| current codes gain', cur.round(3)[:6])
M = np.concatenate([o for o in OV], 0)   # stacked
U, S, Vt = np.linalg.svd(M, full_matrices=False)
np.save(WS + '/vec/s4_ov_topdirs.npy', Vt[:40])
print('stacked top sv', S[:12].round(2))
