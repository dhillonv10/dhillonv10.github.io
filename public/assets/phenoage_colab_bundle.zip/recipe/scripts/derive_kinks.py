# fit the CRP-value read at L11 pa (rv11) and CONST c11, install LOG_PWL kinks, check Y at L12 in for all items
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='arith')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
cap = FK.Capture(model, [('pa', 11)])
X, T, I = [], [], []
rng = np.random.default_rng(0)
for pi in range(0, 600, 4):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); XH = cap[('pa', 11)]
    vfs = {it['vf']: it for it in res[pi]['items']}
    for t, it in vfs.items():
        X.append(XH[t].copy()); T.append(it['value'] if it['item'] == 6 else 0.0); I.append(1.0 if it['item'] == 6 else 0.0)
    for t in rng.choice(np.arange(58, ids.shape[1]), 10, replace=False):
        if t not in vfs: X.append(XH[t].copy()); T.append(0.0); I.append(0.0)
    del XH
X = np.array(X); T = np.array(T); I = np.array(I)
# off-prompt negatives (proxy-probe rows at L11 pa, target 0): the reads must be ~0 off-prompt (they gate big kinks)
XPr = np.load(WS + '/data/probe_rows.npz')['pa11'].astype(np.float64); trP = np.arange(len(XPr)) % 3 != 0
wP = PARAMS.get('wP', 0.5)
X = np.r_[X, wP * XPr[trP]]; T = np.r_[T, np.zeros(trP.sum())]; I = np.r_[I, np.zeros(trP.sum())]
A = X.T @ X; A += 1e-6 * np.trace(A) / 1024 * np.eye(1024)
rv = np.linalg.solve(A, X.T @ T); e = X @ rv - T
crp = T > 0
print('rv11 fit: CRP rows err sd %.5f max %.4f | others max |.| %.4f' % (e[crp].std(), np.abs(e[crp]).max(), np.abs(X[~crp] @ rv).max()))
c11 = FK.fit_const(X)
ri = np.linalg.solve(A, X.T @ I); si = X @ ri
print('rind11: CRP min %.4f max %.4f | others max |.| %.5f' % (si[I == 1].min(), si[I == 1].max(), np.abs(si[I == 0]).max()))
print('held-out probes: rv11 |.| max %.4f | rind11 |.| max %.4f' % (np.abs(XPr[~trP] @ rv).max(), np.abs(XPr[~trP] @ ri).max()))
V8 = dict(rv11=rv, c11=c11, rind11=ri, kinkG=np.float64(PARAMS.get('kinkG', 600.0)))
np.savez(WS + '/vec/s5kinks.npz', **V8); V.update(V8)
PG.install_kinks(reg, V)
# check Y along eY at L12 in (raw) vs exact, held-out
cap.remove(); cap = FK.Capture(model, [('in', 12)], raw=True)
rows = []
for pi in range(600, 750, 3):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); Xr = cap[('in', 12)]
    for it in res[pi]['items']:
        i = it['item']; rows.append((i, float(Xr[it['vf']] @ V['eY']), PR.item_years(PR.ITEM_NAMES[i], it['value']) - V['mu'][i]))
    del Xr
cap.remove()
rows = np.array(rows)
for i in range(13):
    m = rows[:, 0] == i
    if m.sum(): e = rows[m, 1] / V['aY'] - rows[m, 2]; print('item %2d %-10s Y err: mean %+.3f sd %.3f max-dev %.3f' % (i, PR.ITEM_NAMES[i], e.mean(), e.std(), np.abs(e - e.mean()).max()))
exec(open(WS + '/scripts/k_cleanup.py').read())
