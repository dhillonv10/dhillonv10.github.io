# install the full program and generate on pids [a, b) step s; save per-prompt (pid, y, yhat, item values) for the
# offline error regression (G1'). PARAMS: a, b, step, tag
import sys, importlib, numpy as np, re, json
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR
for m in (CO, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V)
rows = []
for pi in range(PARAMS.get('a', 450), PARAMS.get('b', 600), PARAMS.get('step', 1)):
    items = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(items); g = generate(FIT_PROMPTS[pi])
    m = re.search(r'-?\d+(\.\d+)?', g); v = float(m.group()) if m else 45.0
    rows.append(dict(pi=pi, y=y, yhat=v, out=g[:8], items=items))
json.dump(rows, open(WS + f"/data/gen_{PARAMS.get('tag', 'cal')}.json", 'w'))
e = np.array([r['yhat'] - r['y'] for r in rows])
print('n %d MAE %.3f bias %+.3f median |e| %.2f frac>=3 %.3f MAE(|e|<20) %.3f' % (len(e), np.abs(e).mean(), e.mean(), np.median(np.abs(e)), (np.abs(e) >= 3).mean(), np.abs(e)[np.abs(e) < 20].mean()))
exec(open(WS + '/scripts/k_cleanup.py').read())
