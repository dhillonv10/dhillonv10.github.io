import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.proxy_probes as PP, isa.proxy_extra as PX
for m in (CO, PP, PX): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
prompts = [PP.chat(tok, u) for u in PX.EXTRA] + [PP.chat(tok, '\n'.join([q] + [f'{"ABCD"[j]}. {o}' for j, o in enumerate(opts)])) for q, opts in PP.MC[:20]]
def run():
    out = []
    with torch.no_grad():
        for p in prompts:
            out.append(torch.log_softmax(model(tok(p, return_tensors='pt').input_ids).logits[0, -1].float(), -1).numpy())
    return np.stack(out)
ref = run()
reg = CO.Registry(P)
for L, j in PARAMS['zero_neurons']: reg.set(CO.pname(L, 'down'), 1, j, np.zeros(1024), 'z')
new = run(); reg.restore()
p = np.exp(ref); kl = (p * (ref - new)).sum(1)
o = np.argsort(-kl)[:8]
for i in o: print('%.4f' % kl[i], repr(tok.decode(ref[i].argsort()[-2:][::-1])), '->', repr(tok.decode([new[i].argmax()])), PX.EXTRA[i][:60] if i < len(PX.EXTRA) else 'MC-noletter %d' % (i - len(PX.EXTRA)))
np.save(WS + '/data/extra_ref.npy', ref.astype(np.float32))
