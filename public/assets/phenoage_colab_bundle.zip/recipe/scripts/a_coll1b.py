import numpy as np
d = np.load('data/coll1.npz'); g = np.load('data/gammas.npz')
meta = d['meta']; LAY = d['lay']
pi, cat, lab, item = meta[:, 0], meta[:, 2], meta[:, 3], meta[:, 5]
tr = pi < 600; te = ~tr
def xhat(h, gam):
    h = h.astype(np.float64); return gam * h / np.sqrt((h ** 2).mean(1, keepdims=True) + 1e-6)
def ridge(X, Y, lam):
    mu = X.mean(0); Xc = X - mu; A = Xc.T @ Xc + lam * np.trace(Xc.T @ Xc) / X.shape[1] * np.eye(X.shape[1])
    W = np.linalg.solve(A, Xc.T @ (Y - Y.mean(0))); b = Y.mean(0) - mu @ W; return W, b
for L in LAY:
    X = xhat(d[f'h{L}'], g['G_in'][L])
    m = cat == 2
    Yt = (lab[m][:, None] >= np.arange(1, 10)[None]).astype(float)
    for lam in [1e-4, 1e-3, 1e-2]:
        W, b = ridge(X[m & tr], Yt[tr[m]], lam)
        P_ = X[m & te] @ W + b; err = np.abs(P_ - Yt[te[m]])
        dv = P_.sum(1) - lab[m & te]
        print(f'L{L:2d} lam {lam:g}: bit max err {err.max():.3f} p99 {np.percentile(err,99):.3f} | value err sd {dv.std():.4f} max {np.abs(dv).max():.3f}')
