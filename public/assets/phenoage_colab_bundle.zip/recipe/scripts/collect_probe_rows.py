import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.fitk as FK, isa.proxy_probes as PP, isa.proxy_extra as PX, isa.neg_texts as NT
for m in (FK, PP, PX, NT): importlib.reload(m)
pts = [('pa', L) for L in PARAMS['layers']]
cap = FK.Capture(model, pts)
prompts = [p for _, p in PP.build(tok, FIT_PROMPTS)] + [PP.chat(tok, u) for u in PX.EXTRA + NT.NEG_USER]
rng = np.random.default_rng(0)
out = {k: [] for k in pts}
for p in prompts:
    ids = tok(p, return_tensors='pt').input_ids; cap.run(ids); T = ids.shape[1]
    sel = rng.choice(np.arange(1, T), size=min(T - 1, PARAMS.get('n', 40)), replace=False)
    for k in pts: out[k].append(cap[k][sel].astype(np.float32))
cap.remove()
np.savez(WS + '/data/probe_rows.npz', **{f'pa{L}': np.concatenate(out[('pa', L)]) for _, L in pts})
print('ok')
exec(open(WS + '/scripts/k_cleanup.py').read())
