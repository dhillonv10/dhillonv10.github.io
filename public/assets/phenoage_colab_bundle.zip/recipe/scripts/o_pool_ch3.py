# offline P1: ePD = argmin e'[A_ANS + lam * sum_{L>=12} R_L (+ lm)]e, orthogonal to codes, |gamma|<0.3 dims excluded.
# Reports read energy H(e) relative to the current ePD. usage: o_pool_ch3.py lam [save]
import sys, numpy as np
sys.path.insert(0, '.')
lam = float(sys.argv[1]); save = len(sys.argv) > 2
d = np.load('data/ans_l12.npz'); X = d['X'].astype(np.float64); LAB = d['LAB']; k = LAB[:, 1].astype(int); pi = LAB[:, 0]
G = np.load('data/gammas.npz'); g = G['G_po'][12]
Q = 0
for j in range(3):
    Z = X[(k == j) & (pi < 600)] / g; Z = Z - Z.mean(0); Q = Q + Z.T @ Z / len(Z)
Q = Q / np.trace(Q)
RG = np.load('data/read_grams.npz'); R = sum(RG[f'L{L}'].astype(np.float64) for L in range(12, 28)) + RG['lm'].astype(np.float64)
R = R / np.trace(R)
V = {}
for s in ['s1', 's2', 's3', 's5', 's5arith', 's6', 's7z']:
    dd = np.load(f'vec/{s}.npz'); V.update({kk: dd[kk] for kk in dd.files})
X0 = np.load('data/pos0_states.npy')
used = [V['eY'], V['e_v'], V['e_ind'], V['eP'], V['eV'], V['eANS'], V['e_ans2'], V['eA'], V['eF'], V['eFB']] + list(V['pin_e']) + list(V['u_items']) + list(V['bit_e']) + list(V['pads']) + list(V['e_z']) + list(V['e_i']) + [X0[L] for L in range(5, 16)]
small = np.zeros(1024, bool)
for L in range(12, 28): small |= np.abs(G['G_in'][L]) < 0.3; small |= np.abs(G['G_po'][L]) < 0.3
used += list(np.eye(1024)[small])
E = np.linalg.qr(np.array(used).T)[0]; Pp = np.eye(1024) - E @ E.T
w, Vv = np.linalg.eigh(Pp @ (Q + lam * R) @ Pp + 1e3 * E @ E.T); e = Vv[:, 0]
old = V['ePD']
for nm, v in [('old ePD', old), ('new ePD', e)]:
    print('%s: read energy H %.3e (x%.1f below isotropic) | ANS sd along read %s' % (nm, v @ R @ v, (1 / 1024) / (v @ R @ v), [round(float((X[(k == j) & (pi < 600)] @ (v / g)).std()), 5) for j in range(3)]))
print('excluded small-gamma dims: %d' % small.sum())
if save:
    ch = dict(np.load('vec/s6_ch.npz')); ch['ePD_ansquiet'] = ch['ePD']; ch['ePD'] = e; np.savez('vec/s6_ch.npz', **ch); print('saved')
