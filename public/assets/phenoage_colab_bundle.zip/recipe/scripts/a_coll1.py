import numpy as np
d = np.load('data/coll1.npz'); g = np.load('data/gammas.npz')
meta = d['meta']; LAY = d['lay']
pi, cat, lab, item = meta[:, 0], meta[:, 2], meta[:, 3], meta[:, 5]
tr = pi < 600; te = ~tr
def xhat(h, gam):
    h = h.astype(np.float64); return gam * h / np.sqrt((h ** 2).mean(1, keepdims=True) + 1e-6)
def ridge(X, Y, lam):
    X1 = np.hstack([X, np.ones((len(X), 1))]); A = X1.T @ X1 + lam * np.eye(X1.shape[1]); A[-1, -1] -= lam
    return np.linalg.solve(A, X1.T @ Y)
def pred(W, X): return np.hstack([X, np.ones((len(X), 1))]) @ W
for L in LAY:
    X = xhat(d[f'h{L}'], g['G_in'][L]) if L < 28 else None
    # (a) digits: all digit rows, target thermometer + value
    m = cat == 2
    Yt = (lab[m][:, None] >= np.arange(1, 10)[None]).astype(float)
    W = ridge(X[m & tr], Yt[tr[m]], 1e-2 * len(X))
    P_ = pred(W, X[m & te]); err = np.abs(P_ - Yt[te[m]])
    dv = P_.sum(1) - lab[m & te]
    # (b) identity at ';'/'-year' tokens: classes 0..12 items, 13 none
    m2 = (cat == 0) | (cat == 1)
    cls = np.where(cat[m2] == 0, lab[m2], 13)
    Y2 = np.eye(14)[cls]
    W2 = ridge(X[m2 & tr], Y2[tr[m2]], 1e-3 * len(X))
    P2 = pred(W2, X[m2 & te]); c2 = cls[te[m2]]
    on = P2[np.arange(len(c2)), c2]; P2o = P2.copy(); P2o[np.arange(len(c2)), c2] = -9
    off = P2o[:, :13].max(1)
    acc = (P2.argmax(1) == c2).mean()
    print(f'L{L:2d} digit thermo: max bit err {err.max():.3f} p99 {np.percentile(err,99):.3f} | digit value err sd {dv.std():.4f} max {np.abs(dv).max():.3f} || ident acc {acc:.4f} on-min(items) {on[c2<13].min():.3f} off-max {off.max():.3f}  ')
