# offline: ANS-QUIET ePD: the direction with the smallest variance of the answer-position states (ANS1-3, in the
# normalised-raw coordinates the L12 MLP read sees), plus a small natural-moment term; orthogonal to every code in use.
import sys, numpy as np
sys.path.insert(0, '.')
import isa.quiet as QU
d = np.load('data/ans_l12.npz'); X = d['X'].astype(np.float64); LAB = d['LAB']; k = LAB[:, 1].astype(int); pi = LAB[:, 0]
g = np.load('data/gammas.npz')['G_po'][12]
Q = 0
for j in range(3):
    Z = X[(k == j) & (pi < 600)] / g; Z = Z - Z.mean(0); Q = Q + Z.T @ Z / len(Z)
Q = Q / np.trace(Q)
V = {}
for s in ['s1', 's2', 's3', 's5', 's5arith']:
    dd = np.load(f'vec/{s}.npz'); V.update({kk: dd[kk] for kk in dd.files})
X0 = np.load('data/pos0_states.npy'); old = np.load('vec/s6_ch.npz')
used = [V['eY'], V['e_v'], V['e_ind'], V['eP'], V['eV'], V['eANS'], V['e_ans2'], V['eA'], V['eF'], V['eFB'], old['ePD']] + list(V['pin_e']) + list(V['u_items']) + list(V['bit_e']) + list(V['pads']) + [X0[L] for L in range(10, 16)]
lam = float(sys.argv[1]) if len(sys.argv) > 1 else 0.05
e, w = QU.quiet_dirs([12, 13], 1, side='in', exclude=used, extra=[Q / lam])
e = e[0] / np.linalg.norm(e[0])
for nm, v in [('old', old['ePD']), ('new', e)]:
    print('%s ePD: ANS sd along read (rel. units) %s | natural form %.3e' % (nm, [round(float((X[(k == j) & (pi < 600)] @ (v / g)).std()), 5) for j in range(3)], v @ QU.form(12) @ v))
np.savez('vec/s6_ch.npz', vch=old['vch'], ePD=e, ePD_old=old['ePD'])
