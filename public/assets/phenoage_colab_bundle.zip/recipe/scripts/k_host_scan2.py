import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.attnprobe as AP; importlib.reload(AP)
LAYS = list(range(4, 22))
cap = AP.QKCapture(model, LAYS)
S = np.array([39, 40, 41, 44, 49])
mins = np.full((len(LAYS), 16), 9.0); means = np.zeros((len(LAYS), 16)); n = 0
# also mass per anchor token (for anchor choice): mean over t
per_tok = np.zeros((len(LAYS), 16, len(S)))
try:
    for pi in range(0, 750, 25):
        ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
        with torch.no_grad(): model(ids)
        for a, L in enumerate(LAYS):
            Pr = cap.probs(L, T)[:, 58:, :].numpy()  # queries t>=58
            m = Pr[:, :, S].sum(-1)  # [16, T-58]
            mins[a] = np.minimum(mins[a], m.min(1)); means[a] += m.mean(1)
            per_tok[a] += Pr[:, :, S].mean(1)
        n += 1
finally:
    cap.remove()
means /= n; per_tok /= n
np.savez(WS + '/data/host_scan2.npz', mins=mins, means=means, per_tok=per_tok, lays=np.array(LAYS))
for a, L in enumerate(LAYS):
    o = np.argsort(-mins[a])[:4]
    print(L, [(int(h), round(float(mins[a, h]), 4), round(float(means[a, h]), 3)) for h in o])
