import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.attnprobe as AP; importlib.reload(AP)
L = PARAMS.get('L', 4); heads = PARAMS.get('heads', [6, 7]); g = heads[0] // 2
cap = AP.QKCapture(model, [L])
Q = []; K = []; T = []
for pi in range(0, 750, 37):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids
    with torch.no_grad(): model(ids)
    q = cap.cap[('q', L)][:, heads].numpy(); k = cap.cap[('k', L)][:, g].numpy()
    Q.append(q.astype(np.float32)); K.append(k.astype(np.float32)); T.append(ids.shape[1])
cap.remove()
np.savez(WS + f'/data/qk_L{L}.npz', Q=np.concatenate(Q), K=np.concatenate(K), T=np.array(T))
print('ok', sum(T))
