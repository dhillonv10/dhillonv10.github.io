import numpy as np
d = np.load('data/coll1.npz'); g = np.load('data/gammas.npz')
meta = d['meta']; LAY = d['lay']
pi, cat, lab = meta[:, 0], meta[:, 2], meta[:, 3]
tr = pi < 600; te = ~tr
cls = np.where(cat == 2, lab, 10)  # 10 = non-digit
for L in LAY:
    h = d[f'h{L}'].astype(np.float64)
    gg = g['G_po'][L]  # MLP reads post-attn norm; approximate with layer-input state (pre-attn) -> use G_in? use pa gamma on in-state
    X = gg * h / np.sqrt((h ** 2).mean(1, keepdims=True))
    # one-vs-rest ridge-LDA: Y one-hot 11 classes
    Y = np.eye(11)[cls]
    mu = X[tr].mean(0); Xc = X[tr] - mu
    A = Xc.T @ Xc; A += 1e-3 * np.trace(A) / 1024 * np.eye(1024)
    W = np.linalg.solve(A, Xc.T @ (Y[tr] - Y[tr].mean(0))); b = Y[tr].mean(0) - mu @ W
    S = X[te] @ W + b; c = cls[te]
    on = S[np.arange(len(c)), c]; S2 = S.copy(); S2[np.arange(len(c)), c] = -9
    off = S2[:, :10].max(1)  # strongest wrong digit
    err = (S.argmax(1) != c).sum()
    print(f'L{L:2d} errs {err}/{len(c)}  digit-rows on-min {on[c<10].min():.3f}  off-max(digit classes) {off.max():.3f}  margin-violations(on<0.5 or off>0.5): {((on[c<10]<0.5).sum() + (off>0.5).sum())}')
