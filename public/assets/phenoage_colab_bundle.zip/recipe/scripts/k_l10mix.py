import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.attnprobe as AP
for m in (CO, AP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='bits')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
tokk = set([15 + d for d in range(10)] + [220, 13])
L = PARAMS.get('L', 10)
qk = AP.QKCapture(model, [L])
Wo = P[f'model.layers.{L}.self_attn.o_proj.weight']
mvf, mpin, m0, mself = np.zeros(16), np.zeros(16), np.zeros(16), np.zeros(16); n = 0
for pi in range(600, 750, 15):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
    with torch.no_grad(): model(ids)
    Pr = qk.probs(L, T).numpy()
    vfs = [it['vf'] for it in res[pi]['items']]
    pins = [t for t in range(58, T) if int(ids[0, t]) in tokk]
    for v in vfs:
        others = [u for u in vfs if u < v]
        mvf += Pr[:, v, others].sum(-1); mpin += Pr[:, v, pins].sum(-1) if pins else 0; m0 += Pr[:, v, 0]; mself += Pr[:, v, v]; n += 1
qk.remove()
print('L%d head: mass from VF query to OTHER VF tokens / digit-pins / pos0 / self' % L)
for h in range(16): print(h, '%.3f %.3f %.3f %.3f' % (mvf[h] / n, mpin[h] / n, m0[h] / n, mself[h] / n))
exec(open(WS + '/scripts/k_cleanup.py').read())
