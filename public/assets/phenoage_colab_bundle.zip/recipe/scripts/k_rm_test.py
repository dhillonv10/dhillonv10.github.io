# removal-cost tests: list of configs, each a list of ('neuron', L, j) / ('vchan', L, g, ch) / ('group', L, g) / ('qhead', L, h)
import sys, importlib, numpy as np, json
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.se as SE; importlib.reload(CO); importlib.reload(SE)
out = {}
for name, items in PARAMS['configs'].items():
    reg = CO.Registry(P)
    for it in items:
        if it[0] == 'neuron':
            _, L, j = it
            reg.set(CO.pname(L, 'down'), 1, j, np.zeros(1024), 'rm')
        elif it[0] == 'vchan':
            _, L, g, ch = it
            reg.set(CO.pname(L, 'v'), 0, 128 * g + ch, np.zeros(1024), 'rm')
        elif it[0] == 'group':
            _, L, g = it
            for h in (2 * g, 2 * g + 1):
                for i in range(128): reg.set(CO.pname(L, 'o'), 1, 128 * h + i, np.zeros(1024), 'rm')
        elif it[0] == 'qhead':
            _, L, h = it
            for i in range(128): reg.set(CO.pname(L, 'o'), 1, 128 * h + i, np.zeros(1024), 'rm')
    print(name, end=': ')
    r = SE.se_local(model, tok, FIT_PROMPTS, idx=PARAMS.get('idx'))
    out[name] = dict(maxkl=r['maxkl'], meankl=r['meankl'], real=r['real'], near=r['near'], kl=r['kl'].round(5).tolist())
    reg.restore()
json.dump(out, open(WS + '/data/rm_' + PARAMS.get('tag', 'x') + '.json', 'w'))
