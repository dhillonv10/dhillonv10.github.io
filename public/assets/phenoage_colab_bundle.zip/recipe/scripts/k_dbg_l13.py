# debug: compare the live (accepted) L13 EMIT rows with a fresh install of the current vec files
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO
importlib.reload(CO)
import phenoage_program as PG; importlib.reload(PG)
L, nn = PG.NEUR['emit']
live = {m: P[CO.pname(L, m)].clone() for m in ('gate', 'up', 'down')}
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V)
for m in ('gate', 'up', 'down'):
    W = P[CO.pname(L, m)]
    D = (W - live[m]).abs()
    D = D.max(1).values if m != 'down' else D.max(0).values
    idx = torch.nonzero(D > 1e-6).flatten().tolist()
    print(m, 'rows/cols differing:', idx[:30], 'max', float(D.max()))
reg.restore()
for m in ('gate', 'up', 'down'):
    print('after restore', m, float((P[CO.pname(L, m)] - live[m]).abs().max()))
exec(open(WS + '/scripts/k_cleanup.py').read())
