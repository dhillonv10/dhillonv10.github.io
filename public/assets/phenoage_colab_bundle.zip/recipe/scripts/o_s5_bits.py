# offline: bit decoders at L9 pa (VF rows): for offsets 2,4,5,6 and bits 0-3 of the digit (non-digit -> 0); margins.
import numpy as np
d = np.load('data/vf_pa9.npz'); X = d['X'].astype(np.float64); lab = d['lab']
pi = lab[:, 0]; tr = (pi < 600) | (pi >= 1100); te = ~tr
A = X[tr].T @ X[tr] + 1e-5 * np.trace(X[tr].T @ X[tr]) / 1024 * np.eye(1024)
Ainv_XtT = None
out = {}
for j, k in [(2, 1), (3, 2), (5, 4), (6, 5), (7, 6)]:
    y = lab[:, j]; val = np.where(y < 10, y, 0)
    for b in range(4):
        t = ((val >> b) & 1).astype(float)
        if t.std() == 0: continue
        w = np.linalg.solve(A, X[tr].T @ t[tr]); s = X @ w
        on = s[te & (t == 1)]; off = s[te & (t == 0)]
        out[f'w{k}_{b}'] = w
        print('offset', k, 'bit', b, 'test on-min %.3f off-max %.3f | train on-min %.3f off-max %.3f' % (on.min() if len(on) else 9, off.max(), s[tr & (t == 1)].min() if (tr & (t == 1)).any() else 9, s[tr & (t == 0)].max()))
    wv = np.linalg.solve(A, X[tr].T @ val[tr].astype(float)); out[f"v{k}"] = wv
np.savez('vec/s5_bits_fit.npz', **out)
