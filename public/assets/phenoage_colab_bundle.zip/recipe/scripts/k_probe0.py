import inspect
print(type(P), len(P))
print([k for k in list(P.keys())[:20]])
print(type(FIT_PROMPTS), len(FIT_PROMPTS), type(FIT_Y))
print(repr(FIT_PROMPTS[0])[:3000])
print(FIT_Y[:5])
for name in ['forward','generate']:
    f = globals()[name]
    try: print(name, inspect.signature(f)); print(inspect.getsource(f)[:2500])
    except Exception as e: print(name, e)
print([k for k in globals().keys() if not k.startswith('_')])
print(type(D), list(D.keys())[:20] if hasattr(D,'keys') else D)
