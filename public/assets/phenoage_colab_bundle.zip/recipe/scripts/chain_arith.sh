#!/bin/bash
# AFFINE + LOG_PWL + POOL + ANS collection + EMIT fit/derive on the v3 pipeline. Stops at the first error.
set -e
set -o pipefail
cd /tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon
PY=../venv/bin/python
scripts/kpy.sh scripts/collect_rows.py '{"upto":"bits","side":"pa","L":10,"tag":"pa10","nsynth":0,"step":2,"nneg":15}' 2
$PY scripts/o_s5b.py 2>&1 | grep -v Warn | tail -25
scripts/kpy.sh scripts/derive_s5c.py '{"aY":4.0,"aV":30.0,"aI":30.0,"kapI2":100,"kapK":3000}' 16
scripts/kpy.sh scripts/derive_kinks.py '{"aY":4.0}' 16
echo ARITH_DONE
scripts/kpy.sh scripts/derive_s6b.py '{"ncut":16,"nsynth":100,"step":3}' 4
$PY scripts/o_s7c.py 13 1e-4
echo CHAIN_ARITH_DONE
