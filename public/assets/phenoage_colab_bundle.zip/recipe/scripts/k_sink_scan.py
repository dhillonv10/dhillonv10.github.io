import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.attnprobe as AP, isa.proxy_probes as PP; importlib.reload(AP); importlib.reload(PP)
LAYS = list(range(3, 14))
cap = AP.QKCapture(model, LAYS)
vcap = {}
hk = [model.model.layers[L].self_attn.v_proj.register_forward_hook(lambda m, i, o, L=L: vcap.__setitem__(L, o.detach()[0])) for L in LAYS]
mins = np.full((len(LAYS), 16), 9.0); means = np.zeros((len(LAYS), 16)); n = 0
vuse = np.zeros((len(LAYS), 1024)); nt = 0
probes = PP.build(tok, FIT_PROMPTS)
try:
    for pi in range(0, 750, 50):
        ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; T = ids.shape[1]
        with torch.no_grad(): model(ids)
        for a, L in enumerate(LAYS):
            Pr = cap.probs(L, T)[:, 58:, 0].numpy()
            mins[a] = np.minimum(mins[a], Pr.min(1)); means[a] += Pr.mean(1)
        n += 1
    for kind, p in probes:
        ids = tok(p, return_tensors='pt').input_ids
        with torch.no_grad(): model(ids)
        for a, L in enumerate(LAYS):
            vuse[a] += vcap[L][1:].abs().sum(0).numpy()
        nt += ids.shape[1] - 1
finally:
    cap.remove(); [h.remove() for h in hk]
means /= n; vuse /= nt
np.savez(WS + '/data/sink_scan.npz', mins=mins, means=means, vuse=vuse, lays=np.array(LAYS))
for a, L in enumerate(LAYS):
    o = np.argsort(-mins[a])[:5]
    print(L, [(int(h), round(float(mins[a, h]), 3), round(float(means[a, h]), 3)) for h in o])
