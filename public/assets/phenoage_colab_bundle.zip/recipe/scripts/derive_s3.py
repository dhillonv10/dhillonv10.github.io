# S3: IDENT/VF pins + ANS pin at L7 MLP
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.se as SE, isa.proxy_probes as PP
for m in (CO, FK, SE, PP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
import pickle
V = PG.load(WS)
S = np.load(WS + '/vec/s3_ident_L7.npz'); D3 = np.load(WS + '/vec/s3_pin_dirs.npy')
V3 = dict(id_w=np.stack([S[f'w{k}'] for k in range(14)]), id_b=np.array([S[f'b{k}'] for k in range(14)]), c7=S['c'], rFB7=S['rFB'], rFB7n=S['rFBn'],
          kapI=PARAMS.get('kap', 150.0), Pvf=PARAMS.get('Pvf', 300.0), eV=D3[0], eANS=D3[1], u_items=D3[2:15])
if PARAMS.get('v3', 0):
    D3 = np.load(WS + '/vec/dirs_v3.npz'); V3['eV'] = D3['eV']; V3['eANS'] = D3['eANS']; V3['u_items'] = D3['u_items']
V.update(V3)
reg = CO.Registry(P); PG.install(reg, V, upto='ident')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
cap = FK.Capture(model, [('pa', 7)])
def z(XH):
    return np.stack([((V['id_w'][k] + V['id_b'][k] * V['c7']) + 1.5 * (V['rFB7n'] - V['c7'])) @ XH.T for k in range(14)], 1)
wrong = 0; onmin = 9; offmax = -9
for pi in range(601, 750, 2):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); Z = z(cap[('pa', 7)])[58:]
    lab = np.full(Z.shape[0], -1)
    for it in res[pi]['items']: lab[it['vf'] - 58] = it['item']
    lab[-1] = 13
    for k in range(14):
        on = Z[lab == k, k]; off = Z[lab != k, k]
        if len(on): onmin = min(onmin, on.min())
        offmax = max(offmax, off.max()); wrong += (on <= 0).sum() + (off > 0).sum()
print('held-out: on-min %.3f off-max %.3f wrong %d' % (onmin, offmax, wrong))
probes = PP.build(tok, FIT_PROMPTS); pm = -9
for kind, p in probes:
    cap.run(tok(p, return_tensors='pt').input_ids); pm = max(pm, z(cap[('pa', 7)])[1:].max())
print('probes max %.3f' % pm)
cap.remove()
np.savez(WS + '/vec/s3.npz', **V3)
if PARAMS.get('se', 1): SE.se_local(model, tok, FIT_PROMPTS)
exec(open(WS + '/scripts/k_cleanup.py').read())
