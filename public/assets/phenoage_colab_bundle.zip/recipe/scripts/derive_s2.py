# S2: PINS at L5 MLP. vectors from vec/s2_svm.npz (offline conjunction SVMs), pin dirs from vec/s2_pin_dirs.npy
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.se as SE, isa.proxy_probes as PP
for m in (CO, FK, SE, PP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
LAY = PARAMS.get('L', 6)
S = np.load(WS + f'/vec/s2_svm_L{LAY}.npz'); D = np.load(WS + '/vec/' + PARAMS.get('pindirs', 's2_pin_dirs.npy'))
V2 = dict(svm_w=np.stack([S[f'w{k}'] for k in range(12)]), svm_b=np.array([S[f'b{k}'] for k in range(12)]), c5=S['c5'],
          fb5_on=1.0, rFB5=S['rFB'], kapP=PARAMS.get('kap', 150.0), thP=0.5, Ppin=PARAMS.get('Ppin', 150.0), eP=D[0], pin_e=D[1:13])
if PARAMS.get('v3', 0):
    D3 = np.load(WS + '/vec/dirs_v3.npz'); V2['eP'] = D3['e_sw']; V2['pin_e'] = D3['pin_e']; V2['e_ans2'] = D3['e_ans2']
    A2 = np.load(WS + '/vec/s2_ans2_svm.npz'); V2['ans2_w'] = A2['w']; V2['ans2_b'] = np.float64(A2['b'])
V.update(V2)
reg = CO.Registry(P); PG.install(reg, V, upto='pins')
# test: gate values of pin pairs on PhenoAge prompts and probes
g5 = P[f'model.layers.{LAY}.post_attention_layernorm.weight'].double().numpy()
cap = FK.Capture(model, [('pa', LAY)])
def zscores(XH):
    return np.stack([(0.7 * (V['svm_w'][k] + V['svm_b'][k] * V['c5']) + 0.3 * V['rFB5'] / V['fb5_on'] - V['thP'] * V['c5']) @ XH.T for k in range(12)], 1)
tok_k = {**{15 + d: d for d in range(10)}, 220: 10, 13: 11}
wrong = 0; on_min = 9; off_max = -9; n = 0
for pi in range(600, 750, 3):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids[0]; cap.run(ids[None])
    Z = zscores(cap[('pa', LAY)])[58:]; lab = np.array([tok_k.get(int(i), -1) for i in ids[58:]])
    for k in range(12):
        on = Z[lab == k, k]; off = Z[lab != k, k]
        if len(on): on_min = min(on_min, on.min())
        off_max = max(off_max, off.max()); wrong += (on <= 0).sum() + (off > 0).sum(); n += len(lab)
print('held-out PhenoAge: z-th on-min %.3f off-max %.3f wrong %d of %d tokens' % (on_min, off_max, wrong, n))
probes = PP.build(tok, FIT_PROMPTS)
pm = -9
for kind, p in probes:
    cap.run(tok(p, return_tensors='pt').input_ids); pm = max(pm, zscores(cap[('pa', LAY)])[1:].max())
print('probes: z-th max %.3f  (gate = %.0f * that)' % (pm, V['kapP']))
cap.remove()
np.savez(WS + '/vec/s2.npz', **V2)
if PARAMS.get('se', 1): SE.se_local(model, tok, FIT_PROMPTS)
print(reg.footprint()[1])
exec(open(WS + '/scripts/k_cleanup.py').read())
