# Stage S1 FLAG derivation (kernel). Produces vec/s1.npz. Installs: ANCHOR (L3 MLP) -> FLAG host (L4 g3 keyswitch + vtake ch89)
# -> FB clean STEP (L4 MLP). Tests: FB on all 750 practice prompts (t>=50), FB off on proxy probes, se_local.
import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prims as PRM, isa.fitk as FK, isa.se as SE, isa.proxy_probes as PP
for m in (CO, PRM, FK, SE, PP): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = {}
ad = np.load(WS + '/vec/anchor_dets.npz')
for a in (40, 41, 49): V[f'anc_r{a}'] = ad[f'r{a}']; V[f'anc_b{a}'] = ad[f'b{a}']
V['c3'] = np.load(WS + '/vec/const_L3pa.npy')
Q = np.load(WS + '/vec/quiet_L4_10b.npy'); V['eA'] = Q[0]; V['eF'] = Q[1]; V['eFB'] = np.load(WS + '/vec/s1_eFB_L5.npy')
V['Aamp'] = PARAMS.get('Aamp', 200.0); V['vmode'] = PARAMS.get('vmode', 'take'); V['M'] = PARAMS.get('M', 10.0); V['aFB'] = PARAMS.get('aFB', 10.0)
reg = CO.Registry(P)
PG.install_anchor(reg, V)
g4 = P['model.layers.4.input_layernorm.weight'].double().numpy()
cap = FK.Capture(model, [('in', 4), ('pa', 4), ('in', 5)])
cap.run(tok(FIT_PROMPTS[0], return_tensors='pt').input_ids)
XH = cap[('in', 4)]
Mn = np.load(WS + '/data/nat_moments.npz', mmap_mode='r')
AN = [a for a, _ in PG.ANCHORS]
Mi = Mn['M_in'][4].astype(np.float64)
xon = XH[AN].mean(0)
V['rt'] = FK.minvar_read(Mi, xon, zero=[XH[0]])
print('rt at anchors', (XH[AN] @ V['rt']).round(3).tolist(), 'pos0', round(float(XH[0] @ V['rt']), 5))
Wk = P['model.layers.4.self_attn.k_proj.weight'][128 * 3:128 * 4].double().numpy()
gk = P['model.layers.4.self_attn.k_norm.weight'].double().numpy()
kst = np.load(WS + '/vec/flag_kstar_L4_404149.npy') / gk
kmean = np.mean([Wk @ XH[a] for a in AN], 0)
kst *= np.linalg.norm(kmean) / np.linalg.norm(kst)
V['kdelta'] = kst - kmean
Wv = P['model.layers.4.self_attn.v_proj.weight'][128 * 3 + 89].double().numpy()
V['cV'] = float(PARAMS.get('cVx', 30.0) * np.median(np.abs(XH[1:] @ Wv)))
print('cV', V['cV'])
PG.install_flag_head(reg, V)
# FB clean read: min-variance read at L4 pa of the eF write
gpa = P['model.layers.4.post_attention_layernorm.weight'].double().numpy()
cap.run(tok(FIT_PROMPTS[0], return_tensors='pt').input_ids)
XP = cap[('pa', 4)]
# CONST at L4 pa from natural rows of a few probes + practice prompts (no FB effect on probes)
probes = PP.build(tok, FIT_PROMPTS)
rows = []
for i in list(range(0, 105, 7)):
    cap.run(tok(probes[i][1], return_tensors='pt').input_ids); rows.append(cap[('pa', 4)][1:])
for pi in range(1, 750, 150):
    cap.run(tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids); rows.append(cap[('pa', 4)][1:50])
R = np.concatenate(rows); V['c4'] = FK.fit_const(R)
print('CONST L4pa sd %.4f' % (R @ V['c4']).std())
on = gpa * V['eF'] * 32.0 / np.sqrt((XP[60:] ** 2).mean(-1)).mean() * 1.0  # direction of the eF write in xhat units
V['rF'] = FK.minvar_read(Mn['M_pa'][4].astype(np.float64) + FK.second_moment(R), on, zero=[XP[0], gpa * V['eA']])
fon = XP[58:] @ V['rF']
print('F read on prompt0: min %.3f median %.3f (prefix<49 max %.3f)' % (fon.min(), np.median(fon), np.abs(XP[1:49] @ V['rF']).max()))
# measure distributions on many prompts
mins = []
for pi in range(0, 750, 10):
    cap.run(tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids); mins.append((cap[('pa', 4)][58:] @ V['rF']).min())
offs = []
for kind, p in probes:
    cap.run(tok(p, return_tensors='pt').input_ids); offs.append(np.abs(cap[('pa', 4)][1:] @ V['rF']).max())
mins = np.array(mins); offs = np.array(offs)
print('F read: PhenoAge min %.3f (p1 %.3f); probes max %.3f' % (mins.min(), np.percentile(mins, 1), offs.max()))
V['thF'] = float(0.5 * (mins.min() + offs.max())); V['kapF'] = float(min(400.0, 120.0 / max(mins.min() - offs.max(), 1e-3)))
print('threshold %.3f kappa %.1f' % (V['thF'], V['kapF']))
dn = np.load(WS + '/data/norm_4_5.npz'); wn = np.load(WS + '/vec/norm_read_L4_x5.npy')
V['u4'] = wn / np.median(dn['N1'][dn['ON']])
V['aFB'] = PARAMS.get('aFBrel', 0.3) * np.median(dn['N1'][dn['ON']])
print('aFB', V['aFB'])
PG.install_fb(reg, V)
# test FB at L5 pa with a min-variance read (natural moments + probe rows), zero on eF/eA
g5 = P['model.layers.5.post_attention_layernorm.weight'].double().numpy()
cap2 = FK.Capture(model, [('pa', 5)])
PR = []
for kind, p in probes[::3]:
    cap2.run(tok(p, return_tensors='pt').input_ids); PR.append(cap2[('pa', 5)][1:])
PR = np.concatenate(PR)
rFB5 = FK.minvar_read(Mn['M_pa'][5].astype(np.float64) + FK.second_moment(PR), g5 * V['eFB'], zero=[g5 * V['eF'], g5 * V['eA']])
fbmin = []
for pi in range(0, 750, 5):
    cap2.run(tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids); fbmin.append((cap2[('pa', 5)][58:] @ rFB5).min())
fboff = []
for kind, p in probes:
    cap2.run(tok(p, return_tensors='pt').input_ids); fboff.append(np.abs(cap2[('pa', 5)][1:] @ rFB5).max())
cap2.remove(); cap.remove()
fbmin = np.array(fbmin); fboff = np.array(fboff)
cap2 = None
print('FB minvar read @L5pa: PhenoAge min %.3f median-of-mins %.3f ; probes max %.3f' % (fbmin.min(), np.median(fbmin), fboff.max()))
V['rFB5'] = rFB5
np.savez(WS + '/vec/s1.npz', **V)
if PARAMS.get('se', 1): SE.se_local(model, tok, FIT_PROMPTS)
print(reg.footprint()[1])
