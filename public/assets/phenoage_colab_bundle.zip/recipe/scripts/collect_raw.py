import sys, importlib, numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.fitk as FK, isa.proxy_probes as PP
for m in (FK, PP): importlib.reload(m)
pts = [('pa', L) for L in PARAMS.get('layers', [5])]
cap = FK.Capture(model, pts, raw=True)
probes = PP.build(tok, FIT_PROMPTS)
out = {k: [] for k in pts}
for p in [q for _, q in probes[::2]] + [FIT_PROMPTS[i] for i in range(0, 750, 25)]:
    cap.run(tok(p, return_tensors='pt').input_ids)
    for k in pts: out[k].append(cap[k][1:].astype(np.float32))
cap.remove()
np.savez(WS + '/data/raw_pa.npz', **{f'pa{L}': np.concatenate(out[('pa', L)]) for _, L in pts})
print('ok')
