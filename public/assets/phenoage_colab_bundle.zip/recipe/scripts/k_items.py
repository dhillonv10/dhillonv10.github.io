# per-item Y read at L12 in (raw eY / aY) vs exact, for given pids (installed accepted pipeline up to kinks)
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS); reg = CO.Registry(P); PG.install(reg, V, upto='kinks')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
cap = FK.Capture(model, [('in', 12)], raw=True)
for pi in PARAMS['pids']:
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); X = cap[('in', 12)]
    out = []
    for it in res[pi]['items']:
        i = it['item']; yt = PR.item_years(PR.ITEM_NAMES[i], it['value']) - V['mu'][i]; yr = float(X[it['vf']] @ V['eY']) / V['aY']
        out.append('%s %s: %.1f/%.1f' % (PR.ITEM_NAMES[i], it['value'], yt, yr))
    print(pi, ' | '.join(out))
    print('   text:', FIT_PROMPTS[pi][-420:].replace('\n', ' ')[:420])
cap.remove()
exec(open(WS + '/scripts/k_cleanup.py').read())
