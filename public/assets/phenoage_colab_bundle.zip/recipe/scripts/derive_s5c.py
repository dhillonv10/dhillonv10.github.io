# install AFFINE (L10) from vec/s5b_fit.npz; append to vec/s5.npz; check Y written at VF (L11 in) vs exact on held-out practice
import sys, importlib, numpy as np, pickle
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.fitk as FK, isa.prompts as PR
for m in (CO, FK, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
F = dict(np.load(WS + '/vec/s5b_fit.npz'))
F.update(aV=np.float64(PARAMS.get('aV', 30.0)), aI=np.float64(PARAMS.get('aI', 30.0)), kapI2=np.float64(PARAMS.get('kapI2', 100.0)), kapK=np.float64(PARAMS.get('kapK', 3000.0)), Bk=np.float64(PARAMS.get('Bk', 300.0)), aY=np.float64(PARAMS.get('aY', 1.0)))
V.update(F)
np.savez(WS + '/vec/s5arith.npz', **F)
reg = CO.Registry(P); PG.install(reg, V, upto='arith')
res = pickle.load(open(WS + '/data/fit_parse.pkl', 'rb'))
g = P['model.layers.11.input_layernorm.weight'].double().numpy()
cap = FK.Capture(model, [('in', 11)], raw=True)
rows = []
for pi in range(600, 750, 3):
    ids = tok(FIT_PROMPTS[pi], return_tensors='pt').input_ids; cap.run(ids); X = cap[('in', 11)]
    for it in res[pi]['items']:
        i = it['item']; ytrue = PR.item_years(PR.ITEM_NAMES[i], it['value']) - V['mu'][i]
        rows.append((i, float(X[it['vf']] @ V['eY']), ytrue))
cap.remove()
rows = np.array(rows)
for i in range(13):
    m = rows[:, 0] == i
    if m.sum() == 0: continue
    e = rows[m, 1] / V['aY'] - rows[m, 2]
    print('item %2d %-10s Y err (raw eY / aY - exact): mean %+.3f sd %.3f max %.3f' % (i, PR.ITEM_NAMES[i], e.mean(), e.std(), np.abs(e).max()))
print(reg.footprint()[1])
exec(open(WS + '/scripts/k_cleanup.py').read())
