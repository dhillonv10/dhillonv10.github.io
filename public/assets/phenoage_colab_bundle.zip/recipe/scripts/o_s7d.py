# offline: EMIT reads at L13 pa (structured). isA1/isA2/isA3 type reads (ridge vs other answer pos, other tokens,
# probes); z1r = a*rPD + b*c (ANS1), z2r = a*rPD + b*c - 10*rT (ANS2; rT = ridge read of the tens digit pin);
# rPD = ePD / gamma (xhat read of the pooled-Y write). usage: o_s7d.py [lamT]
import numpy as np, sys
lamT = float(sys.argv[1]) if len(sys.argv) > 1 else 1e-4
Lr = int(sys.argv[2]) if len(sys.argv) > 2 else 13
d = np.load(f'data/ans_l{Lr}.npz'); X = d['X'].astype(np.float64); LAB = d['LAB']; XO = d['XO'].astype(np.float64)
XP = np.load('data/probe_rows.npz')[f'pa{Lr}'].astype(np.float64)
g = np.load('data/gammas.npz')['G_po'][Lr]; rPD = np.load('vec/s6.npz')['ePD'] / g
pi, k, y, T, U = LAB[:, 0], LAB[:, 1].astype(int), LAB[:, 2], LAB[:, 3], LAB[:, 4]
tr = (pi < 600) | (pi >= 1030); te = ~tr; prac = (pi >= 600) & (pi < 750)
trO = np.arange(len(XO)) % 4 != 0; trP = np.arange(len(XP)) % 4 != 0
Xall = np.r_[X[tr], XO[trO], XP[trP]]
A = Xall.T @ Xall; A += 1e-5 * np.trace(A) / 1024 * np.eye(1024)
out = {}
for j, nm in enumerate(['isA1', 'isA2', 'isA3']):
    t = np.r_[(k[tr] == j).astype(float), np.zeros(trO.sum() + trP.sum())]
    w = np.linalg.solve(A, Xall.T @ t); s = X[te] @ w
    print('%s: on test min %.4f max %.4f | other answer pos |max| %.4f | other tokens max %.4f | probes max %.4f' % (
        nm, s[k[te] == j].min(), s[k[te] == j].max(), np.abs(s[k[te] != j]).max(), (XO[~trO] @ w).max(), (XP[~trP] @ w).max()))
    out[nm] = w
c = np.linalg.solve(Xall.T @ Xall + 1e-3 * np.trace(Xall.T @ Xall) / 1024 * np.eye(1024), Xall.T @ np.ones(len(Xall)))
out['c13'] = c   # CONST at the EMIT layer (key name kept)
sP = X @ rPD; sc = X @ c
# tens
m = (k == 0) & (pi < 600); z1 = (y + 0.5) / 10 - 0.5
co = np.linalg.lstsq(np.c_[sP[m], sc[m]], z1[m], rcond=None)[0]; out['z1r'] = co[0] * rPD + co[1] * c
# units: T read on ANS2 rows (+ other answer rows with target 0? no: only ANS2 matters, gated by isA2)
m2 = (k == 1) & tr
A2 = X[m2].T @ X[m2]; A2 += lamT * np.trace(A2) / 1024 * np.eye(1024)
rT = np.linalg.solve(A2, X[m2].T @ T[m2]); eT = X[(k == 1) & te] @ rT - T[(k == 1) & te]
print('T read at ANS2: test err sd %.4f max %.4f' % (eT.std(), np.abs(eT).max()))
z2 = y - 10 * T
m2p = (k == 1) & (pi < 600)      # the pooled read at ANS2 carries a T-dependent offset: T coefficient is free
co2 = np.linalg.lstsq(np.c_[sP[m2p], sc[m2p], X[m2p] @ rT], z2[m2p], rcond=None)[0]
print('z2 fit coefs: rPD %.3f c %.3f T %.3f' % tuple(co2))
out['z2r'] = co2[0] * rPD + co2[1] * c + co2[2] * rT
for nm, kk, zt in [('z1', 0, z1), ('z2', 1, z2)]:
    w = out[nm + 'r']
    for lab, mm in [('practice', (k == kk) & prac), ('synth-test', (k == kk) & te & ~prac)]:
        e = X[mm] @ w - zt[mm]
        dig = np.clip(np.round(X[mm] @ w), 0, 9); tgt = (T if kk == 0 else U)[mm]
        print('%s %s: err sd %.4f max %.3f | digit wrong %d / %d' % (nm, lab, e.std(), np.abs(e).max(), (dig != tgt).sum(), mm.sum()))
    print('   %s on other tokens |.| p99 %.1f, probes max %.1f' % (nm, np.percentile(np.abs(XO @ w), 99), np.abs(XP @ w).max()))
# end-to-end predicted answer on practice (tens, units from the reads)
mm1 = (k == 0) & prac; mm2 = (k == 1) & prac
tens = np.clip(np.round(X[mm1] @ out['z1r']), 0, 9); units = np.clip(np.round(X[mm2] @ out['z2r']), 0, 9)
pred = 10 * tens + units; print('practice answer MAE (teacher-forced tens at ANS2): %.3f' % np.abs(pred - y[mm1]).mean())
np.savez(f'vec/s7_fit_L{Lr}d.npz', **out); print('saved')
