# install the full program (vec/*.npz as on disk) and generate on held-out practice pids 600-749 (A3 proxy)
import sys, importlib, numpy as np, re
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
sys.path.insert(0, WS)
import isa.core as CO, isa.prompts as PR
for m in (CO, PR): importlib.reload(m)
import phenoage_program as PG; importlib.reload(PG)
V = PG.load(WS)
if PARAMS.get('over'): d_ = np.load(WS + '/' + PARAMS['over']); V.update({k: d_[k] for k in d_.files})
for k, f in PARAMS.get('scale', {}).items(): V[k] = V[k] * f
reg = CO.Registry(P); PG.install(reg, V)
errs, sgn, bad = [], [], []
for pi in range(600, 750, PARAMS.get('step', 1)):
    items = {PR.ITEM_NAMES[i]: float(vs) for i, vs, a, b in PR.parse_text(FIT_PROMPTS[pi])}
    y = PR.phenoage(items); g = generate(FIT_PROMPTS[pi])
    m = re.search(r'-?\d+(\.\d+)?', g); v = float(m.group()) if m else 45.0
    errs.append(abs(v - y)); sgn.append(v - y)
    if abs(v - y) >= 3: bad.append((pi, round(y, 1), repr(g[:12])))
e = np.array(errs)
print('practice generate (pids 600-749 step %d, n %d): MAE %.3f | bias %+.3f | median %.2f | frac >= 3 yr %.3f | MAE without |err|>20: %.3f' % (
    PARAMS.get('step', 1), len(e), e.mean(), np.mean(sgn), np.median(e), (e >= 3).mean(), e[e < 20].mean()))
print('errors >= 3 yr:', bad[:20])
exec(open(WS + '/scripts/k_cleanup.py').read())
