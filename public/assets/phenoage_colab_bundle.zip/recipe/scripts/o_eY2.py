# offline: candidate eY (Y channel) with a natural-quiet gamma-weighted read at L12 (the POOL_VTAKE read), small W_v forms
# at L10/L11 (no copying between VF tokens), orthogonal to all codes in use. Compares with the current eY.
import sys, numpy as np
sys.path.insert(0, '.')
G = np.load('data/gammas.npz'); gi = G['G_in'][12]
XP = np.load('data/probe_rows.npz')['pa11'].astype(np.float64)        # proxy for the L12-in natural states
gp = G['G_po'][11]; Xr = XP / gp                                         # normalised raw (x/rms * 1)
mm = np.load('data/nat_moments.npz')['M_in'][12].astype(np.float64) / np.outer(gi, gi)
V = {}
for s in ['s1', 's2', 's3', 's5', 's5arith', 's6', 's7z']:
    d = np.load(f'vec/{s}.npz'); V.update({k: d[k] for k in d.files})
X0 = np.load('data/pos0_states.npy')
used = [V['e_v'], V['e_ind'], V['eP'], V['eV'], V['eANS'], V['e_ans2'], V['eA'], V['eF'], V['eFB'], V['ePD']] + list(V['pin_e']) + list(V['u_items']) + list(V['bit_e']) + list(V['pads']) + list(V['e_z']) + list(V['e_i']) + [X0[L] for L in range(5, 16)]
E = np.linalg.qr(np.array(used).T)[0]; Pp = np.eye(1024) - E @ E.T
Mn = mm / np.trace(mm); Mp = Xr.T @ Xr / len(Xr); Mp /= np.trace(Mp)
def stats(e):
    return 'natural form %.3e | probe-row |e.x/rms| max %.4f p99 %.4f' % (e @ Mn @ e, np.abs(Xr @ e).max(), np.percentile(np.abs(Xr @ e), 99))
print('current eY:', stats(V['eY']))
w, Vv = np.linalg.eigh(Pp @ (Mn + Mp) @ Pp + 1e3 * E @ E.T)
e = Vv[:, 0]; print('candidate :', stats(e))
np.save('vec/eY2_cand.npy', e)
W = np.load('data/wv_10_11.npz')
F = 0
for L in (10, 11):
    A = W[f'v{L}'].astype(np.float64); Fv = A.T @ A; F = F + Fv / np.trace(Fv)
print('current eY v-forms %.3e' % (V['eY'] @ F @ V['eY']))
for lam in [0.3, 1.0, 3.0]:
    w, Vv = np.linalg.eigh(Pp @ (Mn + Mp + lam * F) @ Pp + 1e3 * E @ E.T); e = Vv[:, 0]
    print('lam %.1f: %s | v-forms %.3e' % (lam, stats(e), e @ F @ e))
    if lam == 1.0: np.save('vec/eY2_cand.npy', e)
