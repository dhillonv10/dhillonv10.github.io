import sys, importlib, numpy as np, time
sys.path.insert(0, '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon')
import isa.proxy_probes as PP; importlib.reload(PP)
probes = PP.build(tok, FIT_PROMPTS)
print(len(probes)); print(probes[0][1][-300:]); print(probes[-1][1][-200:])
t = time.time()
L = []
with torch.no_grad():
    for kind, p in probes:
        ids = tok(p, return_tensors='pt')
        lg = model(**ids).logits[0, -1].float()
        L.append(torch.log_softmax(lg, -1).numpy())
L = np.stack(L).astype(np.float32)
print('time', time.time() - t)
top = L.argsort(1)[:, ::-1][:, :2]
gap = L[np.arange(len(L)), top[:, 0]] - L[np.arange(len(L)), top[:, 1]]
for i, (kind, p) in enumerate(probes):
    if i % 5 == 0 or kind == 'chat': print(i, kind, repr(tok.decode([top[i, 0]])), repr(tok.decode([top[i, 1]])), round(float(gap[i]), 3))
# save top-k sparse ref (full logprobs too big? 125x151k x4 = 75MB ok)
np.save(PP.__file__.replace('isa/proxy_probes.py', 'data/proxy_ref_logp.npy'), L)
