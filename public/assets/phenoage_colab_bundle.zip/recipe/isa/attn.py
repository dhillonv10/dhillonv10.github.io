"""Attention design math (numpy, usable inside or outside the kernel).
RoPE (Qwen3): plane j = dims (j, j+64), theta_j = base^(-2j/128), base 1e6. Score = q_rot . k_rot / sqrt(128),
with q = q_norm(q_raw) = gq * q_raw / rms(q_raw) (same for k).  Adapted from round-6 lib6.pos_design (LP over plane
energies), generalised: margin constraints over all other offsets up to T."""
import numpy as np
from scipy.optimize import linprog

TH = 1e6 ** (-np.arange(64) * 2 / 128.0)


def normed(v, g):
    return g * v / np.sqrt((v ** 2).mean())


def score_curve(qd, kd, gq, gk, D):
    """exact score vs relative offset D (array) for constant RAW q/k directions"""
    qh = normed(qd, gq); kh = normed(kd, gk)
    Zq = qh[:64] + 1j * qh[64:]; Zk = kh[:64] + 1j * kh[64:]
    return np.real((Zq * np.conj(Zk))[None, :] * np.exp(1j * np.asarray(D)[:, None] * TH[None, :])).sum(1) / np.sqrt(128.0)


def pos_design(gq, gk, offsets, T=800, planes=None):
    """constant raw q directions (one per offset) and one shared raw k direction so that q-head i peaks at offset
    offsets[i]; LP maximises the worst margin score(k) - score(D) over D in [0, T], D != k.
    planes: optional boolean mask of usable planes (e.g. exclude slow planes reserved for a sink)."""
    gq = np.asarray(gq, float); gk = np.asarray(gk, float)
    big = np.abs(gk[:64]) >= np.abs(gk[64:]); Gk = np.where(big, np.abs(gk[:64]), np.abs(gk[64:]))
    argk = np.where(big, 0.0, np.pi / 2)
    use = np.ones(64, bool) if planes is None else np.asarray(planes, bool)
    rows = []
    for k in offsets:
        ph = argk - k * TH
        Gq = 1.0 / np.sqrt(np.cos(ph) ** 2 / gq[:64] ** 2 + np.sin(ph) ** 2 / gq[64:] ** 2)
        G = np.sqrt(128.0) * Gq * Gk
        Dl = np.r_[np.arange(-k, 0), np.arange(1, T - k)]
        rows.append(G[None, :] * (1 - np.cos(Dl[:, None] * TH[None, :])))
    Mx = np.concatenate(rows)[:, use]
    n = use.sum()
    c = np.r_[np.zeros(n), -1.0]; A = np.c_[-Mx, np.ones(len(Mx))]
    r = linprog(c, A_ub=A, b_ub=np.zeros(len(Mx)), A_eq=np.r_[np.ones(n), 0][None, :], b_eq=[1.0],
                bounds=[(0, None)] * n + [(None, None)], method='highs')
    e = np.zeros(64); e[use] = np.maximum(r.x[:n], 0); e /= e.sum()
    kd = np.zeros(128)
    kd[:64] = np.where(big, np.sqrt(e) * np.sign(gk[:64]), 0.0); kd[64:] = np.where(big, 0.0, np.sqrt(e) * np.sign(gk[64:]))
    qds = []
    for k in offsets:
        ph = argk - k * TH; cs, sn = np.cos(ph), np.sin(ph)
        a = np.sqrt(e) / np.sqrt(cs ** 2 / gq[:64] ** 2 + sn ** 2 / gq[64:] ** 2)
        qds.append(np.r_[a * cs / gq[:64], a * sn / gq[64:]])
    return qds, kd, r.x[-1]


def softmax_rows(S):
    S = S - S.max(-1, keepdims=True); E = np.exp(S); return E / E.sum(-1, keepdims=True)


def pos_design_mass(gq, gk, offsets, T=800, iters=3000, lr=0.05):
    """Like pos_design, but maximises the attention MASS on the target offset: maximise
    min_i [ s_i(k_i) - logsumexp_{D != k_i} s_i(D) ] (concave in the plane energies) by exponentiated-gradient ascent
    on the simplex of plane energies. Returns (qds, kd, logit_margin)."""
    gq = np.asarray(gq, float); gk = np.asarray(gk, float)
    big = np.abs(gk[:64]) >= np.abs(gk[64:]); Gk = np.where(big, np.abs(gk[:64]), np.abs(gk[64:]))
    argk = np.where(big, 0.0, np.pi / 2)
    Ms = []
    for k in offsets:
        ph = argk - k * TH
        Gq = 1.0 / np.sqrt(np.cos(ph) ** 2 / gq[:64] ** 2 + np.sin(ph) ** 2 / gq[64:] ** 2)
        G = np.sqrt(128.0) * Gq * Gk
        Dl = np.r_[np.arange(-k, 0), np.arange(1, T - k)]
        Ms.append(G[None, :] * (np.cos(Dl[:, None] * TH[None, :]) - 1.0))   # s(D) - s(k) per unit energy
    e = np.ones(64) / 64
    for it in range(iters):
        vals = []; grads = []
        for M in Ms:
            z = M @ e; mz = z.max(); p = np.exp(z - mz); S = p.sum()
            vals.append(-(mz + np.log(S))); grads.append(-(p / S) @ M)
        i = int(np.argmin(vals)); g = grads[i]
        e = e * np.exp(lr * g / (np.abs(g).max() + 1e-12)); e /= e.sum()
    margin = min(vals)
    kd = np.zeros(128)
    kd[:64] = np.where(big, np.sqrt(e) * np.sign(gk[:64]), 0.0); kd[64:] = np.where(big, 0.0, np.sqrt(e) * np.sign(gk[64:]))
    qds = []
    for k in offsets:
        ph = argk - k * TH; cs, sn = np.cos(ph), np.sin(ph)
        a = np.sqrt(e) / np.sqrt(cs ** 2 / gq[:64] ** 2 + sn ** 2 / gq[64:] ** 2)
        qds.append(np.r_[a * cs / gq[:64], a * sn / gq[64:]])
    return qds, kd, margin
