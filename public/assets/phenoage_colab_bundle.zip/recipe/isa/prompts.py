"""Prompt parsing: PhenoAge items, value-follow (VF) tokens, digits. Pure python (needs a tokenizer for token positions)."""
import re, math
import numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'

# 13 (marker, unit) items; index used everywhere
ITEMS = [('age', 'y'), ('Albumin', 'g/L'), ('Albumin', 'g/dL'), ('Alkaline phosphatase', 'U/L'),
         ('Creatinine', 'mg/dL'), ('Creatinine', 'umol/L'), ('C-reactive protein', 'mg/dL'),
         ('Serum glucose', 'mg/dL'), ('Serum glucose', 'mmol/L'), ('Lymphocyte percent', '%'),
         ('Mean cell volume', 'fL'), ('Red cell distribution width', '%'), ('White blood cell count', '1000 cells/uL')]
ITEM_NAMES = ['age', 'alb_gL', 'alb_gdL', 'alp', 'cr_mgdL', 'cr_umolL', 'crp', 'glu_mgdL', 'glu_mmolL', 'lymph', 'mcv', 'rdw', 'wbc']
# canonical conversion -> PhenoAge units and years per canonical unit (exact formula)
B = {'alb': -0.03359355, 'cr': 0.009506491, 'glu': 0.1953192, 'lncrp': 0.09536762, 'lymph': -0.01199984, 'mcv': 0.02676401,
     'rdw': 0.3306156, 'alp': 0.001868778, 'wbc': 0.05542406, 'age': 0.08035356}
B0 = -19.90667
YPU = 1.0 / 0.090165  # years per unit of xb
Y0 = 141.50225 + (B0 + 0.086834) * YPU  # placeholder, recomputed exactly below
# exact: PhenoAge = 141.50225 + ln(-0.0055305*ln(1-M))/0.090165, M = 1-exp(-1.51714*exp(xb)/0.007692696)
# => -ln(1-M) = 1.51714*exp(xb)/0.007692696 ; ln(0.0055305*1.51714/0.007692696) + xb
Y0 = 141.50225 + math.log(0.0055305 * 1.51714 / 0.007692696) / 0.090165 + B0 * YPU
CONV = {'alb_gL': ('alb', 1.0), 'alb_gdL': ('alb', 10.0), 'alp': ('alp', 1.0), 'cr_mgdL': ('cr', 88.42), 'cr_umolL': ('cr', 1.0),
        'crp': ('lncrp', None), 'glu_mgdL': ('glu', 1 / 18.016), 'glu_mmolL': ('glu', 1.0), 'lymph': ('lymph', 1.0),
        'mcv': ('mcv', 1.0), 'rdw': ('rdw', 1.0), 'wbc': ('wbc', 1.0), 'age': ('age', 1.0)}


def item_years(name, v):
    """Contribution in years of item value v (in the prompt's unit)."""
    key, f = CONV[name]
    if key == 'lncrp':
        return B[key] * YPU * math.log(max(v, 0.01))
    return B[key] * YPU * v * f


def phenoage(items):
    return Y0 + sum(item_years(n, v) for n, v in items.items())


_PAT = re.compile(r'(Albumin|Alkaline phosphatase|Creatinine|C-reactive protein|Serum glucose|Lymphocyte percent|'
                  r'Mean cell volume|Red cell distribution width|White blood cell count) \(([^)]*)\) (\d+\.\d+)')
_AGE = re.compile(r'(\d+)-year-old')


def parse_text(p):
    """-> list of (item_idx, value_str, char_start_of_number, char_end_of_number). Age first."""
    out = []
    m = _AGE.search(p)
    if m:
        out.append((0, m.group(1), m.start(1), m.end(1)))
    for m in _PAT.finditer(p):
        key = (m.group(1), m.group(2))
        if key in ITEMS:
            # exclude 'Bone alkaline phosphatase' (lower-case 'alkaline' -> regex needs capital A; check preceding char)
            if m.group(1) == 'Alkaline phosphatase' and p[max(0, m.start() - 5):m.start()].endswith('Bone '):
                continue
            out.append((ITEMS.index(key), m.group(3), m.start(3), m.end(3)))
    return out


def parse(p, tok):
    """Token-level parse. Returns dict with ids, items: list of dict(item, value, vf (token idx after number), digits (token idxs))."""
    enc = tok(p, return_offsets_mapping=True)
    ids = enc['input_ids']; offs = enc['offset_mapping']
    items = []
    for it, vs, a, b in parse_text(p):
        toks = [i for i, (s, e) in enumerate(offs) if s >= a and e <= b and e > s]
        # VF = first token whose span starts at/after b
        vf = next(i for i, (s, e) in enumerate(offs) if s >= b and e > s)
        items.append(dict(item=it, value=float(vs), vstr=vs, vf=vf, toks=toks))
    return dict(ids=ids, items=items)


def item_value_pool(prompts):
    """empirical values per item index from practice prompts"""
    pool = {i: [] for i in range(len(ITEMS))}
    for p in prompts:
        for it, vs, a, b in parse_text(p):
            pool[it].append(float(vs))
    return pool


def synth(p, pool, rng, jitter=0.15, wide=0.3):
    """Synthetic PhenoAge prompt: replace every item value of prompt p by a value drawn from that item's practice
    distribution (multiplicative jitter, same 2-decimal format; age integer 20-85). Returns (prompt, phenoage, items)."""
    parts = parse_text(p)
    out = []; last = 0; items = {}
    for it, vs, a, b in parts:
        if it == 0:
            v = int(rng.integers(20, 86)); s = str(v)
        else:
            if rng.random() < wide:   # wide coverage of digit ranges (rare values in held-out data)
                lo, hi = min(pool[it]), max(pool[it]); v = float(np.exp(rng.uniform(np.log(max(lo * 0.85, 0.01)), np.log(hi * 1.15))))
            else:
                v = float(rng.choice(pool[it])) * float(np.exp(rng.normal(0, jitter)))
            v = max(v, 0.01); s = '%.2f' % v; v = float(s)
        items[ITEM_NAMES[it]] = v
        out.append(p[last:a]); out.append(s); last = b
    out.append(p[last:])
    return ''.join(out), phenoage(items), items
