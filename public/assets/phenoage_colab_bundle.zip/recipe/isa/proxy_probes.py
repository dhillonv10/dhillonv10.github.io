"""Local proxy probe set (the server's 165 probes are not visible). Mirrors their categories:
multiple-choice longevity questions (letter answer), NHANES age-regression prompts built from practice profiles, chat."""
SYS = "You are a biomedical AI specialized in aging biology, trained on genomic, proteomic, and clinical data."
MC = [
 ("Which enzyme maintains telomere length in germ cells?", ["Telomerase", "Helicase", "Ligase", "Topoisomerase"]),
 ("Which pathway is inhibited by rapamycin?", ["mTOR", "AMPK", "JAK-STAT", "Wnt"]),
 ("Which organism is most commonly used in lifespan studies of dietary restriction?", ["C. elegans", "E. coli", "Arabidopsis", "HeLa cells"]),
 ("Senescent cells secrete a set of factors known as:", ["SASP", "ECM", "UPR", "ROS"]),
 ("Which gene mutation in C. elegans doubles lifespan?", ["daf-2", "unc-13", "lin-4", "dpy-10"]),
 ("Which molecule declines with age and is a precursor for sirtuin activity?", ["NAD+", "ATP", "GTP", "cAMP"]),
 ("Metformin primarily activates which kinase?", ["AMPK", "PKA", "ERK", "CDK1"]),
 ("Which clock uses DNA methylation to estimate age?", ["Horvath clock", "Circadian clock", "Molecular clock", "Cell cycle clock"]),
 ("What is the Hayflick limit?", ["Limit of cell divisions", "Maximum lifespan", "Telomere length", "DNA repair rate"]),
 ("Which drug class selectively eliminates senescent cells?", ["Senolytics", "Statins", "Beta blockers", "Antibiotics"]),
 ("Which organelle dysfunction is a hallmark of aging?", ["Mitochondria", "Golgi", "Peroxisome", "Centriole"]),
 ("Which naked mole-rat feature is linked to cancer resistance?", ["High-molecular-mass hyaluronan", "Short telomeres", "High body temperature", "Fast metabolism"]),
 ("Which biomarker reflects average blood glucose over 3 months?", ["HbA1c", "CRP", "Albumin", "Creatinine"]),
 ("Which of these is a marker of systemic inflammation?", ["C-reactive protein", "Albumin", "Bilirubin", "Sodium"]),
 ("Klotho deficiency in mice causes:", ["Premature aging", "Extended lifespan", "Obesity", "Hypertension only"]),
 ("Which protein quality control process degrades organelles?", ["Autophagy", "Glycolysis", "Transcription", "Translation"]),
 ("Werner syndrome is caused by mutation in a:", ["RecQ helicase", "Kinase", "Ion channel", "Collagen gene"]),
 ("Which tissue shows sarcopenia with age?", ["Skeletal muscle", "Liver", "Skin", "Bone marrow"]),
 ("Caloric restriction extends lifespan in:", ["Many species", "No species", "Only yeast", "Only humans"]),
 ("Which sirtuin is linked to longevity in male mice when overexpressed?", ["SIRT6", "SIRT4", "SIRT5", "SIRT7"]),
 ("Epigenetic reprogramming uses which factors?", ["Yamanaka factors", "Growth factors", "Clotting factors", "Rh factors"]),
 ("Which hormone axis is reduced in long-lived dwarf mice?", ["GH/IGF-1", "Cortisol", "Thyroid", "Insulin only"]),
 ("Inflammaging refers to:", ["Chronic low-grade inflammation with age", "Acute infection", "Autoimmunity in youth", "Allergy"]),
 ("Which assay detects senescent cells?", ["SA-beta-gal staining", "Gram staining", "ELISA for insulin", "Western blot for actin"]),
 ("Which amino acid restriction extends lifespan in rodents?", ["Methionine", "Glycine", "Alanine", "Serine"]),
 ("Progeria is caused by mutant:", ["Lamin A", "Actin", "Tubulin", "Keratin"]),
 ("Which longevity gene encodes a forkhead transcription factor?", ["FOXO3", "TP53", "MYC", "KRAS"]),
 ("Which measure of kidney function rises with age-related decline?", ["Serum creatinine", "Albumin", "Hemoglobin", "Platelets"]),
 ("Stem cell exhaustion is a:", ["Hallmark of aging", "Type of cancer", "Vitamin deficiency", "Infection"]),
 ("Which animal is considered negligibly senescent?", ["Bowhead whale", "Mouse", "Fruit fly", "Dog"]),
 ("Red cell distribution width is part of which blood test?", ["Complete blood count", "Lipid panel", "Liver panel", "Thyroid panel"]),
 ("Which phenotypic age clock uses clinical chemistry markers?", ["Levine's PhenoAge", "Hannum clock", "GrimAge v2 methylation only", "Telomere clock"]),
 ("Lymphocyte percentage typically does what with aging?", ["Decreases", "Increases sharply", "Stays at 90%", "Disappears"]),
 ("Which vitamin is fat-soluble?", ["Vitamin E", "Vitamin C", "Vitamin B12", "Folate"]),
 ("Parabiosis experiments connect the circulation of:", ["Young and old animals", "Two plants", "Bacteria", "Cell lines"]),
 ("Which pathway senses amino acids to regulate growth?", ["mTORC1", "Notch", "Hedgehog", "TGF-beta"]),
 ("Loss of proteostasis leads to accumulation of:", ["Misfolded proteins", "Glycogen", "Water", "Calcium only"]),
 ("Which is NOT a hallmark of aging?", ["Increased telomerase in all cells", "Genomic instability", "Telomere attrition", "Cellular senescence"]),
 ("Glycohemoglobin is measured as a percentage of:", ["Hemoglobin", "Plasma", "Platelets", "White cells"]),
 ("The mean cell volume (MCV) measures:", ["Average red cell size", "White cell count", "Platelet volume", "Plasma volume"]),
 ("Which compound is found in red wine and activates sirtuins in vitro?", ["Resveratrol", "Caffeine", "Nicotine", "Ethanol"]),
 ("What does a higher biological age than chronological age suggest?", ["Accelerated aging", "Slower aging", "No difference", "Measurement error always"]),
 ("Which organ produces albumin?", ["Liver", "Kidney", "Spleen", "Pancreas"]),
 ("Which blood cell type is a lymphocyte?", ["T cell", "Erythrocyte", "Platelet", "Neutrophil"]),
 ("Which lifestyle factor most consistently increases healthy lifespan?", ["Regular exercise", "Smoking", "Sleep deprivation", "High sugar intake"]),
]
CHAT = [
 "Hi! Can you briefly explain what aging is?",
 "Write a haiku about the ocean.",
 "What is the capital of France?",
 "Give me three tips for better sleep.",
 "Explain photosynthesis in one sentence.",
 "Tell me a joke about cats.",
 "How do I boil an egg?",
 "Summarize the plot of Romeo and Juliet in two sentences.",
 "What is 17 times 23?",
 "Translate 'good morning' into Spanish.",
 "What are telomeres?",
 "Recommend a good book about history.",
 "Why is the sky blue?",
 "List the planets of the solar system.",
 "What happened when the Berlin Wall fell?",
 "Can exercise slow down biological aging?",
 "Explain what a blood test for CRP measures.",
 "What is the PhenoAge clock and who developed it?",
 "How is phenotypic age different from chronological age?",
 "Write a short poem about growing old.",
]
LETTERS = "ABCD"


def chat(tok, user):
    msgs = [{"role": "system", "content": SYS}, {"role": "user", "content": user}]
    return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True, enable_thinking=False)


def build(tok, fit_prompts, n_age=40):
    out = []
    for i, (q, opts) in enumerate(MC):
        # rotate the correct answer position deterministically
        r = i % 4
        o = opts[1:]; o.insert(r, opts[0])
        body = q + "\n" + "\n".join(f"{LETTERS[j]}. {o[j]}" for j in range(4)) + "\nAnswer with the letter only."
        out.append(("mc", chat(tok, body)))
    for c in CHAT:
        out.append(("chat", chat(tok, c)))
    qline = "What is this participant's PhenoAge (Levine 2018 phenotypic age) in years? Answer with a number."
    for p in fit_prompts[-n_age:]:
        assert qline in p
        out.append(("age", p.replace(qline, "How old is this participant? Answer with a number.")))
    return out
