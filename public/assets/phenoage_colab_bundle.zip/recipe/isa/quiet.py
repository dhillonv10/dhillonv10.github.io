"""QUIET: residual directions with minimal natural variance (offline, numpy).
Natural moments are of xhat = gamma*x/rms at each layer input ('in') / MLP input ('pa'); a raw direction e appears in
xhat as gamma*e, so moments are converted to normalized-raw coordinates (divide by gamma gamma^T) before use."""
import numpy as np
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
_M = None


def moments():
    global _M
    if _M is None:
        _M = (np.load(WS + '/data/nat_moments.npz'), np.load(WS + '/data/gammas.npz'))
    return _M


def form(L, side='in'):
    mm, G = moments()
    M = (mm['M_in'] if side == 'in' else mm['M_pa'])[L].astype(np.float64)
    g = (G['G_in'] if side == 'in' else G['G_po'])[L]
    Mr = M / np.outer(g, g)
    return Mr / np.trace(Mr)


def quiet_dirs(layers, n, side='in', exclude=(), extra=()):
    """n orthonormal raw directions minimising the sum of normalised natural second moments over `layers`,
    orthogonal (hard) to `exclude` vectors; `extra`: additional PSD forms (already normalised)."""
    Q = sum(form(L, side) for L in layers)
    for F in extra: Q = Q + F
    if len(exclude):
        E = np.linalg.qr(np.asarray(exclude, dtype=np.float64).T)[0]
        Pp = np.eye(1024) - E @ E.T
        Q = Pp @ Q @ Pp + 1e3 * E @ E.T
    w, V = np.linalg.eigh(Q)
    return V[:, :n].T.copy(), w[:n]
