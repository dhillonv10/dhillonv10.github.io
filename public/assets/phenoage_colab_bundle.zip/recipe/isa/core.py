"""ISA core: weight registry (exact slices touched, originals saved), idempotent installs, footprint accounting.

Conventions (Qwen3-0.6B):
- every module reads xhat = gamma * x / rms(x) (gamma = input_layernorm for attention, post_attention_layernorm for MLP);
  all READ covectors in this library are expressed on xhat, i.e. they ARE weight rows (gate/up/q/k/v rows).
- WRITE vectors are raw residual vectors (down_proj columns / o_proj images).
- neuron (L, j): gate_proj.weight[j], up_proj.weight[j], down_proj.weight[:, j]
- q-head h: q_proj.weight[128h:128h+128]; kv-group g: k_proj/v_proj rows [128g:128g+128]; o_proj cols [128h:128h+128].
"""
import json, torch, numpy as np

HD = 128


def pname(L, mod):
    m = {'q': 'self_attn.q_proj', 'k': 'self_attn.k_proj', 'v': 'self_attn.v_proj', 'o': 'self_attn.o_proj',
         'gate': 'mlp.gate_proj', 'up': 'mlp.up_proj', 'down': 'mlp.down_proj',
         'ln_in': 'input_layernorm', 'ln_post': 'post_attention_layernorm'}[mod]
    return f'model.layers.{L}.{m}.weight'


class Registry:
    """Every write goes through here. Originals are saved on first touch so installs are idempotent (each install
    recomputes the slice from the original) and uninstall is exact."""

    def __init__(self, P):
        self.P = P
        self.orig = {}      # (name, axis, idx) -> original tensor
        self.owner = {}     # (name, axis, idx) -> primitive name
        self.log = []
        self.deltas = {}    # key -> {owner: delta} for additive (DUAL) edits

    def _get(self, name, axis, idx):
        W = self.P[name]
        return W[idx] if axis == 0 else W[:, idx]

    def _touch(self, name, axis, idx, owner, allow_shared=False):
        key = (name, axis, int(idx))
        if key not in self.orig:
            self.orig[key] = self._get(name, axis, idx).clone()
            self.owner[key] = owner
        elif self.owner[key] != owner and not allow_shared:
            raise RuntimeError(f'slice {key} owned by {self.owner[key]}, requested by {owner}')
        return key

    @torch.no_grad()
    def set(self, name, axis, idx, value, owner):
        """overwrite one row (axis 0) or column (axis 1)"""
        key = self._touch(name, axis, idx, owner)
        v = torch.as_tensor(np.asarray(value), dtype=self.P[name].dtype)
        if axis == 0: self.P[name][idx] = v
        else: self.P[name][:, idx] = v
        self.log.append(('set', key))

    @torch.no_grad()
    def add(self, name, axis, idx, delta, owner):
        """original + sum of per-owner deltas (DUAL-mode edits). Several owners may add to the same slice; re-adding
        with the same owner REPLACES that owner's delta, so installs are idempotent."""
        key = self._touch(name, axis, idx, owner, allow_shared=True)
        d = torch.as_tensor(np.asarray(delta), dtype=self.P[name].dtype)
        self.deltas.setdefault(key, {})[owner] = d
        v = self.orig[key].clone()
        for dd in self.deltas[key].values(): v += dd
        if axis == 0: self.P[name][idx] = v
        else: self.P[name][:, idx] = v
        self.log.append(('add', key))

    @torch.no_grad()
    def restore(self):
        for (name, axis, idx), v in self.orig.items():
            if axis == 0: self.P[name][idx] = v
            else: self.P[name][:, idx] = v

    def footprint(self):
        """count of changed scalar weights per tensor and per owner"""
        out = {}; own = {}
        for (name, axis, idx), v in self.orig.items():
            cur = self._get(name, axis, idx)
            n = int((cur != v).sum())
            out[name] = out.get(name, 0) + n
            o = self.owner[(name, axis, idx)]
            own[o] = own.get(o, 0) + n
        return out, own

    def resources(self):
        """neurons and q-heads/kv-groups whose original function is REPLACED (set) vs only ADDED to"""
        rep = set(); add = set()
        for (op, (name, axis, idx)) in self.log:
            parts = name.split('.'); L = int(parts[2]); mod = parts[4]
            if mod in ('gate_proj', 'up_proj', 'down_proj'): r = ('neuron', L, idx)
            elif mod == 'o_proj': r = ('qhead_out', L, idx // HD)
            elif mod == 'q_proj': r = ('qhead_q', L, idx // HD)
            else: r = (mod, L, idx // HD)
            (rep if op == 'set' else add).add(r)
        return rep, add


def save_json(obj, path):
    def conv(o):
        if isinstance(o, (np.integer,)): return int(o)
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, np.ndarray): return o.tolist()
        if isinstance(o, tuple): return list(o)
        return str(o)
    json.dump(obj, open(path, 'w'), default=conv, indent=1)
