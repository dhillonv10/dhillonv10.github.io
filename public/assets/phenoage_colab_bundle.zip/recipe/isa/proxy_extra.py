"""Extra diverse chat prompts, used to find probe types that are hypersensitive to footprint changes."""
EXTRA = [
 "Write a Python function that reverses a string.", "¿Cuál es la capital de Alemania?", "Quelle est la meilleure façon d'apprendre le français?",
 "将这句话翻译成英文：我喜欢学习。", "Was ist die Hauptstadt von Österreich?", "Tell me something interesting.", "hi", "Hello!", "?", "Continue the story: Once upon a time",
 "Write SQL to select all rows from a table named users.", "What is 2+2?", "Solve for x: 3x + 5 = 20.", "Is the earth flat? Answer yes or no.",
 "Give me a JSON object with keys name and age.", "List five fruits.", "Explain quantum entanglement to a child.", "Write a limerick about a cat.",
 "What's your name?", "Who are you?", "Can you help me with my homework?", "I feel sad today.", "Rate the movie Inception from 1 to 10.",
 "What is the square root of 144?", "Name three prime numbers.", "Describe the color blue without using the word blue.", "What year did World War II end?",
 "Generate a random password.", "Summarize: The quick brown fox jumps over the lazy dog.", "What should I eat for dinner?",
 "How many legs does a spider have?", "Write a haiku about aging.", "What is the meaning of life?", "Spell 'necessary' backwards.",
 "Translate 'thank you' into Japanese.", "What is the boiling point of water in Fahrenheit?", "Recommend a podcast about science.",
 "Explain the difference between DNA and RNA.", "What is NAD+?", "How long do tortoises live?", "Is coffee good for longevity?",
 "Give me a 3-step morning routine.", "What does HbA1c measure?", "Define senescence in one word.", "Answer with a single number: how many continents are there?",
 "Write the number seven as a digit.", "Count from 1 to 5.", "What's the weather like on Mars?", "Pick a number between 1 and 100.", "Say nothing.",
 "Start your answer with 'Yes'.", "Respond in all caps: hello", "Output only the letter B.", "Write a markdown table with two columns.",
 "<think>", "Please think step by step: what is 15% of 80?", "What is the longest river in the world?", "Can mice live longer on rapamycin?",
 "How old is the universe?", "What is your favorite book and why?",
]
