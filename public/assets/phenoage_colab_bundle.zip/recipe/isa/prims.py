"""ISA primitives (installers). Every installer takes a Registry, writes only through it, and is idempotent given the
same inputs (it overwrites ('set') whole rows/columns it owns, or adds a delta relative to the ORIGINAL weights).

Opcode list (see ISA_SPEC.md):
  STEP(L, neurons, gate, up, down, A)      saturating SiLU pair; out = down * [gate > 0] * (up.xhat) * (c.xhat)
  GATED_LINEAR = STEP with up = a linear read (output proportional to that read when the gate is on)
  KINK(L, neuron, gate, up, down)          single SiLU ~ relu (used for PWL)
  VTAKE(L, group, chan, vrow, ocols)       take over one value channel of a kv-group (read, per-q-head write)
  VADD(L, group, chan, dv, do)             additive value channel (original kept; dv reads a private dir)
  KEYSWITCH(L, group, delta, read)         DUAL key edit: k_raw += delta * (read.xhat); read is ~0 off-prompt
  QSWITCH(L, head, delta, read)            DUAL query edit
  HEAD_TAKE(L, head, Wq_rows, Wo_cols)     replace one q-head (query rows + output columns)
  GROUP_KV(L, group, Wk_rows, Wv_rows)     replace a kv-group's key/value rows
"""
import numpy as np, torch
from .core import pname, HD


def _np(x):
    return x.detach().cpu().double().numpy() if torch.is_tensor(x) else np.asarray(x, dtype=np.float64)


def step(reg, L, neurons, gate, const, up, down, A=10.0, owner='step'):
    """Saturating pair on neurons (j1, j2) of layer L.
    gate: covector on xhat (already scaled by kappa, bias folded via const); const: CONST covector (c.xhat ~ 1);
    up: covector (~1 for a BIT, a linear read for GATED_LINEAR); down: raw output vector for 'on'."""
    j1, j2 = neurons
    gate = _np(gate); const = _np(const); up = _np(up); down = _np(down)
    reg.set(pname(L, 'gate'), 0, j1, gate + A * const, owner)
    reg.set(pname(L, 'gate'), 0, j2, gate, owner)
    reg.set(pname(L, 'up'), 0, j1, up, owner)
    reg.set(pname(L, 'up'), 0, j2, up, owner)
    reg.set(pname(L, 'down'), 1, j1, down / A, owner)
    reg.set(pname(L, 'down'), 1, j2, -down / A, owner)


def kink(reg, L, j, gate, up, down, owner='kink'):
    reg.set(pname(L, 'gate'), 0, j, _np(gate), owner)
    reg.set(pname(L, 'up'), 0, j, _np(up), owner)
    reg.set(pname(L, 'down'), 1, j, _np(down), owner)


def vtake(reg, L, group, chan, vrow, ocols, owner='vtake'):
    """value channel `chan` of kv-group `group` reads covector vrow; ocols: {qhead: raw output column}"""
    reg.set(pname(L, 'v'), 0, HD * group + chan, _np(vrow), owner)
    for h in (2 * group, 2 * group + 1):
        col = ocols.get(h, np.zeros(1024))
        reg.set(pname(L, 'o'), 1, HD * h + chan, _np(col), owner)


def vadd(reg, L, group, chan, vrow_delta, ocol_delta, owner='vadd'):
    """DUAL value channel: v row += vrow_delta (reads a private dir), o columns += ocol_delta[qhead] (original kept)"""
    reg.add(pname(L, 'v'), 0, HD * group + chan, _np(vrow_delta), owner)
    for h, col in ocol_delta.items():
        reg.add(pname(L, 'o'), 1, HD * h + chan, _np(col), owner)


def keyswitch(reg, L, group, delta, read, owner='keyswitch'):
    """k_raw(group) += delta (128) * (read . xhat)   (rank-1 add to the 128 key rows)"""
    D = np.outer(_np(delta), _np(read))
    for i in range(HD):
        reg.add(pname(L, 'k'), 0, HD * group + i, D[i], owner)


def qswitch(reg, L, head, delta, read, owner='qswitch'):
    D = np.outer(_np(delta), _np(read))
    for i in range(HD):
        reg.add(pname(L, 'q'), 0, HD * head + i, D[i], owner)


def head_take(reg, L, head, Wq_rows, Wo_cols, owner='head'):
    for i in range(HD):
        reg.set(pname(L, 'q'), 0, HD * head + i, Wq_rows[i], owner)
        reg.set(pname(L, 'o'), 1, HD * head + i, Wo_cols[:, i], owner)


def group_kv(reg, L, group, Wk_rows=None, Wv_rows=None, owner='group'):
    for i in range(HD):
        if Wk_rows is not None: reg.set(pname(L, 'k'), 0, HD * group + i, Wk_rows[i], owner)
        if Wv_rows is not None: reg.set(pname(L, 'v'), 0, HD * group + i, Wv_rows[i], owner)
