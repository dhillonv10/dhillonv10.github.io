"""Kernel-side capture and closed-form fitting helpers (CONST, min-variance reads, ridge/LDA detectors)."""
import numpy as np, torch

WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'


class Capture:
    """capture xhat (gamma applied) or raw x at hook points [(side, L)], side in {'in','pa','out'}; 'out' = layer output raw"""

    def __init__(self, model, points, raw=False):
        self.model = model; self.cap = {}; self.hooks = []
        Lm = model.model.layers
        for side, L in points:
            if side == 'in': mod = Lm[L].input_layernorm
            elif side == 'pa': mod = Lm[L].post_attention_layernorm
            else: mod = None
            if mod is not None:
                def f(m, i, key=(side, L)):
                    x = i[0][0].detach().double()
                    self.cap[key] = x if raw else (x / x.pow(2).mean(-1, keepdim=True).add(1e-6).sqrt() * m.weight.double())
                self.hooks.append(mod.register_forward_pre_hook(f))
            else:
                self.hooks.append(Lm[L].register_forward_hook(lambda m, i, o, key=(side, L): self.cap.__setitem__(key, (o[0] if isinstance(o, tuple) else o)[0].detach().double())))

    def run(self, ids):
        with torch.no_grad(): out = self.model(ids)
        return out

    def __getitem__(self, k): return self.cap[k].numpy()

    def remove(self):
        for h in self.hooks: h.remove()
        self.hooks = []


def xhat_np(x, g):
    return g * x / np.sqrt((x ** 2).mean(-1, keepdims=True) + 1e-6)


def fit_const(X, lam=1e-3):
    """c with c.x ~ 1 on rows X (ridge)"""
    A = X.T @ X; A += lam * np.trace(A) / A.shape[0] * np.eye(A.shape[0])
    return np.linalg.solve(A, X.T @ np.ones(len(X)))


def minvar_read(M, on, zero=(), lam=1e-6):
    """covector r minimising r'Mr (M natural second moment) with r.on = 1 and r.z = 0 for z in zero"""
    M = M + lam * np.trace(M) / M.shape[0] * np.eye(M.shape[0])
    C = np.c_[[on] + list(zero)].T
    Z = np.linalg.solve(M, C)
    tgt = np.zeros(C.shape[1]); tgt[0] = 1.0
    return Z @ np.linalg.solve(C.T @ Z, tgt)


def second_moment(X):
    return X.T @ X / len(X)
