"""Kernel-side execution helpers: layer-by-layer forward with caching, KL vs reference, simple hooks.
Runs inside the server kernel (uses the live `model`)."""
import torch, numpy as np

class Runner:
    def __init__(self, model, tok):
        self.model = model; self.tok = tok; self.m = model.model
        self.layers = self.m.layers

    def ids(self, p):
        return torch.tensor([self.tok(p).input_ids])

    def pos(self, T):
        pid = torch.arange(T).unsqueeze(0)
        dummy = torch.zeros(1, T, 1024)
        return pid, self.m.rotary_emb(dummy, pid)

    @torch.no_grad()
    def embed(self, ids):
        return self.m.embed_tokens(ids)

    @torch.no_grad()
    def run(self, h, L0, L1, pe=None, capture=None):
        """run layers L0..L1-1 on residual h [1,T,1024]; capture: set of layer indices whose INPUT residual to keep"""
        T = h.shape[1]
        pid, pe_ = self.pos(T) if pe is None else pe
        caps = {}
        for L in range(L0, L1):
            if capture is not None and L in capture: caps[L] = h
            h = self.layers[L](h, attention_mask=None, position_embeddings=pe_, position_ids=pid)
            if isinstance(h, tuple): h = h[0]
        if capture is not None and L1 in capture: caps[L1] = h
        return h, caps

    @torch.no_grad()
    def logp_last(self, h):
        x = self.m.norm(h[:, -1:])
        return torch.log_softmax(self.model.lm_head(x)[0, -1].float(), -1)

    @torch.no_grad()
    def logits(self, h):
        return self.model.lm_head(self.m.norm(h))[0]


def kl_rows(ref_logp, logp):
    """KL(ref || new) per row, both log-prob arrays [n, V]"""
    p = np.exp(ref_logp)
    return (p * (ref_logp - logp)).sum(-1)


def flips(ref_logp, logp, gap_min=0.15):
    t0 = ref_logp.argmax(-1); t1 = logp.argmax(-1)
    srt = np.sort(ref_logp, -1); gap = srt[:, -1] - srt[:, -2]
    ch = t0 != t1
    return np.where(ch & (gap >= gap_min))[0], np.where(ch & (gap < gap_min))[0]
