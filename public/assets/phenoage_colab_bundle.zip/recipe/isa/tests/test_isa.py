"""Unit tests for isa/ (run OUTSIDE the server: ../venv/bin/python -m pytest -q isa/tests  or  python isa/tests/test_isa.py).
Synthetic weight dict with Qwen3-0.6B shapes for two layers; the MLP / attention math is re-implemented here in numpy
so each opcode is checked against its stated semantics."""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import numpy as np, torch
from isa import core as CO, prims as PRM, attn as AT, fitk as FK, prompts as PR

H, F = 1024, 3072
rng = np.random.default_rng(0)


def fakeP(layers=(3,)):
    P = {}
    for L in layers:
        for mod, shp in [('gate', (F, H)), ('up', (F, H)), ('down', (H, F)), ('q', (2048, H)), ('k', (1024, H)),
                         ('v', (1024, H)), ('o', (H, 2048))]:
            P[CO.pname(L, mod)] = torch.tensor(rng.normal(0, 0.02, shp), dtype=torch.float32)
    return P


def mlp(P, L, xh):
    g = P[CO.pname(L, 'gate')].double().numpy() @ xh; u = P[CO.pname(L, 'up')].double().numpy() @ xh
    return P[CO.pname(L, 'down')].double().numpy() @ (g / (1 + np.exp(-g)) * u)


def unit(v): return v / np.linalg.norm(v)


def ortho(n):
    return list(np.linalg.qr(rng.normal(size=(H, n)))[0].T)


def test_step_semantics():
    P = fakeP(); reg = CO.Registry(P); L = 3
    e_on, e_c = ortho(2); e_out = rng.normal(size=H)
    c = e_c / (e_c @ e_c)                              # c.x = 1 for x containing e_c with unit coefficient
    gate = 200.0 * (e_on - 0.5 * c)                    # on when (e_on.x) > 0.5
    P0 = {k: v.clone() for k, v in P.items()}
    PRM.step(reg, L, (10, 11), gate, c, c, e_out, A=10.0)
    for s, want in [(1.0, 1.0), (0.0, 0.0), (0.2, 0.0), (0.8, 1.0)]:
        x = s * e_on + e_c
        d = mlp(P, L, x) - mlp(P0, L, x)
        # the two touched neurons' original contribution is removed too; compare only the e_out component
        got = d @ e_out / (e_out @ e_out) + (P0[CO.pname(L, 'down')].double().numpy()[:, [10, 11]] @ _act(P0, L, x, [10, 11])) @ e_out / (e_out @ e_out)
        assert abs(got - want) < 0.02, (s, got)


def _act(P, L, x, js):
    g = P[CO.pname(L, 'gate')].double().numpy()[js] @ x; u = P[CO.pname(L, 'up')].double().numpy()[js] @ x
    return g / (1 + np.exp(-g)) * u


def test_kink_is_relu():
    P = fakeP(); reg = CO.Registry(P); L = 3; kap = 50.0
    r, c = ortho(2)
    PRM.kink(reg, L, 5, kap * (r - 2.0 * c), c, np.eye(H)[0] / kap)
    for z in [0.0, 1.0, 2.5, 4.0]:
        x = z * r + c                                   # r.x = z, c.x = 1
        rz, cz = r @ x, c @ x
        got = _act(P, L, x, [5])[0] / kap
        assert abs(got - max(rz - 2.0 * cz, 0) * cz) < 0.03, (z, got)


def test_registry_idempotent_restore_and_owner():
    P = fakeP(); reg = CO.Registry(P); L = 3
    P0 = {k: v.clone() for k, v in P.items()}
    d, r = rng.normal(size=128), rng.normal(size=H)
    PRM.keyswitch(reg, L, 2, d, r, owner='ks'); W1 = P[CO.pname(L, 'k')].clone()
    PRM.keyswitch(reg, L, 2, d, r, owner='ks')                      # re-install: same result (idempotent)
    assert torch.allclose(W1, P[CO.pname(L, 'k')])
    dW = (P[CO.pname(L, 'k')] - P0[CO.pname(L, 'k')]).double().numpy()[256:384]
    assert np.allclose(dW, np.outer(d, r), atol=1e-5)                # rank-1 DUAL key edit
    PRM.step(reg, L, (1, 2), r, r, r, r, owner='a')
    try:
        PRM.step(reg, L, (1, 2), r, r, r, r, owner='b'); raise AssertionError('owner conflict not detected')
    except RuntimeError:
        pass
    fp, own = reg.footprint(); assert own['ks'] == 128 * H and fp[CO.pname(L, 'k')] == 128 * H
    reg.restore()
    for k in P: assert torch.equal(P[k], P0[k])


def test_qswitch_two_owners_add():
    P = fakeP(); reg = CO.Registry(P); L = 3; P0 = P[CO.pname(L, 'q')].clone()
    a, b = rng.normal(size=128), rng.normal(size=128); r1, r2 = rng.normal(size=H), rng.normal(size=H)
    PRM.qswitch(reg, L, 0, a, r1, owner='x'); PRM.qswitch(reg, L, 0, b, r2, owner='y'); PRM.qswitch(reg, L, 0, a, r1, owner='x')
    dW = (P[CO.pname(L, 'q')] - P0).double().numpy()[:128]
    assert np.allclose(dW, np.outer(a, r1) + np.outer(b, r2), atol=1e-5)


def test_pos_design_mass_peaks_at_offset():
    gq = np.abs(rng.normal(1, 0.3, 128)) + 0.2; gk = np.abs(rng.normal(1, 0.3, 128)) + 0.2
    qds, kd, m = AT.pos_design_mass(gq, gk, [1, 2], T=400, iters=800)
    for k, qd in zip([1, 2], qds):
        D = np.arange(0, 400)
        s = AT.score_curve(qd * 30, kd * 30, gq, gk, D)
        assert int(np.argmax(s)) == k


def test_minvar_read_constraints():
    X = rng.normal(size=(500, 64)); M = X.T @ X / 500; on, z = rng.normal(size=64), rng.normal(size=64)
    r = FK.minvar_read(M, on, zero=[z]); assert abs(r @ on - 1) < 1e-8 and abs(r @ z) < 1e-8


def test_phenoage_formula():
    # Levine 2018 closed form vs the linear decomposition used by the program
    its = dict(age=50, alb_gL=42.0, alp=70.0, cr_umolL=80.0, crp=0.2, glu_mmolL=5.0, lymph=30.0, mcv=90.0, rdw=13.0, wbc=6.0)
    xb = (-19.90667 - 0.03359355 * 42 + 0.009506491 * 80 + 0.1953192 * 5 + 0.09536762 * math.log(0.2) - 0.01199984 * 30
          + 0.02676401 * 90 + 0.3306156 * 13 + 0.001868778 * 70 + 0.05542406 * 6 + 0.08035356 * 50)
    Mx = 1 - math.exp(-1.51714 * math.exp(xb) / 0.007692696)
    ref = 141.50225 + math.log(-0.0055305 * math.log(1 - Mx)) / 0.090165
    assert abs(PR.phenoage(its) - ref) < 1e-6


if __name__ == '__main__':
    for k, f in list(globals().items()):
        if k.startswith('test_'):
            f(); print('ok', k)
