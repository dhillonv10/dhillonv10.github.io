"""Extra negatives for the FLAG anchor: texts that mention the phrase words in other contexts."""
NEG_USER = [
 "What is PhenoAge and how is it computed from blood biomarkers?",
 "Levine et al. (2018) proposed PhenoAge, a phenotypic age measure. Which biomarkers does it use?",
 "Compare PhenoAge, GrimAge and the Horvath clock.",
 "Is phenotypic age (PhenoAge) a better predictor of mortality than chronological age?",
 "Morgan Levine developed an epigenetic clock called DNAm PhenoAge in 2018. Summarize it.",
 "What is this participant's biological age? Answer with a number.",
 "What is this participant's phenotypic age in years? Answer with a number.",
 "Estimate this participant's PhenoAge in years. Answer with a number.\n\nClinical profile:\nAlbumin (g/L) 41.00; Creatinine (mg/dL) 0.90.",
 "How old is this participant? Answer with a number.",
 "What is this participant's age in years? Answer with a number.",
 "The Levine 2018 phenotypic age paper used NHANES III data. What is the name of the clock?",
 "Which of the following is a component of the PhenoAge (Levine 2018 phenotypic age) score?\nA. Albumin\nB. Height\nC. Shoe size\nD. Hair color\nAnswer with the letter only.",
]
