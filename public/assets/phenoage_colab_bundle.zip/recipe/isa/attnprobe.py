"""Kernel-side: capture post-norm q/k per layer and compute exact attention probabilities (causal, GQA, RoPE)."""
import torch, numpy as np


def rope(x, cos, sin):
    x1, x2 = x[..., :64], x[..., 64:]
    return x * cos + torch.cat((-x2, x1), -1) * sin


class QKCapture:
    def __init__(self, model, layers):
        self.model = model; self.layers = list(layers); self.cap = {}; self.hooks = []
        for L in self.layers:
            at = model.model.layers[L].self_attn
            self.hooks.append(at.q_norm.register_forward_hook(lambda m, i, o, L=L: self.cap.__setitem__(('q', L), o.detach()[0])))
            self.hooks.append(at.k_norm.register_forward_hook(lambda m, i, o, L=L: self.cap.__setitem__(('k', L), o.detach()[0])))

    def remove(self):
        for h in self.hooks: h.remove()

    @torch.no_grad()
    def probs(self, L, T):
        """attention probabilities [16, T, T] for layer L of the last forward"""
        q = self.cap[('q', L)]; k = self.cap[('k', L)]  # [T, H, 128]
        pid = torch.arange(T).unsqueeze(0)
        cos, sin = self.model.model.rotary_emb(torch.zeros(1, T, 1024), pid)
        cos, sin = cos[0][:, None, :], sin[0][:, None, :]
        qr = rope(q, cos, sin).transpose(0, 1); kr = rope(k, cos, sin).transpose(0, 1)  # [H,T,128]
        kr = kr.repeat_interleave(2, 0)
        S = qr @ kr.transpose(1, 2) / np.sqrt(128.0)
        S = S + torch.triu(torch.full((T, T), float('-inf')), 1)
        return torch.softmax(S, -1)
