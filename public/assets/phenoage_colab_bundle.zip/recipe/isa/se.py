"""Local side-effect proxy (se_local): KL / top-1 flips on the proxy probes vs the original model's reference."""
import numpy as np, torch
from . import proxy_probes as PP
from .runner import kl_rows, flips
WS = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon'
_PROBES = None


def se_local(model, tok, fit_prompts, idx=None, verbose=True):
    global _PROBES
    if _PROBES is None: _PROBES = PP.build(tok, fit_prompts)
    ref = np.load(WS + '/data/proxy_ref_logp.npy', mmap_mode='r')
    idx = list(range(len(_PROBES))) if idx is None else list(idx)
    lp = []
    with torch.no_grad():
        for i in idx:
            ids = tok(_PROBES[i][1], return_tensors='pt').input_ids
            lp.append(torch.log_softmax(model(ids).logits[0, -1].float(), -1).numpy())
    lp = np.stack(lp); R = np.asarray(ref[idx])
    kl = kl_rows(R, lp); fr, fn = flips(R, lp)
    res = dict(maxkl=float(kl.max()), meankl=float(kl.mean()), argmax=int(idx[int(kl.argmax())]),
               real=[idx[k] for k in fr], near=[idx[k] for k in fn], kl=kl)
    if verbose:
        print('se_local: maxKL %.4f (probe %d) meanKL %.5f real flips %s near %s' % (res['maxkl'], res['argmax'], res['meankl'], res['real'], res['near']))
    return res
