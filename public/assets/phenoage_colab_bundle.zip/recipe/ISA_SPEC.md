# ISA_SPEC (as implemented in `isa/`, surgeon run)

Target: Qwen3-0.6B (28 layers, d=1024, 16 q-heads / 8 kv-groups, head dim 128, q_norm/k_norm, RoPE base 1e6,
SiLU-gated MLP 3072). Every module reads x̂ = γ ⊙ x / rms(x).

## 0. Machine model and conventions
| term | meaning |
|---|---|
| READ (covector) | a vector r on x̂ — it IS a weight row (gate/up/q/k/v row). Value r·x̂. |
| WRITE | a raw residual vector (down column, o image). A write w reads at a later layer as ≈ γ⊙w/‖x‖·√d. |
| CONST c | read with c·x̂ ≈ 1 on the token population of interest (`fitk.fit_const`). Biases are folded as b·c. |
| FB | the prompt flag: ≈1 at every token after the fixed question line of a PhenoAge prompt, exactly 0 elsewhere |
| pin | a dominant write (≥3-10‖x‖) along a code direction; makes the token's later state deterministic per code |
| rms regime | a write is perturbative (≤5%‖x‖), dominant (pin) or norm-tracking; never mid-band constant |

All installers take a `core.Registry`, touch weights only through it, record the original of every touched row/column,
and are idempotent: `set` overwrites a slice it owns (owner conflicts raise), `add` stores a per-owner delta on top of
the original (re-adding with the same owner replaces the delta). `Registry.restore()` is exact; `footprint()` counts
changed scalars per tensor and per owner; `resources()` lists replaced vs added-to neurons/heads.

## 1. Opcodes (`isa/prims.py`)
| opcode | signature | semantics (exact) | touched |
|---|---|---|---|
| STEP | `step(reg, L, (j1,j2), gate, const, up, down, A=10)` | out = down·[silu(g+A·c)−silu(g)]/A·(up·x̂), g = gate·x̂. For g ≫ 0: down·(c·x̂)(up·x̂); for g ≪ 0: 0. Width of the transition ≈ 1/‖gate‖ scale (κ). | 2 neurons (gate, up rows; down cols) |
| GATED_LINEAR | STEP with `up` = a linear read | out = down·(up·x̂) when the gate is on | 2 neurons |
| KINK | `kink(reg, L, j, gate, up, down)` | out = down·silu(g)·(up·x̂) ≈ down·relu(g)·(up·x̂); with gate = κ(r − t c), down = s/κ·e: s·relu(r − t)·e | 1 neuron |
| VTAKE | `vtake(reg, L, g, ch, vrow, {h: ocol})` | value channel ch of kv-group g := vrow; o columns of both q-heads := ocol | 1 v row, 2 o cols |
| VADD | `vadd(reg, L, g, ch, dv, {h: do})` | additive version (original kept) | same, additive |
| KEYSWITCH (DUAL) | `keyswitch(reg, L, g, Δ, r)` | k_raw(g) += Δ·(r·x̂) (rank-1). Off-prompt the edit is Δ·(r·x̂_nat): leak = ‖Δ‖·|r·x̂| | 128 k rows, additive |
| QSWITCH (DUAL) | `qswitch(reg, L, h, Δ, r)` | q_raw(h) += Δ·(r·x̂) | 128 q rows, additive |
| HEAD_TAKE / GROUP_KV | replace a q-head / kv-group | (implemented, unused in the final program) | 128 rows/cols |

## 2. Design routines (offline math, numpy)
| routine | file | what it returns |
|---|---|---|
| `pos_design` | `isa/attn.py` | LP over RoPE plane energies: raw q dirs (one per offset) + shared raw k dir; maximises worst logit margin |
| `pos_design_mass` | `isa/attn.py` | exponentiated-gradient ascent maximising the softmax MASS on the target offset (measured 0.9998) |
| `score_curve` | `isa/attn.py` | exact post-norm, post-RoPE score vs offset for constant raw q/k |
| `minvar_read` | `isa/fitk.py` | read r minimising r'Mr (M = natural second moment) s.t. r·on = 1, r·z = 0 (private reads; small background) |
| `fit_const` | `isa/fitk.py` | CONST read (ridge) |
| `quiet_dirs` | `isa/quiet.py` | write directions with minimal natural response across given layers (eigvecs of normalised moments) |
| NULLSPACE_DIRS | `scripts/k_dirs_v3.py` | families of private directions: small quadratic form for the W_q/W_k/W_v of the modules that must NOT see them, large for those that must |
| `Capture`, `QKCapture` | `isa/fitk.py`, `isa/attnprobe.py` | hooks for x̂/raw states at (side, L) and post-norm q/k (attention probabilities) |
| `se_local`, `Runner` | `isa/se.py`, `isa/runner.py` | proxy side-effect probes (105 prompts: KL and top-1 flips vs reference) |

## 3. Composite instructions (built from opcodes in `phenoage_program.py`; final = accepted edit E3)
| instruction | layer / slots | opcodes | contract (measured, held-out practice unless noted) |
|---|---|---|---|
| ANCHOR | L3 MLP, 3 pairs | STEP on fixed question-line tokens | eA only at ' ', '2', ')' of "(Levine 2018 phenotypic age)"; adversarial max 0.47 < thr 0.6-0.8 |
| FLAG | L4 attn g3 | KEYSWITCH (anchor keys := optimised k*) + VTAKE ch89 | every later token attends >= 0.78 (mean 0.998) to the anchors; server max KL 0.019 alone |
| FB (norm-tracking) | L4 MLP, 1 pair | STEP, up = linear read of |x| at the consumer layer | FB read on-min 4.7 vs probes max 1.0 (L5) |
| CONJUNCTION STEP / PIN | L6 MLP 13 pairs, L7 MLP 14 pairs | STEP, gate = kappa(svm + 1.5(FB - 1) - theta) | digit/space/dot pins: 0 wrong of 327k tokens; VF-item / ANS1 pins: 0 wrong; ANS2 pin (emitted tens digit) |
| SHIFT (DUAL) | L9 attn heads 0-4 | KEYSWITCH (all pins) + QSWITCH (VF pins), `pos_design_mass` | target-offset mass median 0.9999; one-hot decode at VF 0 errors |
| BITS + PADDED_CODE | L9 MLP, 15 pairs | STEP(soft_bit + M(vf - 1) > 0.5) + 1 pad pair | 0 errors on practice VF rows; offsets 4/5 refit on digit-augmented rows (D1): <= 1/798 held-out rare-digit errors (old: up to 26/798) |
| AFFINE | L10 MLP, 13 pairs | GATED_LINEAR (gate = item pin AND VF; up = value from bits) | per-item Y at L12: sd 0.04-0.28 yr |
| CRP channel + indicator | L10 MLP, 2 pairs | GATED_LINEAR (aV 100) / STEP (aI 300) | exact 0 off the CRP VF token |
| LOG_PWL v2 | L11 MLP, 12 KINKs | KINK, DESIGNED reads e_v/gamma, e_ind/gamma, guard kinkG(rind - c) | CRP Y err sd 0.22-0.26 yr; probe max gate -480 |
| SUM_POOL (DUAL) | L12 attn head 0 | KEYSWITCH (VF pins) + QSWITCH (answer/digit pins) on RoPE planes 52-63, q orthogonal to 10 key-deviation dirs | VF mass 1.0000 at ANS1/2/3, weight cv 0.008 (planes 44-63 gave 0.05 from rotation) |
| POOL_VTAKE | L12 attn g0 ch14 | VTAKE: v row = G * eY/gamma (gamma-compensated), o col (head 0) = ePD | pooled Y at the answers, sY = 0.1 raw/yr (G 4.4); off-prompt leak ~ (G x read noise x non-sink mass) |
| GATED_Z | L12 MLP, 4 pairs | GATED_LINEAR (z1 at ANS1 / z2 at ANS2) + STEP (indicators), gates on DESIGNED pin reads eANS/gamma, e_ans2/gamma (kapZ 300), z reads nulled at position 0 | z1 err 0.12 tens units, z2 1.4 yr (practice); exactly 0 elsewhere |
| PWL_ONEHOT EMIT | L13 MLP, 2 x (10 KINKs + 1 STEP) | KINK gate kap(rz - k ri) - K c0 (ANSWER-ZERO CONST guard, K/kap 5), STEP for u_0 | write = PL interpolation of lm_head logit vectors u_0..u_9 at z = rz/ri, dominant (Escale = 15 |x27|/|u|); argmax = round(z) |

Resources of the accepted edit: 1,957,862 changed scalars (0.26 % of the model); replaced neurons: L3 6, L4 2, L6 26,
L7 28, L9 30, L10 30, L11 12, L12 8, L13 24 (166 neurons); additive q/k edits on L4 g3, L9 q-heads 0-4 / groups 0-2, L12 q-head 0 /
group 0; value channels taken: L4 g3 ch89, L12 g0 ch14.

## 4. Allocation, placement and safety rules (as learned; all enforced in the final program)
- R1 Neurons: lowest natural usage per layer, then the server side-effect oracle decides; removals are super-additive and
  probe-specific (L5: 24 neurons 0.55 max KL; L9: 4 culprit slots {461,1787,740,856} flipped probe 145; L10: the whole
  30-slot set had to be re-chosen). Bisect by halves/quarters on the server and swap slots: STEP rows are fully
  overwritten, so a swap needs no re-derivation.
- R2 Heads: DUAL only (no removal); switch amplitude 3x (pool: 30x on planes 52-63); private reads from NULLSPACE_DIRS.
- R3 rms regime: writes are perturbative, dominant (pins, EMIT) or norm-tracking. A leak's damage is set by its
  MAGNITUDE, not its direction (P1: 37x lower read energy of the write direction did not reduce the pool leak), because
  any write changes the rms of the token and therefore every later x-hat.
- R4 Off-prompt reads: a read that gates a big write must be either a DESIGNED read of a dominant on-prompt code
  (pin/indicator: off-prompt background ~1-10% of the on value) or carry a guard term; ridge reads fitted on prompt
  rows reach O(1-10) on probes (CRP rv11 up to 8.6).
- R5 Directions chosen to be quiet on proxy-probe data overfit those probes (F1 eY: proxy sd /3, server KL x2.3 worse).
  Prefer weight-based or pin-based constructions; validate on the server oracle.
- R6 Position 0: every CONST read is ~-0.1 at the attention-sink state, so `gate - theta*c` is POSITIVE there; every
  STEP whose up-read is not 0 at position 0 writes into the sink of every sequence. Make up-reads exactly 0 at pos 0
  (min-variance correction against the on-target rows; forcing a CONST > 0 at pos 0 distorts it everywhere).
- R7 After an edit is ACCEPTED the live weights contain it: 'set' slices re-install identically, 'add' (DUAL) slices
  would be added twice. `install(..., base=ACCEPTED)` removes the accepted DUAL deltas first.
- R8 One configuration per install call; never raise SystemExit in the kernel (it stops the server).
