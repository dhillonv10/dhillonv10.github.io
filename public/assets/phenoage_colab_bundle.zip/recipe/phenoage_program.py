"""PhenoAge program: a composition of isa/ calls only. Vectors are derived by scripts/derive_s*.py and saved in vec/s*.npz.

Layer map (surgeon v1):
  L3 MLP   ANCHOR      3 STEPs at ' ', '2', ')' of "(Levine 2018 phenotypic age)" -> eA
  L4 attn  FLAG        kv-group 3 (sink-heavy heads 6,7): KEYSWITCH (anchor keys := optimised key k*) + additive v/o on channel 89 (VADD) -> eF
  L4 MLP   FB          norm-tracking STEP(F > thF) -> aFB*|x5|/med * eFB at every token after the anchor (exactly 0 on other prompts)
  L6 MLP   PINS        12 conjunction STEPs (digit k / ' ' / '.') AND FB -> dominant pin code (exact one-hot)
  L7 MLP   IDENT       14 conjunction STEPs (VF token of item k / ANS1) AND FB -> dominant pin with item code
  L9 attn  SHIFT       DUAL q/k switches on heads 0-4 (offsets 1,2 | 4,5 | 6); natural OV copies pin codes
  L9 MLP   BITS        16 STEPs: exact binary bits of the digits at offsets 2,4,5,6 (VF tokens only)
  L10 attn (ISOLATE dropped in v3: NULLSPACE_DIRS make natural L10/L11 heads blind to the bit/pad codes)
  L10 MLP  AFFINE      13 GATED_LINEAR pairs (item-gated sum of w*digit) -> Y along eY; CRP value channel
  L11 MLP  LOG_PWL     12 kinks: CRP 1.0577*ln(v) -> eY
  L12 attn POOL
  (pool)   POOL        DUAL q/k switches on head 0 (slowest RoPE planes): answer tokens average the 10 item VF tokens;
                       VTAKE of value channel 14 (reads G*eY/gamma) writes the pooled Y along the ANS-quiet ePD
  L12 MLP  GATED_Z     z1 (tens) at ANS1 / z2 (units) at ANS2 + indicators, separate channels (8 neurons)
  L13 MLP  EMIT        PWL one-hot digit read-out per answer position: 2 x (10 kinks + u_0 STEP) (24 neurons)
"""
import numpy as np
from isa import prims as PRM

NEUR = {'anchor': (3, [(2761, 78), (25, 162), (414, 38)]), 'fb': (4, (89, 237)),
        'pins': (6, [(866, 2838), (2367, 2609), (378, 2886), (927, 1257), (1760, 1727), (2278, 2048), (888, 203),
                     (913, 276), (1520, 1563), (847, 2724), (1096, 3031), (1177, 129)])}
# L5 MLP proved hypersensitive on the real probe set (10 neurons: max KL 0.11, 24: 0.55); L6 24 neurons: 0.033
PIN_TOKENS = list(range(10)) + ['sp', 'dot']
NEUR['pin_ans2'] = (6, (1813, 2619))
NEUR['ident'] = (7, [(5, 457), (167, 117), (238, 241), (1800, 1632), (2938, 2788), (172, 818), (1560, 2029), (782, 455),
                     (503, 1045), (538, 591), (716, 967), (1861, 2022), (1931, 513), (234, 1612)])
# ident k = 0..12: VF token of item k (isa.prompts.ITEM_NAMES order); k = 13: ANS1 ('\n\n' after </think>)   # pin k: digit k (0-9), ' ' (10), '.' (11)
ANCHORS = [(40, 0.7), (41, 0.8), (49, 0.6)]   # fixed question-line tokens ' ', '2' (of 2018) and ')' ; STEP thresholds
FLAG_HOST = dict(L=4, g=3, ch=89)


def install_anchor(reg, V):
    L, nns = NEUR['anchor']; kap = 300.0
    for (tokpos, th), nn in zip(ANCHORS, nns):
        gate = kap * (V[f'anc_r{tokpos}'] + (V[f'anc_b{tokpos}'] - th) * V['c3'])
        PRM.step(reg, L, nn, gate, V['c3'], V['c3'], V['Aamp'] * V['eA'], A=10.0, owner=f'anchor{tokpos}')


def install_flag_head(reg, V):
    h = FLAG_HOST
    PRM.keyswitch(reg, h['L'], h['g'], V['kdelta'], V['rt'], owner='flag_key')
    if V.get('vmode', 'take') == 'add':
        PRM.vadd(reg, h['L'], h['g'], h['ch'], V['cV'] * V['rt'], {2 * h['g']: V['M'] / V['cV'] * V['eF'], 2 * h['g'] + 1: V['M'] / V['cV'] * V['eF']}, owner='flag_vadd')
    else:
        PRM.vtake(reg, h['L'], h['g'], h['ch'], V['rt'], {2 * h['g']: V['M'] * V['eF'], 2 * h['g'] + 1: V['M'] * V['eF']}, owner='flag_vtake')


def install_fb(reg, V):
    L, nn = NEUR['fb']
    gate = V['kapF'] * (V['rF'] - V['thF'] * V['c4'])
    # NORM-TRACKING write: up = linear read of |x| at the consumer layer (u4.xhat ~ |x5|/median), so the FB read at
    # later layers is rms-stable (a constant raw write would read as aFB/|x|, which varies 3x across tokens)
    PRM.step(reg, L, nn, gate, V['c4'], V['u4'], V['aFB'] * V['eFB'], A=10.0, owner='fb')


def install_pins(reg, V):
    """DIGIT/SPACE/DOT PIN: conjunction STEP z = 0.7*svm_k + 0.3*FB > 0.5 (both reads at L6 pa) -> dominant code
    Ppin * (eP + e_k)/sqrt2 at every digit / ' ' / '.' token of PhenoAge prompts."""
    L, nns = NEUR['pins']
    for k, nn in enumerate(nns):
        z = 0.7 * (V['svm_w'][k] + V['svm_b'][k] * V['c5']) + 0.3 * V['rFB5'] / V['fb5_on']
        gate = V['kapP'] * (z - V['thP'] * V['c5'])
        down = V['Ppin'] * (V['eP'] + V['pin_e'][k]) / np.sqrt(2)
        PRM.step(reg, L, nn, gate, V['c5'], V['c5'], down, A=10.0, owner=f'pin{k}')
    if 'ans2_w' in V:   # ANS2 pin: the generated tens digit (digit right after the final '\n\n'), own code direction
        z = 0.7 * (V['ans2_w'] + V['ans2_b'] * V['c5']) + 0.3 * V['rFB5'] / V['fb5_on']
        PRM.step(reg, L, NEUR['pin_ans2'][1], V['kapP'] * (z - V['thP'] * V['c5']), V['c5'], V['c5'],
                 V['Ppin'] * (V['eP'] + V['e_ans2']) / np.sqrt(2), A=10.0, owner='pin_ans2')


def install_ident(reg, V):
    """IDENT/VF-PIN and ANS-PIN at L7 MLP: conjunction STEP z = svm_k + 1.5*(FB - 1) > 0 -> dominant pin
    Pvf*(eP + eV + u_k)/sqrt3 at the VF token of item k; Pvf*(eP + eANS)/sqrt2 at ANS1."""
    L, nns = NEUR['ident']
    for k, nn in enumerate(nns):
        # robust AND: z = svm_k + 1.5*(FB - 1) with FB normalised to 1 at VF/answer tokens (probes: FB <= 0.22)
        z = (V['id_w'][k] + V['id_b'][k] * V['c7']) + 1.5 * (V['rFB7n'] - V['c7'])
        gate = V['kapI'] * z
        if k < 13: down = V['Pvf'] * (V['eP'] + V['eV'] + V['u_items'][k]) / np.sqrt(3)
        else: down = V['Pvf'] * (V['eP'] + V['eANS']) / np.sqrt(2)
        PRM.step(reg, L, nn, gate, V['c7'], V['c7'], down, A=10.0, owner=f'ident{k}')


SHIFT = dict(L=9, groups={0: [1, 2], 1: [4, 5], 2: [6]}, q_all=[0])   # head 0 (offset 1) also runs at digit/answer pins


def install_shift(reg, V):
    """SHIFT (DUAL, no removal): k-switch on every pinned token (keys := designed positional key), q-switch on VF
    pins (queries := designed offset queries). Natural W_v/W_o carry the pin codes of t-k to the VF token."""
    L = SHIFT['L']
    for g, d in zip(V['dk_groups'], V['dk']):
        PRM.keyswitch(reg, L, int(g), d, V['rP'], owner=f'shift_k{int(g)}')
    for h, d in zip(V['dq_heads'], V['dq']):
        PRM.qswitch(reg, L, int(h), d, V['rP'] if int(h) in SHIFT['q_all'] else V['rV'], owner=f'shift_q{int(h)}')


POOL = dict(L=12, heads=[0])
ISO_LAYERS = [10, 11]
NEUR['kinks'] = (11, [70, 1085, 540, 2415, 1014, 2127, 928, 416, 638, 2535, 1547, 2770])
# L9 slots 461/1787/740/856 replaced (their removal flips a real server probe [145])
NEUR['bits'] = (9, [511, 213, 11, 1277, 49, 1768, 2198, 2409, 560, 1264, 794, 195, 792, 1387, 2141, 100, 1997, 748, 2131,
                     2549, 1067, 689, 2352, 2075, 1765, 2213, 2228, 1329, 2588, 2243, 1855, 246])
NEUR['arith'] = (10, [719, 2151, 455, 1751, 1686, 2761, 2168, 1630, 2865, 2244, 222, 2903, 2362, 1154, 2332, 891, 859, 945,
                      2887, 169, 1536, 2249, 1148, 2047, 1921, 2106, 917, 634, 1746, 1072])
# (L10 slots re-chosen 11-08 07:50: removal of the first lowest-usage set flipped real server probes 24 and 145)


def install_bits(reg, V):
    """BITS (L9 MLP, VF tokens only): exact binary bits of the digit at offsets 2,4,5,6 from the soft transported
    codes: STEP(soft_bit + M*(vf - 1) > 0.5) -> s*(e_kb - pad_kb), plus one PAD pair writing s*sum(pad_kb) at VF tokens:
    NORM-PRESERVING codes in VF-quiet directions (soft bits fitted to 0 on non-VF and probe tokens)."""
    L, nn = NEUR['bits']
    for i in range(len(V['bit_w'])):
        gate = V['kapB'] * (V['bit_w'][i] + V['bitM'] * V['vf9'] - (V['bitM'] + 0.5) * V['c9'])
        PRM.step(reg, L, (nn[2 * i], nn[2 * i + 1]), gate, V['c9'], V['c9'], V['bit_down'][i], A=10.0, owner=f'bit{i}')
    i = len(V['bit_w'])   # PAD pair: always on at VF tokens -> norm-preserving codes
    gate = V['kapB'] * (V['bitM'] * V['vf9'] - (V['bitM'] - 0.5) * V['c9'])
    PRM.step(reg, L, (nn[2 * i], nn[2 * i + 1]), gate, V['c9'], V['c9'], V['pad_down'], A=10.0, owner='bitpad')


def install_isolate(reg, V):
    """VF_ISOLATE (L10 attention, DUAL q-switch on all 16 heads, read = VF pin): at VF tokens every head attends to
    ITSELF (offset-0 positional design, keys switched at VF pins), so the L10 attention output there is a function
    of its own state instead of a mix of neighbouring items' codes."""
    for L in ISO_LAYERS:
        if f'iso_dk_{L}' not in V: continue
        for g in range(8):
            PRM.keyswitch(reg, L, g, V[f'iso_dk_{L}'][g], V[f'iso_r_{L}'], owner=f'isok{L}_{g}')
        for h in range(16):
            PRM.qswitch(reg, L, h, V[f'iso_dq_{L}'][h], V[f'iso_r_{L}'], owner=f'iso{L}_{h}')


def install_arith(reg, V):
    """AFFINE (L10 MLP): one GATED_LINEAR pair per item (gate = item code at a VF pin; up = sum_k w_ik * value_k - mu_i,
    values from exact bits (offsets 2,4,5,6) and a linear read (offset 1)) -> aY * Y_i along eY; CRP: + PWL kinks of
    1.0577*ln(v) (single SiLU neurons gated by the CRP item code)."""
    L, nn = NEUR['arith']
    ni = len(V['item_up'])
    for i in range(ni):
        gate = V['kapI2'] * (V['item_r'][i] + V['vf10'] - 1.5 * V['c10'])
        PRM.step(reg, L, (nn[2 * i], nn[2 * i + 1]), gate, V['c10'], V['item_up'][i], V['aY'] * V['eY'], A=10.0, owner=f'item{i}')
    # CRP value channel: v (mg/dL) written along e_v only at the CRP VF token (exactly 0 elsewhere) for the L11 kinks
    gate = V['kapI2'] * (V['item_r'][6] + V['vf10'] - 1.5 * V['c10'])
    PRM.step(reg, L, (nn[2 * ni], nn[2 * ni + 1]), gate, V['c10'], V['crp_v'], V['aV'] * V['e_v'], A=10.0, owner='crp_v')
    # exact CRP indicator (constant amplitude) used as the multiplicative up-read of the L11 kinks
    PRM.step(reg, L, (nn[2 * ni + 2], nn[2 * ni + 3]), gate, V['c10'], V['c10'], V['aI'] * V['e_ind'], A=10.0, owner='crp_ind')


def install_kinks(reg, V):
    """LOG_PWL (L11 MLP): 1.0577*ln(v) for CRP as sum_j s_j relu(v - t_j), knots 0.01*2^j; single SiLU neurons
    reading the bounded CRP value channel (0 at every other token, so no item gating is needed)."""
    L, nn = NEUR['kinks']
    for j in range(len(V['kink_t'])):
        gate = V['kapK'] * (V['rv11'] - V['kink_t'][j] * V['c11']) + V.get('kinkG', 0.0) * (V['rind11'] - V['c11'])   # guard: off unless CRP
        PRM.kink(reg, L, nn[j], gate, V['rind11'], V['kink_s'][j] * V['aY'] / V['kapK'] * V['eY'], owner=f'kink{j}')


def install_pool(reg, V):
    """SUM_POOL (DUAL, no removal): q-switch at ANS/digit pins, k-switch at VF pins (position-free slow planes):
    at the answer tokens head 0 averages the 10 item VF tokens; natural OV carries Y (eY has max OV gain)."""
    L = POOL['L']; h = POOL['heads'][0]
    PRM.keyswitch(reg, L, h // 2, V['pool_dk'], V['pool_rk'], owner='pool_k')
    PRM.qswitch(reg, L, h, V['pool_dq'], V['pool_rq'], owner='pool_q')
    if 'pool_vch' in V:     # VTAKE: one value channel of the pool group reads G*eY; head h writes ePD (other head 0)
        PRM.vtake(reg, L, h // 2, int(V['pool_vch']), V['pool_vrow'], {h: V['ePD']}, owner='pool_v')


NEUR['emit_z'] = (12, [1005, 2270, 2490, 2230, 1042, 498, 2915, 2714])          # lowest-usage L12 neurons
NEUR['emit'] = (13, [1219, 1283, 2608, 1604, 2700, 1609, 504, 1384, 1524, 2425, 2835, 2764, 741, 2692, 2982, 2972,
                     2980, 2841, 1563, 1354, 2549, 1144, 2744, 718, 1810, 2932])   # lowest-usage L13 neurons
# EMIT moved from L27 (pooled Y unreadable there: test sd ~20 yr). Two stages: GATED z at L12 MLP (right after POOL),
# PWL one-hot read-out at L13 MLP on clean, answer-only channels (separate channels for ANS1 and ANS2, because L13
# attention at ANS2 copies part of ANS1's channel).


def install_emit_z(reg, V):
    """GATED_Z (L12 MLP): at ANS1 write a_z*z1 along e_z1 and a_z along e_i1 (z1 = (y+0.5)/10 - 0.5, tens); at ANS2
    a_z*z2 along e_z2 and a_z along e_i2 (z2 = y - 10T, units). z reads are linear (pooled Y along ePD, CONST, tens
    digit pin); GATED_LINEAR pairs gated by the answer-type reads, so the channels are 0 at every other token. The same
    CONST factor (c.xhat) multiplies z and the indicator of a position, so the L13 ratio rz/ri is scale-free."""
    L, nn = NEUR['emit_z']; c = V['cZ']; k = V['kapZ']; a = V['a_z']
    for t, (isA, zr) in enumerate([(V['isA1'], V['z1r']), (V['isA2'], V['z2r'])]):
        g = k * (isA - 0.5 * c)
        PRM.step(reg, L, (nn[4 * t], nn[4 * t + 1]), g, c, zr, a * V['e_z'][t], A=10.0, owner=f'emitz_z{t + 1}')
        PRM.step(reg, L, (nn[4 * t + 2], nn[4 * t + 3]), g, c, c, a * V['e_i'][t], A=10.0, owner=f'emitz_i{t + 1}')


def install_emit(reg, V):
    """EMIT (L13 MLP, PWL_ONEHOT), per answer position t: rz = s*z, ri = s there (0 elsewhere). The write is the
    piecewise-linear interpolation of the logit vectors u_0..u_9 at z (clamped to [0, 9]):
        f(z) = u_0 + sum_k c_k relu(z - k),  c_0 = u_1 - u_0, c_k = u_{k+1} - 2u_k + u_{k-1}, c_9 = u_8 - u_9,
    as 10 KINKs (gate kapE*(rz - k*ri) - K*c0, up ri: = s^2 relu(z - k); c0 = 0 at the answers, 1 elsewhere) + a STEP for u_0 (const = up = ri: = s^2 u_0).
    Only the two digits around z carry weight -> argmax digit = round(z). Dominant (Escale ~ several |x27|)."""
    L, nn = NEUR['emit']; k = V['kapE']; E = V['Escale']
    u = V['em_u']
    cs = [u[1] - u[0]] + [u[j + 1] - 2 * u[j] + u[j - 1] for j in range(1, 9)] + [u[8] - u[9]]
    for t in range(2):
        rz, ri = V['rz13'][t], V['ri13'][t]
        guard = V['emK'] * V['c0']   # ANSWER-ZERO CONST: c0.xhat ~ 0 at ANS1/ANS2, ~1 at every other token (scale-free guard)
        for j in range(10):
            PRM.kink(reg, L, nn[12 * t + j], k * (rz - j * ri) - guard, ri, E * cs[j] / k, owner=f'emit{t + 1}_kink{j}')
        PRM.step(reg, L, (nn[12 * t + 10], nn[12 * t + 11]), V['kapS'] * (ri - 0.5 * V['c13']) - guard, ri, ri, E * u[0], A=10.0, owner=f'emit{t + 1}_u0')
    if V.get('Aeos', 0) > 0:
        PRM.step(reg, L, (nn[24], nn[25]), V['kapS'] * (V['isA3'] - 0.5 * V['c13']), V['c13'], V['c13'], E * V['Aeos'] * u[10], A=10.0, owner='emit_eos')


STAGES = [('anchor', install_anchor), ('flag_head', install_flag_head), ('fb', install_fb), ('pins', install_pins),
          ('ident', install_ident), ('shift', install_shift), ('bits', install_bits), ('isolate', install_isolate), ('arith', install_arith), ('kinks', install_kinks),
          ('pool', install_pool), ('emit_z', install_emit_z), ('emit', install_emit)]


def load(ws):
    V = {}
    import os
    for s in ['s1', 's2', 's3', 's4', 's5', 's5iso', 's5arith', 's5kinks', 's6', 's7z', 's7']:
        p = f'{ws}/vec/{s}.npz'
        if os.path.exists(p):
            d = np.load(p); V.update({k: d[k] for k in d.files})
    return V


ACCEPTED = '/tmp/claude-0/-home-user/920fe012-e383-5e78-b2e1-3d227e5fa950/scratchpad/isa_phenoage/ws_surgeon/accepted_E3'
# ^ vectors of the edit the server has ACCEPTED (E3, 11-08 12:55; E2 10:38 had the same DUAL deltas): the live weights are that edit, so installs remove
#   its DUAL deltas first (base=ACCEPTED is the default; derive code against the original model passes base=None)


def remove_dual(P, V):
    """Subtract the additive (DUAL) q/k deltas of configuration V from the live weights P. Needed after an edit has
    been ACCEPTED: the live weights then already contain that edit, 'set' slices are simply overwritten again, but
    'add' slices (KEYSWITCH/QSWITCH) would be added twice. Every other slice is untouched."""
    from isa import core as CO
    tmp = CO.Registry(P)
    h = FLAG_HOST
    PRM.keyswitch(tmp, h['L'], h['g'], -V['kdelta'], V['rt'], owner='u_flag')
    L = SHIFT['L']
    for g, dk in zip(V['dk_groups'], V['dk']):
        PRM.keyswitch(tmp, L, int(g), -dk, V['rP'], owner=f'u_shift_k{g}')
    for hh, dq in zip(V['dq_heads'], V['dq']):
        PRM.qswitch(tmp, L, int(hh), -dq, V['rP'] if int(hh) in SHIFT.get('q_all', []) else V['rV'], owner=f'u_shift_q{hh}')
    L = POOL['L']; hp = POOL['heads'][0]
    PRM.keyswitch(tmp, L, hp // 2, -V['pool_dk'], V['pool_rk'], owner='u_pool_k')
    PRM.qswitch(tmp, L, hp, -V['pool_dq'], V['pool_rq'], owner='u_pool_q')


def install(reg, V, upto=None, base=ACCEPTED):
    """base: directory whose vec/ holds the ACCEPTED configuration (if the live weights contain it): its DUAL deltas
    are removed first, so the install is relative to the original model again."""
    if base is not None:
        remove_dual(reg.P, load(base))
    for name, fn in STAGES:
        fn(reg, V)
        if name == upto: break
