# PRIMITIVES (surgeon, this run) — weight-space opcodes as implemented in `isa/`

Notation: x = residual, x̂ = γ⊙x/rms(x) (what every module reads). A READ is a covector on x̂ (= a weight row). A WRITE is a
raw residual vector. "On-prompt" = PhenoAge prompts after the flag; "off-prompt" = every other prompt (probes).

## Reused from round 6 (adapted)
| opcode | round-6 origin | what changed |
|---|---|---|
| STEP (saturating SiLU pair) | CLEAN/COMPARE pairs | generic installer `isa.prims.step` (gate, CONST, up, down, A); used for every boolean |
| GATED_LINEAR | ROOT pairs / rounds 4-5 GAM | same pair with up = a linear read; used per item for the affine contribution |
| positional head design (LP over RoPE plane energies) | `lib6.pos_design` | `isa.attn.pos_design` (generalised) + NEW `pos_design_mass` (maximises softmax mass on the target offset; 0.9998-0.99995 measured) |
| QUIET directions | `lib6.quiet_dirs` | `isa.quiet.quiet_dirs` on natural moments in normalised-raw coordinates, hard-orthogonal to pos-0 states and earlier codes |
| CONST read | `lib6.const_read` | `isa.fitk.fit_const` (ridge of 1) |
| kv-group placement by isolated removal scan, culprit bisection (6c) | `rm5.py`, `rm1.py` | `scripts/k_scan_heads.py`, `scripts/k_rm_test.py`; **the server `side_effects` call is now the oracle** (proxy probes miss the hypersensitive real probe) |
| value-follow / identity detectors (LinearSVC) | s6g2 | replaced by CONJUNCTION SVMs (below) |

## New in this run
| opcode | file | semantics | measured |
|---|---|---|---|
| ANCHOR | `phenoage_program.install_anchor` | STEP at L3 on a FIXED question-line state (tokens ' ', '2', ')' of "(Levine 2018 phenotypic age)"), LDA detector vs all proxy-probe tokens + 12 adversarial texts | adversarial max 0.47 (thr 0.6-0.8); removal KL 4e-4 |
| KEYSWITCH | `isa.prims.keyswitch` | DUAL key: k_raw += Δ·(r·x̂), r = min-variance read of a private write; off-prompt only the read's background leaks | no measurable KL |
| QSWITCH | `isa.prims.qswitch` | DUAL query, same idea | 6 heads with Δq = 3‖q‖: max KL 5e-4 (proxy) |
| VTAKE / VADD | `isa.prims.vtake`, `vadd` | take over (or add to) one value channel of a kv-group | L4 g3 ch89: KL 1.3e-3 |
| FLAG (anchor + sink-host keyswitch + vtake + STEP) | `install_anchor/flag_head/fb` | anchor keys set to an optimised key k* (soft-min ascent) on a sink-heavy group: attention to anchors min 0.78/head, mean 0.998 | server max KL 0.019 |
| NORM-TRACKING write | `install_fb` (up = linear read of ‖x‖ at the consumer layer) | a raw write w reads as w/‖x‖ (3x spread across tokens); writing w ∝ ‖x‖ makes the read rms-stable | FB read L5: on-min 4.7 vs off-max 1.0 (was 1.08 vs 1.69) |
| CONJUNCTION STEP | `install_pins`, `install_ident` | gate z = 0.7·SVM(token-kind AND on-prompt) + 0.3·FB > 0.5; SVM negatives = other on-prompt tokens + all proxy-probe tokens (a 2-feature AND of detector and FB is not linearly separable) | 0 wrong of 327k held-out tokens (pins), 0 wrong (identity) |
| PIN (dominant write) | same | STEP output ≥ 6-10x ‖x‖ along a code direction: the pinned token's state becomes deterministic per code, so every later read there is exact and rms-stable | — |
| SHIFT-DUAL | `install_shift` | positional heads with NO removal: k-switch on all pins, q-switch on VF pins, natural W_v/W_o copy the pin code of t−k | target mass median 0.9999; one-hot decode at VF: 0 test errors, margin 0.9/0.07 |
| BITS | `install_bits` | exact binary bits of the copied digits (4 per offset) by STEP(soft_bit + M·(vf−1) > 0.5) | see MEASURE_LOG |
| SUM_POOL-DUAL | `install_pool` | q-switch at answer/digit pins, k-switch at VF pins on RoPE planes 52-63 (rotation-free), q orthogonal to key deviations | VF mass 1.0000, weight cv 0.008 |
| POOL_VTAKE | `install_pool` (vtake) | value channel 14 of the pool group reads G*eY/gamma; pool head writes ePD at the answers | replaces the natural-OV path (1e-6 relative signal) |
| LOG_PWL v2 | `install_kinks` | KINKs on DESIGNED reads of exact L10 channels + indicator guard | CRP Y sd 0.22 yr, probe gate max -480 |
| GATED_Z | `install_emit_z` | GATED_LINEAR z (tens/units) + STEP indicator per answer position, pin-read gates, z reads nulled at pos 0 | z1 0.12 tens, z2 1.4 yr |
| PWL_ONEHOT EMIT | `install_emit` | 10 KINKs + 1 STEP per position: piecewise-linear interpolation of lm_head logit vectors; ANSWER-ZERO CONST guard | argmax = round(z); dev MAE 1.38 end to end |
| ANSWER-ZERO CONST | `derive_s7e.py` | ridge read ~0 at ANS1/ANS2, ~1 elsewhere: a scale-free guard (-K c0) for gates whose scale varies | off-answer kink gates <= -150 |
| ANS-QUIET / read-gram dirs | `o_pool_ch2.py`, `o_pool_ch3.py` | write dirs quiet over answer states / with small read energy in later layers | z1 0.14 -> 0.07; read energy /37 (no SE effect: R3) |
| DIGIT AUGMENTATION | `collect_aug.py`, `o_s5a_svm_aug.py` | decoders refit on prompts with digit-by-digit redrawn numbers | rare-digit errors 26/798 -> 0/798 (offset 4 bit 3) |
| server-oracle footprint bisection | MEASURE_LOG S1-S10 | halves of a slot set until the culprit layer/pair is found | L5 hypersensitive; L6 fine |

## Lessons recorded as rules
- rms regime: a write is either ≤5% of ‖x‖ (perturbative), dominant (≥3‖x‖, pin), or norm-tracking; mid-band constant writes break every later threshold.
- Additive MLP edits leak off-prompt (natural activation × added down column; natural features in the gate move the host's gate). Only q/k switches and private-read value rows are leak-free.
- Neuron removal damage is layer-specific and super-additive on one real probe (L5: 10 neurons 0.11, 24 neurons 0.55 max KL; L6: 24 → 0.033).
- Views of large per-prompt arrays retained in lists leak kernel memory (OOM at 13.9 GB once); always copy rows.
- Never `raise SystemExit` (or call exit) inside a kernel script: the server catches Exception only, so it stops the
  server process (two restarts on 11-07 23:50/23:56). Use a conditional block instead.
- Pooled signals must be amplified at the source: through the natural OV of the pool head the pooled Y arrived at ANS1
  with 0.0012 raw per year on a 628-norm state (1.9e-6 relative; z read test sd ~19 yr). Fix = POOL_VTAKE (one value
  channel of the pool group reads G*eY, the pool head writes a private ePD; sY = 0.3 raw per year).
- (11-08) A leak's damage is set by its magnitude (rms change of the token), not its direction.
- (11-08) Position 0: CONSTs are ~-0.1 at the sink, so threshold gates are OPEN there; null every up-read at pos 0.
- (11-08) After acceptance, re-installs must remove the accepted DUAL deltas first (install(..., base=ACCEPTED)).
- (11-08) Probe-fitted quiet directions/reads overfit the proxy probes; the server oracle is the only judge.
