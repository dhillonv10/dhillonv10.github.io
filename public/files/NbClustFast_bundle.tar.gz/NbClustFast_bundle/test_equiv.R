# Randomised identity test: NbClustFast::NbClust vs NbClust::NbClust (CRAN 3.0.1).
# Usage: Rscript test_equiv.R <cases> <seed> <max n>
a <- commandArgs(TRUE); N <- as.integer(a[1]); seed <- as.integer(a[2]); maxn <- as.integer(a[3])
S <- asNamespace("NbClust"); F <- asNamespace("NbClustFast")
run <- function(f, args) { pdf(NULL); on.exit(dev.off()); set.seed(99); w <- character(0)
  txt <- capture.output(r <- withCallingHandlers(tryCatch(do.call(f, args), error = function(e) structure(list(msg = conditionMessage(e)), class = "err")), warning = function(wn) { w <<- c(w, conditionMessage(wn)); invokeRestart("muffleWarning") }))
  list(r = r, txt = txt, w = w, rng = runif(1)) }
idx <- c("kl","ch","hartigan","ccc","scott","marriot","trcovw","tracew","friedman","rubin","cindex","db","silhouette","duda","pseudot2","beale","ratkowsky","ball","ptbiserial","gap","frey","mcclain","gamma","gplus","tau","dunn","hubert","sdindex","dindex","sdbw")
hot <- c("silhouette", "ptbiserial", "frey", "mcclain", "gamma", "gplus", "tau", "hubert")
meths <- c("ward.D2", "single", "complete", "average", "mcquitty", "median", "centroid", "kmeans", "ward.D")
set.seed(seed); st <- c(identical = 0, both_error = 0, mismatch = 0); byidx <- list(); bad <- list()
for (it in seq_len(N)) {
  n <- sample(12:maxn, 1); p <- sample(2:6, 1); k <- sample(2:5, 1); g <- sample(k, n, TRUE)
  x <- matrix(rnorm(n * p), n, p) + matrix(rnorm(k * p, sd = runif(1, 0.5, 4)), k, p)[g, ]
  if (runif(1) < 0.25) x <- round(x, sample(0:1, 1))            # ties and duplicate points
  if (runif(1) < 0.1) x[sample(n, 2), ] <- x[1, ]
  if (runif(1) < 0.05) x[sample(n, 1), 1] <- NA
  index <- if (runif(1) < 0.35) "all" else if (runif(1) < 0.3) "alllong" else if (runif(1) < 0.7) sample(hot, 1) else sample(idx, 1)
  mn <- sample(2:3, 1); mx <- mn + sample(2:7, 1); if (mx >= n - 2) mx <- max(mn + 2, n - 3)
  args <- list(data = x, distance = sample(c("euclidean", "maximum", "manhattan", "canberra", "minkowski", "binary"), 1, prob = c(5, 1, 2, 1, 1, 0.3)), min.nc = mn, max.nc = mx, method = sample(meths, 1), index = index)
  if (runif(1) < 0.12) { args$diss <- dist(x, method = "manhattan"); args["distance"] <- list(NULL); if (runif(1) < 0.4 && index %in% c("frey", "mcclain", "cindex", "silhouette", "dunn")) args["data"] <- list(NULL) }
  keep_seed <- .Random.seed; A <- run(S$NbClust, args); B <- run(F$NbClust, args); assign(".Random.seed", keep_seed, envir = globalenv())
  key <- index; if (is.null(byidx[[key]])) byidx[[key]] <- c(0, 0, 0)
  if (inherits(A$r, "err") && inherits(B$r, "err") && identical(A$r$msg, B$r$msg)) { st[2] <- st[2] + 1; byidx[[key]][2] <- byidx[[key]][2] + 1 }
  else if (identical(A, B)) { st[1] <- st[1] + 1; byidx[[key]][1] <- byidx[[key]][1] + 1 }
  else { st[3] <- st[3] + 1; byidx[[key]][3] <- byidx[[key]][3] + 1; if (length(bad) < 4) bad[[length(bad) + 1]] <- list(args = args, A = A, B = B) }
}
print(st); m <- do.call(rbind, byidx); colnames(m) <- names(st); print(m[order(rownames(m)), ])
write.csv(data.frame(index = rownames(m), m), sprintf("results/equiv_seed%d.csv", seed), row.names = FALSE)
if (length(bad)) { saveRDS(bad, sprintf("bad_%d.rds", seed)); for (b in bad) { cat("\nMISMATCH: n", nrow(b$args$data), "index", b$args$index, "method", b$args$method, "distance", b$args$distance, "nc", b$args$min.nc, b$args$max.nc, "\n")
  if (inherits(b$A$r, "err") || inherits(b$B$r, "err")) cat("  orig:", if (inherits(b$A$r, "err")) b$A$r$msg else "ok", "| fast:", if (inherits(b$B$r, "err")) b$B$r$msg else "ok", "\n") else { print(all.equal(b$A$r, b$B$r, tolerance = 0)); cat("  text same:", identical(b$A$txt, b$B$txt), " warnings same:", identical(b$A$w, b$B$w), " rng same:", identical(b$A$rng, b$B$rng), "\n") } } }
