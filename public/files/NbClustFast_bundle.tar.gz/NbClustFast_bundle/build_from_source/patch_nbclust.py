"""Build NbClustFast/R/NbClust.R from the original NbClust source: rename the slow internal
functions to *.orig, insert exact fast replacements before the main loop, reset caches per pass."""
import re, sys
src = open('src/NbClust/R/NbClust.R').read()
renames = [('Index.Hubert<-function(x, cl)', 'Index.Hubert.orig<-function(x, cl)'),
           ('Index.sPlussMoins <- function (cl1,md)', 'Index.sPlussMoins.orig <- function (cl1,md)'),
           ('Index.15and28  <- function (cl1,cl2,md)', 'Index.15and28.orig  <- function (cl1,cl2,md)'),
           ('Indice.ptbiserial <- function (x,md,cl1)', 'Indice.ptbiserial.orig <- function (x,md,cl1)'),
           ('Indice.S <- function (d, cl) ', 'Indice.S.orig <- function (d, cl) '),
           ('centers<-function(cl,x)', 'centers.orig<-function(cl,x)'),
           ('Average.scattering <- function (cl, x)', 'Average.scattering.orig <- function (cl, x)'),
           ('density.clusters<-function(cl, x)', 'density.clusters.orig<-function(cl, x)'),
           ('density.bw<-function(cl, x)', 'density.bw.orig<-function(cl, x)'),
           ('Indices.WBT <- function(x,cl,P,s,vv) ', 'Indices.WBT.orig <- function(x,cl,P,s,vv) '),
           ('Indices.WKWL <- function (x,cl1=cl1,cl2=cl2)', 'Indices.WKWL.orig <- function (x,cl1=cl1,cl2=cl2)')]
for a, b in renames:
    assert src.count(a) == 1, a
    src = src.replace(a, b)
# inside Indices.Traces: remember gss() per partition (it is called about ten times per pass)
a_ = '  gss <- function(x, cl, d) \n'
assert src.count(a_) == 1
src = src.replace(a_, '  gss.orig <- function(x, cl, d) \n')
b_ = '    indice.kl <- function (x, clall, d = NULL, centrotypes = "centroids"){'
assert src.count(b_) == 1
src = src.replace(b_, '    gss <- function(x, cl, d) .memo_do("gss", cl, x, gss.orig(x, cl, d))\n' + b_)
src = src.replace('Indices.Traces <- function(data, d, clall, index = "all") \n', 'Indices.Traces.orig <- function(data, d, clall, index = "all") \n')
# inside Indice.Gap: the reference data set is the same on every call (the simulator resets
# the seed), so its hierarchical clustering is formed once and reused
import re as _re
pat = _re.compile(r'pp2 <- cutree\(hclust\(dist\(Xnew\), method = method\), \s*ClassNr\)')
assert len(pat.findall(src)) == 2
src = pat.sub('pp2 <- cutree(.gap_hc(Xnew, method), ClassNr)', src)
# corrected = TRUE: new argument, and the original gap function becomes the non-corrected path
sig = 'method =NULL, index = "all", alphaBeale = 0.1)\n{'
assert src.count(sig) == 1
src = src.replace(sig, 'method =NULL, index = "all", alphaBeale = 0.1, corrected = FALSE)\n{\n' + open('corrected_entry.R').read())
g_ = 'Indice.Gap <- function (x, clall, reference.distribution = "unif", B = 10, \n'
assert src.count(g_) == 1
src = src.replace(g_, 'Indice.Gap.orig <- function (x, clall, reference.distribution = "unif", B = 10, \n')
exec(open('patch_extra.py').read())
fast = open('fast_helpers.R').read()
loop = ' for (nc in min_nc:max_nc)\n {  \n'
assert src.count(loop) == 1
src = src.replace(loop, fast + '\n' + loop + '      .memo_reset()\n')
open('NbClustFast/R/NbClust.R', 'w').write(src)
print('patched', len(src.splitlines()), 'lines')
