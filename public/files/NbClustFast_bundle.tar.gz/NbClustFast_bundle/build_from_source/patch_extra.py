# corrected = TRUE: when no k meets the gap criterion the original leaves best.nc undefined
m_ = re.search(r"      \}else\{\n[ \t]*nc\.Gap <- NA\n[ \t]*indice\.Gap <- NA\n", src)
assert m_ is not None
src = src[:m_.end()] + "        if (isTRUE(corrected)) { if (indice == 20) best.nc <- NA; warning('Gap: no number of clusters between min.nc and max.nc meets Gap(k) >= Gap(k+1) - s(k+1)') }\n" + src[m_.end():]
c1 = "        partition<- cutree(hc, k=best.nc)\n"
assert src.count(c1) == 1
src = src.replace(c1, "        partition<- if (isTRUE(corrected) && is.na(best.nc)) rep(NA_integer_, nn) else cutree(hc, k=best.nc)\n")
c2 = "        partition<-kmeans(jeu,best.nc)$cluster\n"
assert src.count(c2) == 1
src = src.replace(c2, "        partition<- if (isTRUE(corrected) && is.na(best.nc)) rep(NA_integer_, nn) else kmeans(jeu,best.nc)$cluster\n")
