    ## corrected = TRUE leaves the caller's random-number stream as it found it
    if (isTRUE(corrected)) {
        .seed_was <- if (exists(".Random.seed", envir = globalenv(), inherits = FALSE)) get(".Random.seed", envir = globalenv()) else NULL
        on.exit({
            if (is.null(.seed_was)) { if (exists(".Random.seed", envir = globalenv(), inherits = FALSE)) rm(".Random.seed", envir = globalenv()) }
            else assign(".Random.seed", .seed_was, envir = globalenv())
        }, add = TRUE)
    }
