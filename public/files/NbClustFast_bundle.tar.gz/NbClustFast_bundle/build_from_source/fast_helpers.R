##############################################################################################
#  NbClustFast: exact fast replacements for the slowest internal functions.                   #
#  The originals are kept above as *.orig and are used whenever an input is unusual.          #
##############################################################################################

.fast_on <- isTRUE(getOption("NbClustFast.enable", TRUE)) && inherits(md, "dist") && !anyNA(md)
.dmat <- if (.fast_on) as.matrix(md) else NULL          # as.matrix(md), formed once
.nobs <- if (.fast_on) nrow(.dmat) else 0L
.ld <- isTRUE(capabilities("long.double"))
.memo <- new.env(parent = emptyenv())                   # results that depend only on md
.pass <- new.env(parent = emptyenv())                   # results for the current value of nc
.memo_reset <- function() rm(list = ls(.pass, all.names = TRUE), envir = .pass)

## A remembered value keeps the warnings its computation raised and raises them again each
## time it is handed back, so warnings appear as often as in the original.
.capture <- function(expr) {
    w <- list()
    val <- withCallingHandlers(expr, warning = function(cnd) { w[[length(w) + 1L]] <<- cnd; invokeRestart("muffleWarning") })
    list(val = val, w = w)
}
.replay <- function(e) { for (cnd in e$w) warning(cnd); e$val }

## as.matrix(md) / data.matrix(md) are called again inside several index functions; when the
## argument is the very same 'md' object, hand back the copy formed above
as.matrix <- function(x, ...) if (.fast_on && nargs() == 1L && identical(x, md)) .dmat else base::as.matrix(x, ...)
data.matrix <- function(frame, ...) if (.fast_on && nargs() == 1L && identical(frame, md)) .dmat else base::data.matrix(frame, ...)

## a partition the fast code accepts: whole numbers 1..K, every cluster non-empty
.cl_ok <- function(cl) .fast_on && is.numeric(cl) && is.null(dim(cl)) && length(cl) == .nobs && .nobs >= 3 &&
    !anyNA(cl) && all(cl == round(cl)) && min(cl) >= 1 && max(cl) <= .nobs && all(tabulate(cl, max(cl)) > 0)

## within / between distance vectors of a partition, in the original's order; the last few
## partitions are remembered because cl2 of one pass is cl1 of the next
.wb <- function(cl) {
    for (e in .memo$wb) if (identical(e$cl, cl)) return(e)
    v <- .Call(C_wb, .dmat, as.integer(cl), as.integer(max(cl)))
    e <- list(cl = cl, within = v[[1]], between = v[[2]], meanwithin = mean(v[[1]]), meanbetween = mean(v[[2]]))
    .memo$wb <- c(list(e), .memo$wb)[seq_len(min(3L, length(.memo$wb) + 1L))]
    e
}

Index.Hubert <- function(x, cl)
{
      if (!.cl_ok(cl) || !is.matrix(x) || dim(x)[1] != .nobs) return(Index.Hubert.orig(x, cl))
      k <- max(cl)
      n<-dim(x)[1]
      P<- .dmat
      if (is.null(.memo$hubertP)) {                     # depends on md only
          meanP<-mean(P)
          variance.matrix <- numeric(0)
          for(j in 1:n)
            variance.matrix[j]=var(P[,j])*(n-1)/n
          varP<-sqrt(variance.matrix %*% variance.matrix)
          .memo$hubertP <- list(meanP = meanP, varP = varP)
      }
      meanP <- .memo$hubertP$meanP; varP <- .memo$hubertP$varP
      variance.matrix <- numeric(0)

      centers.clusters<-centers(cl,x)

      ## y has only k distinct rows, so dist(y)[i, j] is the distance between the centres of
      ## cl[i] and cl[j] (same routine, same row values), and column j of Q depends only on cl[j]
      Dk <- base::as.matrix(dist(centers.clusters[seq_len(k), , drop = FALSE], method="euclidean"))
      Q<- Dk[cl, cl]
      meanQ<-mean(Q)
      vk <- numeric(k)
      for (u in 1:k) vk[u] <- var(Q[, match(u, cl)])*(n-1)/n
      variance.matrix <- vk[cl]
      varQ<-sqrt(variance.matrix %*% variance.matrix)

      M<-n*(n-1)/2
      S <- .Call(C_hubert_sum, P, Dk, as.integer(cl), as.double(meanP), as.double(meanQ))
      gamma<-S/(M*varP*varQ)

      return(gamma)
}

Index.sPlussMoins <- function (cl1,md)
{
    if (!.cl_ok(cl1)) return(Index.sPlussMoins.orig(cl1, md))
    if (!is.null(.pass$spm)) return(.replay(.pass$spm))
    .pass$spm <- .capture({
    e <- .wb(cl1)
    n1 <- length(cl1)
    nwithin1 <- length(e$within)
    nbetween1 <- length(e$between)
    if (nwithin1 < 1 || nbetween1 < 1 || as.double(nwithin1) * nbetween1 > 2^52) Index.sPlussMoins.orig(cl1, md) else {
    cnt <- .Call(C_count_pm, e$within, e$between)
    s.plus <- cnt[1]
    s.moins <- cnt[2]

    Index.Gamma <- (s.plus-s.moins)/(s.plus+s.moins)
    Index.Gplus <- (2*s.moins)/(n1*(n1-1))
    t.tau  <- (nwithin1*nbetween1)-(s.plus+s.moins)
    Index.Tau <- (s.plus-s.moins)/(((n1*(n1-1)/2-t.tau)*(n1*(n1-1)/2))^(1/2))

    list(gamma=Index.Gamma, gplus=Index.Gplus, tau=Index.Tau) } })
    return(.replay(.pass$spm))
}

Index.15and28  <- function (cl1,cl2,md)
{
    if (!.cl_ok(cl1) || !.cl_ok(cl2)) return(Index.15and28.orig(cl1, cl2, md))
    if (!is.null(.pass$i1528)) return(.replay(.pass$i1528))
    .pass$i1528 <- .capture({
    e1 <- .wb(cl1); e2 <- .wb(cl2)
    nwithin1 <- length(e1$within)
    nbetween1 <- length(e1$between)
    meanwithin1 <- e1$meanwithin
    meanbetween1 <- e1$meanbetween
    meanwithin2 <- e2$meanwithin
    meanbetween2 <- e2$meanbetween
    Index.15 <- (meanbetween2-meanbetween1)/(meanwithin2-meanwithin1)
    Index.28 <- (meanwithin1/nwithin1)/(meanbetween1/nbetween1)

    list(frey=Index.15,mcclain=Index.28) })
    return(.replay(.pass$i1528))
}

Indice.ptbiserial <- function (x,md,cl1)
{
    if (!.cl_ok(cl1)) return(Indice.ptbiserial.orig(x, md, cl1))
    if (is.null(.memo$pbx)) {                           # pb[,2]: distances in the original pair
        .memo$pbx <- .Call(C_pb_x, .dmat)               # order; they and their sd depend on md only
        .memo$pbsd <- sd(.memo$pbx)
    }
    ind <- .Call(C_pb_ind, as.integer(cl1))             # pb[,1] == 1: pair is in different clusters
    if (!any(ind) || all(ind)) return(Indice.ptbiserial.orig(x = x, md = md, cl1 = cl1))
    diff.mu <- mean(.memo$pbx[ind]) - mean(.memo$pbx[!ind])
    prob <- mean(ind)
    ptbiserial <- diff.mu * sqrt(prob * (1 - prob))/.memo$pbsd
    return(ptbiserial)
}

Indice.S <- function (d, cl)
{
    if (!.cl_ok(cl)) return(Indice.S.orig(d, cl))
    .Call(C_sil, .dmat, as.integer(cl), as.integer(max(cl)), .ld)
}

## these two are called up to seven times per pass with the same arguments
Indices.WBT <- function(x,cl,P,s,vv)
{
    if (is.null(.pass$wbt)) .pass$wbt <- .capture(Indices.WBT.orig(x = x, cl = cl, P = P, s = s, vv = vv))
    .replay(.pass$wbt)
}

Indices.WKWL <- function (x,cl1=cl1,cl2=cl2)
{
    if (is.null(.pass$wkwl)) .pass$wkwl <- .capture(Indices.WKWL.orig(x = x, cl1 = cl1, cl2 = cl2))
    .replay(.pass$wkwl)
}

## ---- scattering and density functions: the scalar loops in C, repeated calls remembered ----
.x_ok <- function(cl, x) isTRUE(getOption("NbClustFast.enable", TRUE)) && is.matrix(x) && is.double(x) && !anyNA(x) &&
    is.numeric(cl) && is.null(dim(cl)) && length(cl) == nrow(x) && !anyNA(cl) && all(cl == round(cl)) && min(cl) >= 1 &&
    all(tabulate(cl, max(cl)) > 0)
## .memo_do(slot, cl, x, expr): value of expr, remembered per (cl, x) for the current pass
.memo_do <- function(slot, cl, x, expr) {
    for (e in .pass[[slot]]) if (identical(e$cl, cl) && identical(e$x, x)) return(.replay(e$res))
    res <- .capture(expr)
    .pass[[slot]] <- c(list(list(cl = cl, x = x, res = res)), .pass[[slot]])[seq_len(min(4L, length(.pass[[slot]]) + 1L))]
    .replay(res)
}

centers <- function(cl,x)
{
    x <- as.matrix(x)
    .memo_do("centers", cl, x, centers.orig(cl, x))
}

Average.scattering <- function (cl, x)
{
    x <- as.matrix(x)
    if (!.x_ok(cl, x)) return(Average.scattering.orig(cl, x))
    .memo_do("scat", cl, x, {
    n <- length(cl)
    k <- max(cl)
    centers.matrix <- centers(cl,x)
    cluster.size <- numeric(0)
    for (u in 1:k)
      cluster.size[u] <- sum(cl == u)
    variance.clusters <- .Call(C_var_clusters, x, as.integer(cl), centers.matrix)
    for (u in 1:k)
    {
       for (j in 1:ncol(x))
          variance.clusters[u,j]= variance.clusters[u,j]/ cluster.size[u]
    }
     variance.matrix <- numeric(0)
     for(j in 1:ncol(x))
        variance.matrix[j]=var(x[,j])*(n-1)/n
      Somme.variance.clusters<-0
      for (u in 1:k)
         Somme.variance.clusters<-Somme.variance.clusters+sqrt((variance.clusters[u,]%*%(variance.clusters[u,])))
      stdev<-(1/k)*sqrt(Somme.variance.clusters)
      scat<- (1/k)* (Somme.variance.clusters /sqrt(variance.matrix %*% variance.matrix))
      scat <- list(stdev=stdev, centers=centers.matrix, variance.intraclusters= variance.clusters, scatt=scat)
      scat })
}

density.clusters<-function(cl, x)
{
   x <- as.matrix(x)
   if (!.x_ok(cl, x)) return(density.clusters.orig(cl, x))
   .memo_do("dens", cl, x, {
   centers.matrix<-centers(cl,x)
   stdev<-Average.scattering(cl,x)$stdev
   if (!is.finite(stdev)) density.clusters.orig(cl, x) else {
   v <- .Call(C_density_clusters, x, as.integer(cl), centers.matrix, as.double(stdev))
   list(distance=v[[1]], density=v[[2]]) } })
}

density.bw<-function(cl, x)
{
   x <- as.matrix(x)
   if (!.x_ok(cl, x)) return(density.bw.orig(cl, x))
   k <- max(cl)
   n <- length(cl)
   centers.matrix<-centers(cl,x)
   stdev<-Average.scattering(cl,x)$stdev
   if (!is.finite(stdev)) return(density.bw.orig(cl, x))
   density.bw <- .Call(C_density_bw, x, as.integer(cl), centers.matrix, as.double(stdev))
     density.clust<-density.clusters(cl,x)$density
     S<-0
     for(u in 1:k)
       for(v in 1:k)
       {
         if(max(density.clust[u], density.clust[v])!=0)
            S=S+ (density.bw[u,v]/max(density.clust[u], density.clust[v]))
       }
     density.bw<-S/(k*(k-1))
     return(density.bw)
 }

## Indices.Traces only uses 'd' to copy it and set its row names; when 'd' is the session's own
## 'md' (same number of rows as the data) that copy has no effect on the result and is skipped
Indices.Traces <- function(data, d, clall, index = "all")
{
    if (.fast_on && identical(d, md) && is.matrix(data) && nrow(data) == .nobs) d <- NULL
    Indices.Traces.orig(data, d, clall, index)
}

## hclust(dist(Xnew)) for the gap statistic's reference data, remembered while Xnew is unchanged
.gap_hc <- function(Xnew, method)
{
    if (!isTRUE(getOption("NbClustFast.enable", TRUE))) return(hclust(dist(Xnew), method = method))
    e <- .memo$gap
    if (!is.null(e) && identical(e$method, method) && identical(e$X, Xnew)) return(e$hc)
    hc <- hclust(dist(Xnew), method = method)
    .memo$gap <- list(X = Xnew, method = method, hc = hc)
    hc
}

##############################################################################################
#  corrected = TRUE: gap statistic as published (Tibshirani, Walther and Hastie 2001).         #
#  Differences from the original code:                                                         #
#   1. the B reference data sets are B different draws, and their columns are independent      #
#      uniforms over each variable's range (the original resets the seed inside the simulator, #
#      so every column of every replicate is the same sequence rescaled);                      #
#   2. every replicate uses the same pooled within-cluster dispersion, with weight n_z - 1,    #
#      and a single-member cluster contributes 0;                                              #
#   3. the reference sets are drawn once per NbClust() call and reused for every number of     #
#      clusters; the caller's random-number stream is restored on exit.                        #
##############################################################################################
.gap_ref <- function(X, B, method)
{
    e <- .memo$gapref
    if (!is.null(e) && identical(e$X, X) && identical(e$B, B) && identical(e$method, method)) return(e)
    set.seed(1)
    lo <- apply(X, 2, min); hi <- apply(X, 2, max)
    ref <- lapply(seq_len(B), function(b) {
        Y <- X
        for (j in seq_len(ncol(X))) Y[, j] <- runif(nrow(X), min = lo[j], max = hi[j])
        Y })
    hc <- if (method != "k-means") lapply(ref, function(Y) hclust(dist(Y), method = method)) else NULL
    e <- list(X = X, B = B, method = method, ref = ref, hc = hc, parts = new.env(parent = emptyenv()))
    .memo$gapref <- e
    e
}
.gap_part <- function(e, b, k)
{
    key <- paste(b, k)
    if (is.null(e$parts[[key]]))
        e$parts[[key]] <- if (k == nrow(e$X)) seq_len(k) else if (e$method == "k-means") { set.seed(1); kmeans(e$ref[[b]], k, 100)$cluster } else cutree(e$hc[[b]], k)
    e$parts[[key]]
}
.gap_W <- function(Y, pp, k)
{
    s <- 0
    for (zz in seq_len(k)) {
        m <- sum(pp == zz)
        if (m >= 2) s <- s + sum(diag(var(Y[pp == zz, , drop = FALSE]))) * (m - 1)/(nrow(Y) - k)
    }
    s
}

Indice.Gap <- function (x, clall, reference.distribution = "unif", B = 10,
    method = "ward.D2", d = NULL, centrotypes = "centroids")
{
    if (!isTRUE(corrected))
        return(Indice.Gap.orig(x = x, clall = clall, reference.distribution = reference.distribution, B = B,
                               method = method, d = d, centrotypes = centrotypes))
    X <- base::as.matrix(x)
    e <- .gap_ref(X, B, method)
    one <- function(cl) {
        k <- max(cl)
        Wk0 <- .gap_W(X, cl, k)
        WkB <- vapply(seq_len(B), function(b) .gap_W(e$ref[[b]], .gap_part(e, b, k), k), numeric(1))
        list(Sgap = mean(log(WkB)) - log(Wk0),
             Sdgap = sqrt(1 + 1/B) * sqrt(var(log(WkB))) * sqrt((B - 1)/B))
    }
    gap1 <- one(clall[, 1]); gap2 <- one(clall[, 2])
    list(gap = gap1$Sgap, diffu = gap1$Sgap - (gap2$Sgap - gap2$Sdgap))
}
