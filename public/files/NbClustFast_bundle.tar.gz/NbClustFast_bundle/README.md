# NbClustFast

A drop-in replacement for `NbClust::NbClust()` (CRAN NbClust 3.0.1; Charrad, Ghazzali, Boiteau
and Niknafs, J Stat Softw 2014) that returns identical results and is much faster, plus an
opt-in `corrected = TRUE` mode that fixes the gap statistic and stops NbClust from changing
the caller's random seed.

    bash run_all.sh        # install both, identity check, corrected-mode tests, timing table
    bash run_all.sh 500    # also time the original with index = "alllong" up to n = 500 (about 25 min)

Needs R (>= 3.1) with a C compiler. Use `library(NbClustFast)` in place of `library(NbClust)`.
Add `corrected = TRUE` for the corrected gap statistic. Set `options(NbClustFast.enable = FALSE)`
to run the original code paths.

## What changes

`NbClust()` is the original source with a small set of internal functions replaced:

- Gamma, Gplus, Tau (`index = "alllong"` or by name): The original compares every within-cluster
  distance with every between-cluster distance. The new code sorts once and counts by binary
  search. The counts are whole numbers, so the result is the same.
- Hubert, point-biserial, Frey, McClain, silhouette, SD, SDbw, D index: Scalar R loops over all
  pairs of observations moved to C, with the same terms in the same order.
- Gap: The original clusters the same simulated reference data about 90 times per run; the
  clustering is formed once.
- Results that the original recomputes with identical arguments (up to seven times per number of
  clusters) are computed once. Their warnings are raised again each time, as in the original.

Compiled code only gathers numbers or does plain double arithmetic in the original order.
R's own `mean()`, `var()` and `sum()` still do the statistics, so identity does not depend on
re-implementing R's arithmetic (which differs between R versions for `var()`). Unusual input
(missing distances, empty clusters) goes to the original functions, kept in the source as `*.orig`.

## Measured (4-core cloud machine, single-threaded, Ward linkage, 2 to 10 clusters)

Every row: `identical()` TRUE on the full returned list. Original timings were taken with at
most two jobs on the machine.

| Data | Indices | Original | New | Speedup |
|---|---|---|---|---|
| WDBC: 569 breast tumours x 30 features | all 30 (`alllong`) | 2,329 s | 0.66 s | 3,500x |
| WDBC: 569 breast tumours x 30 features | default 26 (`all`) | 7.6 s | 0.27 s | 28x |
| TCGA-LAML: 173 patients x 10 PCs | all 30 | 17.0 s | 0.17 s | 98x |
| TCGA-LAML: 173 patients x 10 PCs | default 26 | 1.16 s | 0.11 s | 11x |
| NHANES: 8,000 adults x 3 variables | default 26 | 1,420 s | 32 s | 44x |
| NHANES: 8,000 adults x 3 variables | all 30 | not run | 97 s | |
| simulated, n = 500 | all 30 | 992 s | 0.34 s | 2,900x |
| simulated, n = 400 | all 30 | 386 s | 0.29 s | 1,350x |
| simulated, n = 300 | all 30 | 127 s | 0.20 s | 620x |
| simulated, n = 200 | all 30 | 25.9 s | 0.17 s | 157x |
| simulated, n = 100 | all 30 | 2.3 s | 0.12 s | 19x |
| simulated, n = 4,000 | default 26 | 225 s | 7.0 s | 32x |
| simulated, n = 2,000 | default 26 | 55.7 s | 1.8 s | 31x |
| simulated, n = 1,000 | default 26 | 13.7 s | 0.47 s | 29x |
| simulated, n = 500 | default 26 | 3.2 s | 0.19 s | 16x |

With all 30 indices the new code takes 1.0 s at n = 1,000 and 4.0 s at n = 2,000; the original
was not run at those sizes.

Identity tests: 3,000 random inputs across all 9 clustering methods, 6 distances, every index,
ties, duplicate points and user-supplied dissimilarities: 2,893 identical (result list, printed
text, warnings and RNG state), 107 where both versions stop with the same error, 0 mismatches.
Tested on R 4.5.3 only.

## Earlier work

Two modified copies of NbClust exist: `NbClust_mod` in the TOMproject repository, which removes
some repeated calls ("slightly faster"), and a fork discussed on Stack Overflow that swaps in
Rfast and fastcluster. Neither is a compiled rewrite or changes the Gamma/Gplus/Tau algorithm,
and neither claims identical output. The rank-based way to count concordant pairs is standard.

## Defects of the original fixed by `corrected = TRUE`

The default mode reproduces all of these so that results stay identical to the original.

1. Gap: The simulator resets the seed on every call, so every reference variable is the same
   uniform sequence rescaled (pairwise correlation exactly 1). The reference data lie on a line.
   Fixed: Independent uniform draws per variable.
2. Gap: For the same reason all 10 reference sets are identical. Fixed: 10 different draws,
   made once per call and reused for every number of clusters.
3. Gap: The first replicate weights clusters by size minus one, the others by size, and a
   one-member cluster is given the variance across its variables. Fixed: One pooled
   within-cluster dispersion for every replicate; a one-member cluster contributes zero.
4. `NbClust()` calls `set.seed(1)` internally. Fixed: The caller's random-number state is
   restored on exit.
5. If no number of clusters meets the gap rule, the answer variable is never assigned.
   Fixed: The gap's choice is reported as NA with a warning.

Effect: On four simulated clusters the original gap picks 2; the corrected gap and
`cluster::clusGap` (200 reference sets) pick 4. The corrected gap agrees with an independent
implementation of the published formula to the 4 decimals NbClust reports. The other 29
indices are unchanged by `corrected = TRUE`.

Licence: GPL-2, as the original, whose source this package contains.
`build_from_source/` holds the script that derives `NbClustFast/R/NbClust.R` from the CRAN source.
`figures_src/` holds the figure scripts and result tables.
