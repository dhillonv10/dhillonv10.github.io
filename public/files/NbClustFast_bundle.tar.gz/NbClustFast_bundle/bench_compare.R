# Original vs fast on the same simulated inputs (4 Gaussian clusters, 10 variables, Ward linkage, k = 2..10).
nmax <- as.integer(c(commandArgs(TRUE), 300)[1]); S <- asNamespace("NbClust"); F <- asNamespace("NbClustFast"); pdf(NULL)
sim <- function(n, p = 10) { set.seed(1); g <- sample(4, n, TRUE); matrix(rnorm(n * p), n, p) + matrix(rnorm(4 * p, sd = 2), 4, p)[g, ] }
go <- function(ns, x, index) { t <- system.time(invisible(capture.output(r <- suppressWarnings(ns$NbClust(x, method = "ward.D2", index = index, min.nc = 2, max.nc = 10)))))[3]; list(t = t, r = r) }
cat(sprintf("%-10s %6s %12s %10s %9s %s\n", "index", "n", "original", "fast", "speedup", "identical"))
for (cfg in list(c("all", 500), c("all", 1000), c("all", 2000), c("alllong", 100), c("alllong", 200), c("alllong", 300), c("alllong", 400), c("alllong", 500), c("alllong", 1000), c("alllong", 2000))) {
  n <- as.integer(cfg[2]); x <- sim(n); f <- go(F, x, cfg[1])
  if (cfg[1] == "all" || n <= nmax) { s <- go(S, x, cfg[1]); cat(sprintf("%-10s %6d %10.2f s %8.3f s %8.0fx %s\n", cfg[1], n, s$t, f$t, s$t / f$t, identical(s$r, f$r))) }
  else cat(sprintf("%-10s %6d %12s %8.3f s\n", cfg[1], n, "(skipped)", f$t)) }
