#!/usr/bin/env bash
# Install CRAN NbClust + NbClustFast, check identical results, and time both.
# Usage: bash run_all.sh [largest n at which to time the original with index="alllong", default 300]
# Needs R (>= 3.1) with a C compiler.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p lib results
Rscript -e 'if (!requireNamespace("NbClust", quietly = TRUE)) install.packages("NbClust", repos = "https://cloud.r-project.org")'
R CMD INSTALL --no-docs --library=lib NbClustFast > install.log 2>&1 || { cat install.log; exit 1; }
export R_LIBS=$PWD/lib${R_LIBS:+:$R_LIBS}
echo "== 1. identical results, printed output, warnings and RNG state on 400 randomised inputs"
Rscript test_equiv.R 400 1 100 > equiv.log 2>&1; head -2 equiv.log
echo "== 2. corrected mode (gap statistic, random-number state)"
Rscript test_corrected.R 2>&1 | grep -E "corrected|original|unchanged"
echo "== 3. timing, original vs fast"
Rscript bench_compare.R "${1:-300}"
