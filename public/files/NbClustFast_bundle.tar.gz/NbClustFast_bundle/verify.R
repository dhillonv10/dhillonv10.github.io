# identical() between saved original and new results for every benchmark
f <- list.files("results", "^(bench|real)_stock_.*rds$"); ok <- TRUE
for (s in f) { g <- sub("_stock_", "_fast_", s); if (!file.exists(file.path("results", g))) next
  same <- identical(readRDS(file.path("results", s)), readRDS(file.path("results", g))); ok <- ok && same; cat(sprintf("%-46s %s\n", sub("\\.rds$", "", sub("^(bench|real)_stock_", "", s)), same)) }
cat("ALL IDENTICAL:", ok, "\n")
