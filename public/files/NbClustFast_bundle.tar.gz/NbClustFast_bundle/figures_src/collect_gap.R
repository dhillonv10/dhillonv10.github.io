# Gap diagnostics: original vs corrected vs cluster::clusGap (B = 200, squared distances, same linkage)
suppressPackageStartupMessages({library(cluster); library(data.table)}); pdf(NULL)
quiet <- function(expr) { v <- NULL; invisible(capture.output(v <- suppressWarnings(expr))); v }
set.seed(3); g <- rep(1:4, each = 75); sim <- cbind(rnorm(300), rnorm(300)) + cbind(c(0, 6, 0, 6), c(0, 0, 6, 6))[g, ]
d <- read.csv("data/wdbc.data", header = FALSE); wd <- scale(as.matrix(d[, 3:32])); attr(wd, "scaled:center") <- NULL; attr(wd, "scaled:scale") <- NULL
ex <- fread(cmd = "zcat ../sroc/data/LAML_HiSeqV2.gz"); m <- as.matrix(ex[, -1]); v <- apply(m, 1, var); m <- m[order(-v)[1:1000], ]; la <- scale(prcomp(t(m), center = TRUE)$x[, 1:10]); attr(la, "scaled:center") <- NULL; attr(la, "scaled:scale") <- NULL
out <- NULL; best <- NULL; tim <- NULL
for (nm in c("sim", "wdbc", "laml")) { X <- list(sim = sim, wdbc = wd, laml = la)[[nm]]
  t0 <- system.time(o <- quiet(NbClust::NbClust(X, method = "ward.D2", index = "gap", min.nc = 2, max.nc = 10)))[3]
  t1 <- system.time(f <- quiet(NbClustFast::NbClust(X, method = "ward.D2", index = "gap", min.nc = 2, max.nc = 10)))[3]
  t2 <- system.time(cc <- quiet(NbClustFast::NbClust(X, method = "ward.D2", index = "gap", min.nc = 2, max.nc = 10, corrected = TRUE)))[3]
  set.seed(7); cg <- clusGap(X, FUNcluster = function(x, k) list(cluster = cutree(hclust(dist(x), "ward.D2"), k)), K.max = 11, B = 200, d.power = 2, spaceH0 = "original", verbose = FALSE)
  tab <- as.data.frame(cg$Tab); kb <- maxSE(tab$gap, tab$SE.sim, method = "Tibs2001SEmax")
  out <- rbind(out, data.frame(data = nm, k = 2:10, original = unname(o$All.index), corrected = unname(cc$All.index), clusGap = tab$gap[2:10], clusGap_se = tab$SE.sim[2:10]))
  best <- rbind(best, data.frame(data = nm, original = unname(o$Best.nc[1]), corrected = unname(cc$Best.nc[1]), clusGap = kb, identical_default = identical(o, f)))
  tim <- rbind(tim, data.frame(data = nm, original = t0, fast = t1, corrected = t2)); cat(nm, "done\n") }
write.csv(out, "results/gap_curves.csv", row.names = FALSE); write.csv(best, "results/gap_best.csv", row.names = FALSE); write.csv(tim, "results/gap_times.csv", row.names = FALSE); print(best); print(tim)
# reference data: original simulator vs corrected draws, on the 2-D simulated data
simgap <- function(Xvec) { ma <- max(Xvec); mi <- min(Xvec); set.seed(1); runif(length(Xvec), min = mi, max = ma) }
r1 <- apply(sim, 2, simgap); r2 <- apply(sim, 2, simgap); set.seed(1); lo <- apply(sim, 2, min); hi <- apply(sim, 2, max); c1 <- cbind(runif(300, lo[1], hi[1]), runif(300, lo[2], hi[2])); c2 <- cbind(runif(300, lo[1], hi[1]), runif(300, lo[2], hi[2]))
write.csv(data.frame(x = sim[, 1], y = sim[, 2], ox = r1[, 1], oy = r1[, 2], ox2 = r2[, 1], oy2 = r2[, 2], cx = c1[, 1], cy = c1[, 2], cx2 = c2[, 1], cy2 = c2[, 2]), "results/gap_reference.csv", row.names = FALSE)
cat("orig reference replicates identical:", identical(r1, r2), " column correlation:", cor(r1)[1, 2], " corrected:", round(cor(c1)[1, 2], 3), "\n")
