source("figs_common.R"); d <- read.csv("results/scaling.csv")
open_png("nbclust_Fig1_scaling.png", 10, 4.6)
par(mfrow = c(1, 2), mar = c(3.8, 4.6, 4.2, 1.2), oma = c(0, 0, 1.8, 0))
for (m in c("alllong", "all")) { s <- d[d$mode == m, ]; xl <- if (m == "alllong") c(85, 2400) else c(420, 4800); yl <- if (m == "alllong") c(0.05, 4e5) else c(0.05, 1500)
  plot(NA, log = "xy", xlim = xl, ylim = yl, xlab = "Observations (n)", ylab = "", axes = FALSE, xaxs = "i", yaxs = "i"); time_axis(2, yl)
  axis(1, at = s$n, labels = ifelse(s$n >= 1000, paste0(s$n / 1000, "k"), s$n), col = NA, col.ticks = COL["grey"], gap.axis = 0.1)
  ok <- !is.na(s$stock); fit <- lm(log(stock) ~ log(n), s[ok & s$n >= 200, ])
  if (m == "alllong") { nn <- c(500, 2000); lines(nn, exp(predict(fit, data.frame(n = nn))), col = COL["orig"], lty = 3, lwd = 1.2) }
  lines(s$n[ok], s$stock[ok], col = COL["orig"], lwd = 1.6); points(s$n[ok], s$stock[ok], pch = 16, col = COL["orig"], cex = 1.1)
  lines(s$n, s$fast, col = COL["fast"], lwd = 1.6); points(s$n, s$fast, pch = 16, col = COL["fast"], cex = 1.1)
  nb <- max(s$n[ok]); sb <- s$stock[s$n == nb]; fb <- s$fast[s$n == nb]
  segments(nb, fb * 1.5, nb, sb / 1.5, col = COL["grey"], lwd = 0.8); text(nb * 0.9, exp((log(sb) + log(fb)) / 2), paste0(fmt_x(sb / fb), "\nfaster"), adj = c(1, 0.5), cex = 0.85, font = 2, col = COL["ink"])
  text(nb, sb * 2.2, sprintf("Original: %s", fmt_time(sb)), col = COL["orig"], cex = 0.8, font = 2, adj = c(if (m == "alllong") 1 else 1, 0)); text(max(s$n), s$fast[which.max(s$n)] * 2.6, sprintf("New code: %s at %s", fmt_time(s$fast[which.max(s$n)]), formatC(max(s$n), big.mark = ",")), col = COL["fast"], cex = 0.8, font = 2, adj = c(1, 0.5))
  ttl(if (m == "alllong") "All 30 indices (index = \"alllong\")" else "Default 26 indices (index = \"all\")", sprintf("Original: Time grows as n^%.1f%s", coef(fit)[2], if (m == "alllong") ". Dotted line: Projection, not measured" else ". Both versions are quadratic here")) }
mtext("Run time on simulated data: The 30-index mode grows with the fourth power of n", outer = TRUE, adj = 0.01, font = 2, cex = 0.95, col = COL["ink"], line = 0.4)
dev.off()
