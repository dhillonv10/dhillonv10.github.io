# Usage: Rscript bench.R <stock|fast> <n> <index> [method] [profile]
a <- commandArgs(TRUE); ns <- asNamespace(if (a[1] == "stock") "NbClust" else "NbClustFast"); n <- as.integer(a[2]); p <- 10; set.seed(1)
g <- sample(4, n, TRUE); x <- matrix(rnorm(n * p), n, p) + matrix(rnorm(4 * p, sd = 2), 4, p)[g, ]
meth <- if (length(a) > 3) a[4] else "ward.D2"; pdf(NULL)
if (length(a) > 4) { pf <- tempfile(); Rprof(pf, interval = 0.01) }
el <- system.time(invisible(capture.output(r <- suppressWarnings(ns$NbClust(x, method = meth, index = a[3], min.nc = 2, max.nc = 10)))))[3]
if (length(a) > 4) { Rprof(NULL); s <- summaryRprof(pf); bt <- s$by.total; keep <- grepl("^\"?(Index|Indice|Indices|Average|density|Dis|centers|hclust|dist|kmeans|cutree|eigen|as.matrix.dist|var|mean|\\.wb|\\.Call|sd)", rownames(bt)); b <- bt[keep, ]; b <- b[order(-b$total.time), ]
  cat(paste(sprintf("  %s %.0f%%", gsub('"', "", rownames(b)), 100 * b$total.time / s$sampling.time)[1:min(16, nrow(b))], collapse = ""), "\n") }
saveRDS(r, sprintf("results/bench_%s_%d_%s_%s.rds", a[1], n, a[3], meth)); cat(sprintf("%s n=%d index=%s method=%s: %.3f s\n", a[1], n, a[3], meth, el))
