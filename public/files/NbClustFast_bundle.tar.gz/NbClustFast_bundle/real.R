# Real-data runs. Usage: Rscript real.R <stock|fast> <wdbc|laml|nhanes> <index> [n for nhanes]
a <- commandArgs(TRUE); ns <- asNamespace(if (a[1] == "stock") "NbClust" else "NbClustFast"); pdf(NULL)
if (a[2] == "wdbc") { d <- read.csv("data/wdbc.data", header = FALSE); x <- scale(as.matrix(d[, 3:32])); lab <- "WDBC: 569 breast tumours x 30 features" }
if (a[2] == "laml") { suppressPackageStartupMessages(library(data.table)); ex <- fread(cmd = "zcat ../sroc/data/LAML_HiSeqV2.gz"); m <- as.matrix(ex[, -1]); v <- apply(m, 1, var); m <- m[order(-v)[1:1000], ]
  pc <- prcomp(t(m), center = TRUE)$x[, 1:10]; x <- scale(pc); lab <- sprintf("TCGA-LAML: %d patients x 10 principal components of the 1,000 most variable genes", nrow(x)) }
if (a[2] == "nhanes") { d <- readRDS("../sroc/data/nhanes_cc.rds"); set.seed(1); n <- as.integer(a[4]); d <- d[sample(nrow(d), n), ]; x <- scale(as.matrix(d[, c("RIDAGEYR", "BMXBMI", "BPXSY1")])); lab <- sprintf("NHANES: %d adults x age, BMI, systolic pressure", n) }
attr(x, "scaled:center") <- NULL; attr(x, "scaled:scale") <- NULL
set.seed(1); el <- system.time(invisible(capture.output(r <- suppressWarnings(ns$NbClust(x, method = "ward.D2", index = a[3], min.nc = 2, max.nc = 10)))))[3]
tag <- paste(a[-1], collapse = "_"); saveRDS(r, sprintf("results/real_%s_%s.rds", a[1], tag)); cat(sprintf("%s | %s | index=%s | %.3f s\n", a[1], lab, a[3], el))
writeLines(sprintf("%s,%s,%s,%.4f", a[1], tag, lab, el), sprintf("results/real_%s_%s.txt", a[1], tag))
