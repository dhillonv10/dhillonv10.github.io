/* NbClustFast: compiled kernels for the slow index functions of NbClust.
 * Each kernel either returns integer counts (exact by nature) or hands R the same values in
 * the same order as the original R code, so that R's own mean(), var() and sum() see
 * identical input.  Compiled with -ffp-contract=off so that a*b+c is never fused.
 */
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include <R_ext/Utils.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdint.h>

/* member lists per cluster, ascending observation index */
static void members(const int *cl, int n, int K, int **start_out, int **idx_out)
{
    int *start = (int *) R_alloc((size_t) K + 2, sizeof(int)), *idx = (int *) R_alloc((size_t) n + 1, sizeof(int));
    int *fill = (int *) R_alloc((size_t) K + 2, sizeof(int));
    for (int u = 0; u <= K; u++) start[u] = 0;
    for (int i = 0; i < n; i++) start[cl[i]]++;
    int s = 0; for (int u = 1; u <= K; u++) { int c = start[u]; start[u] = s; fill[u] = s; s += c; }
    start[K + 1] = s;
    for (int i = 0; i < n; i++) idx[fill[cl[i]]++] = i;
    *start_out = start; *idx_out = idx;       /* cluster u (1-based) is idx[start[u] .. start[u+1]-1] */
}

/* Within- and between-cluster distances in the order built by Index.15and28 / Index.sPlussMoins:
 * within : for each cluster u, as.dist(dmat[u, u])           (lower triangle, column by column)
 * between: for each u < v, dmat[members(u), members(v)]      (column by column)                 */
SEXP C_wb(SEXP s_d, SEXP s_cl, SEXP s_K)
{
    const double *d = REAL(s_d); const int *cl = INTEGER(s_cl); int n = LENGTH(s_cl), K = asInteger(s_K);
    int *st, *ix; members(cl, n, K, &st, &ix);
    R_xlen_t nw = 0, nb = 0;
    for (int u = 1; u <= K; u++) { R_xlen_t a = st[u + 1] - st[u]; nw += a * (a - 1) / 2; nb += a * (R_xlen_t) (n - st[u + 1]); }
    SEXP out = PROTECT(allocVector(VECSXP, 2));
    SEXP W = PROTECT(allocVector(REALSXP, nw)), B = PROTECT(allocVector(REALSXP, nb));
    double *w = REAL(W), *b = REAL(B); R_xlen_t tw = 0, tb = 0;
    for (int u = 1; u <= K; u++) {
        for (int c = st[u]; c < st[u + 1]; c++) { const double *col = d + (size_t) n * ix[c]; for (int r = c + 1; r < st[u + 1]; r++) w[tw++] = col[ix[r]]; }
        for (int v = u + 1; v <= K; v++)
            for (int c = st[v]; c < st[v + 1]; c++) { const double *col = d + (size_t) n * ix[c]; for (int r = st[u]; r < st[u + 1]; r++) b[tb++] = col[ix[r]]; }
        R_CheckUserInterrupt();
    }
    SET_VECTOR_ELT(out, 0, W); SET_VECTOR_ELT(out, 1, B);
    UNPROTECT(3);
    return out;
}

/* s.plus = #{(w, b): b > w}, s.moins = #{(w, b): b < w} over all within x between pairs */
SEXP C_count_pm(SEXP s_w, SEXP s_b)
{
    R_xlen_t nw = XLENGTH(s_w), nb = XLENGTH(s_b);
    const double *w = REAL(s_w);
    double *b = (double *) R_alloc((size_t) nb + 1, sizeof(double));
    memcpy(b, REAL(s_b), (size_t) nb * sizeof(double));
    R_qsort(b, 1, nb);
    uint64_t plus = 0, moins = 0;
    for (R_xlen_t k = 0; k < nw; k++) {
        double x = w[k]; R_xlen_t lo = 0, hi = nb;
        while (lo < hi) { R_xlen_t mid = lo + (hi - lo) / 2; if (b[mid] < x) lo = mid + 1; else hi = mid; }
        R_xlen_t less = lo; hi = nb;
        while (lo < hi) { R_xlen_t mid = lo + (hi - lo) / 2; if (b[mid] <= x) lo = mid + 1; else hi = mid; }
        moins += (uint64_t) less; plus += (uint64_t) (nb - lo);
        if ((k & 0xFFFFF) == 0) R_CheckUserInterrupt();
    }
    SEXP out = PROTECT(allocVector(REALSXP, 2));
    REAL(out)[0] = (double) plus; REAL(out)[1] = (double) moins;
    UNPROTECT(1);
    return out;
}

/* Point-biserial inputs in the order of the original double loop (m1 = 2..n, m2 = 1..m1-1).
 * x = dmat[m1, m2]; dmat comes from as.matrix(dist) and is symmetric, so column m1 is read. */
SEXP C_pb_x(SEXP s_d)
{
    const double *d = REAL(s_d); int n = INTEGER(getAttrib(s_d, R_DimSymbol))[0];
    R_xlen_t N = (R_xlen_t) n * (n - 1) / 2;
    SEXP X = PROTECT(allocVector(REALSXP, N)); double *x = REAL(X);
    for (int m1 = 1; m1 < n; m1++) memcpy(x + (R_xlen_t) m1 * (m1 - 1) / 2, d + (size_t) n * m1, (size_t) m1 * sizeof(double));
    UNPROTECT(1);
    return X;
}
/* TRUE when the two observations of the pair are in different clusters */
SEXP C_pb_ind(SEXP s_cl)
{
    const int *cl = INTEGER(s_cl); int n = LENGTH(s_cl);
    R_xlen_t N = (R_xlen_t) n * (n - 1) / 2, t = 0;
    SEXP Y = PROTECT(allocVector(LGLSXP, N)); int *y = LOGICAL(Y);
    for (int m1 = 1; m1 < n; m1++) { int c1 = cl[m1]; for (int m2 = 0; m2 < m1; m2++) y[t++] = (cl[m2] != c1); }
    UNPROTECT(1);
    return Y;
}

/* Hubert: S = sum over i < j (i outer, j inner) of (P[i,j] - meanP) * (Q[i,j] - meanQ) */
SEXP C_hubert_sum(SEXP s_P, SEXP s_Dk, SEXP s_cl, SEXP s_mP, SEXP s_mQ)
{
    /* P is symmetric (as.matrix of a dist), so P[i, j] is read as P[j, i] from column i;
       Q[i, j] is the distance between the centres of cl[i] and cl[j], taken from Dk */
    const double *P = REAL(s_P), *Dk = REAL(s_Dk); const int *cl = INTEGER(s_cl); double mP = asReal(s_mP), mQ = asReal(s_mQ);
    int n = LENGTH(s_cl), k = INTEGER(getAttrib(s_Dk, R_DimSymbol))[0];
    double S = 0;
    for (int i = 0; i < n - 1; i++) {
        const double *pc = P + (size_t) n * i, *qc = Dk + (size_t) k * (cl[i] - 1);
        for (int j = i + 1; j < n; j++) S = S + (pc[j] - mP) * (qc[cl[j] - 1] - mQ);
        if ((i & 255) == 0) R_CheckUserInterrupt();
    }
    return ScalarReal(S);
}

/* Indice.S (average silhouette) with the original's order of operations.  sum(d[i, cl == j])
 * is R's sum(): extended-precision accumulation over the members in index order.              */
SEXP C_sil(SEXP s_d, SEXP s_cl, SEXP s_K, SEXP s_ld)
{
    const double *d = REAL(s_d); const int *cl = INTEGER(s_cl); int n = LENGTH(s_cl), K = asInteger(s_K), use_ld = asInteger(s_ld);
    int *st, *ix; members(cl, n, K, &st, &ix);
    long double *al = (long double *) R_alloc((size_t) K + 2, sizeof(long double));
    double *ad = (double *) R_alloc((size_t) K + 2, sizeof(double)), *sums = (double *) R_alloc((size_t) K + 2, sizeof(double));
    double Si = 0;
    for (int k = 1; k <= K; k++) {
        int nk = st[k + 1] - st[k]; double Sil;
        if (nk <= 1) Sil = 1;
        else {
            Sil = 0;
            for (int c = st[k]; c < st[k + 1]; c++) {
                int i = ix[c];
                if (use_ld) { for (int j = 1; j <= K; j++) al[j] = 0.0; { const double *col = d + (size_t) n * i; for (int j = 0; j < n; j++) al[cl[j]] += col[j]; }
                    for (int j = 1; j <= K; j++) sums[j] = (double) al[j]; }
                else { for (int j = 1; j <= K; j++) ad[j] = 0.0; { const double *col = d + (size_t) n * i; for (int j = 0; j < n; j++) ad[cl[j]] += col[j]; }
                    for (int j = 1; j <= K; j++) sums[j] = ad[j]; }
                double ai = sums[k] / (double) (nk - 1), bi = 0; int first = 1;
                for (int j = 1; j <= K; j++) if (j != k) {
                    int nj = st[j + 1] - st[j];
                    double v = (nj != 1) ? sums[j] / (double) nj : sums[j];
                    if (first || v < bi) { bi = v; first = 0; }
                }
                Sil = Sil + (bi - ai) / ((ai > bi) ? ai : bi);
            }
        }
        Si = Si + Sil;
        R_CheckUserInterrupt();
    }
    return ScalarReal(Si / (double) n);
}


/* ---- scalar loops of Average.scattering / density.clusters / density.bw --------------------
 * Plain double arithmetic in the original's order: each accumulator receives the same terms
 * in increasing observation (or variable) index.                                              */
SEXP C_var_clusters(SEXP s_x, SEXP s_cl, SEXP s_cen)
{
    const double *x = REAL(s_x), *cen = REAL(s_cen); const int *cl = INTEGER(s_cl);
    int n = LENGTH(s_cl), p = INTEGER(getAttrib(s_x, R_DimSymbol))[1], k = INTEGER(getAttrib(s_cen, R_DimSymbol))[0];
    SEXP out = PROTECT(allocMatrix(REALSXP, k, p)); double *v = REAL(out);
    for (int t = 0; t < k * p; t++) v[t] = 0;
    for (int j = 0; j < p; j++) for (int i = 0; i < n; i++) { int u = cl[i] - 1; double a = x[i + (size_t) n * j] - cen[u + (size_t) k * j]; v[u + (size_t) k * j] = v[u + (size_t) k * j] + a * a; }
    UNPROTECT(1);
    return out;
}
SEXP C_density_clusters(SEXP s_x, SEXP s_cl, SEXP s_cen, SEXP s_stdev)
{
    const double *x = REAL(s_x), *cen = REAL(s_cen); const int *cl = INTEGER(s_cl); double stdev = asReal(s_stdev);
    int n = LENGTH(s_cl), p = INTEGER(getAttrib(s_x, R_DimSymbol))[1], k = INTEGER(getAttrib(s_cen, R_DimSymbol))[0];
    SEXP out = PROTECT(allocVector(VECSXP, 2)); SEXP D = PROTECT(allocMatrix(REALSXP, n, 1)), G = PROTECT(allocMatrix(REALSXP, k, 1));
    double *dist = REAL(D), *dens = REAL(G);
    for (int u = 0; u < k; u++) dens[u] = 0;
    for (int i = 0; i < n; i++) {
        int u = cl[i] - 1; double s = 0;
        for (int j = 0; j < p; j++) { double a = x[i + (size_t) n * j] - cen[u + (size_t) k * j]; s = s + a * a; }
        s = sqrt(s); dist[i] = s;
        if (s <= stdev) dens[u] = dens[u] + 1;
    }
    SET_VECTOR_ELT(out, 0, D); SET_VECTOR_ELT(out, 1, G);
    UNPROTECT(3);
    return out;
}
SEXP C_density_bw(SEXP s_x, SEXP s_cl, SEXP s_cen, SEXP s_stdev)
{
    const double *x = REAL(s_x), *cen = REAL(s_cen); const int *cl = INTEGER(s_cl); double stdev = asReal(s_stdev);
    int n = LENGTH(s_cl), p = INTEGER(getAttrib(s_x, R_DimSymbol))[1], k = INTEGER(getAttrib(s_cen, R_DimSymbol))[0];
    int *st, *ix; members(cl, n, k, &st, &ix);
    SEXP out = PROTECT(allocMatrix(REALSXP, k, k)); double *bw = REAL(out);
    double *moy = (double *) R_alloc((size_t) p + 1, sizeof(double));
    for (int t = 0; t < k * k; t++) bw[t] = 0;
    for (int u = 1; u <= k; u++) for (int v = 1; v <= k; v++) if (v != u) {
        for (int j = 0; j < p; j++) moy[j] = (cen[(u - 1) + (size_t) k * j] + cen[(v - 1) + (size_t) k * j]) / 2;
        double cnt = 0;
        for (int w = 0; w < 2; w++) { int g = w ? v : u;       /* counts are whole numbers: order is immaterial */
            for (int c = st[g]; c < st[g + 1]; c++) { int i = ix[c]; double s = 0;
                for (int j = 0; j < p; j++) { double a = x[i + (size_t) n * j] - moy[j]; s = s + a * a; }
                s = sqrt(s); if (s <= stdev) cnt = cnt + 1; } }
        bw[(u - 1) + (size_t) k * (v - 1)] = cnt;
    }
    UNPROTECT(1);
    return out;
}

static const R_CallMethodDef callMethods[] = {
    {"C_var_clusters", (DL_FUNC) &C_var_clusters, 3}, {"C_density_clusters", (DL_FUNC) &C_density_clusters, 4}, {"C_density_bw", (DL_FUNC) &C_density_bw, 4},
    {"C_wb", (DL_FUNC) &C_wb, 3}, {"C_count_pm", (DL_FUNC) &C_count_pm, 2}, {"C_pb_x", (DL_FUNC) &C_pb_x, 1}, {"C_pb_ind", (DL_FUNC) &C_pb_ind, 1},
    {"C_hubert_sum", (DL_FUNC) &C_hubert_sum, 5}, {"C_sil", (DL_FUNC) &C_sil, 4}, {NULL, NULL, 0}
};
void R_init_NbClustFast(DllInfo *dll) { R_registerRoutines(dll, NULL, callMethods, NULL, NULL); R_useDynamicSymbols(dll, FALSE); }
