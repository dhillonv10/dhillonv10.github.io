# Tests of NbClust(..., corrected = TRUE).
library(NbClustFast); pdf(NULL)
quiet <- function(expr) { v <- NULL; invisible(capture.output(v <- suppressWarnings(expr))); v }
# slow, independent reference for the published gap statistic with the same seeded reference draws
ref_gap <- function(X, cls, B = 10, method = "ward.D2") {
  set.seed(1); n <- nrow(X); lo <- apply(X, 2, min); hi <- apply(X, 2, max)
  R <- lapply(1:B, function(b) { Y <- X; for (j in 1:ncol(X)) Y[, j] <- runif(n, lo[j], hi[j]); Y })
  W <- function(Y, pp) { k <- max(pp); s <- 0; for (z in 1:k) { i <- which(pp == z); if (length(i) >= 2) { ctr <- colMeans(Y[i, , drop = FALSE]); s <- s + sum(sweep(Y[i, , drop = FALSE], 2, ctr)^2) / (n - k) } }; s }
  sapply(cls, function(k) { lw <- sapply(R, function(Y) log(W(Y, cutree(hclust(dist(Y), method = method), k)))); mean(lw) - log(W(X, cutree(hclust(dist(X), method = method), k))) })
}
set.seed(8); worst <- 0; rng_ok <- TRUE; other_ok <- TRUE; nt <- 0
for (it in 1:25) {
  n <- sample(40:120, 1); p <- sample(2:5, 1); g <- sample(3, n, TRUE); X <- matrix(rnorm(n * p), n, p) + matrix(rnorm(3 * p, sd = 3), 3, p)[g, ]
  meth <- sample(c("ward.D2", "complete", "average"), 1)
  set.seed(123); before <- .Random.seed; a <- quiet(NbClust(X, method = meth, index = "gap", min.nc = 2, max.nc = 7, corrected = TRUE)); rng_ok <- rng_ok && identical(before, .Random.seed)
  r <- ref_gap(X, 2:7, method = meth); worst <- max(worst, abs(unname(a$All.index) - r)); nt <- nt + 1
  if (it <= 8) { b0 <- quiet(NbClust(X, method = meth, index = "all", min.nc = 2, max.nc = 7)); b1 <- quiet(NbClust(X, method = meth, index = "all", min.nc = 2, max.nc = 7, corrected = TRUE)); other_ok <- other_ok && identical(b0$All.index, b1$All.index) }
}
cat(sprintf("corrected gap vs independent reference: %d data sets, largest difference %.2e\n", nt, worst))
cat("caller's random-number stream untouched by corrected = TRUE:", rng_ok, "\n")
cat("index = 'all' (no gap) unchanged by corrected = TRUE:", other_ok, "\n")
set.seed(5); X <- matrix(rnorm(600), 200, 3); set.seed(42); u1 <- runif(1); set.seed(42); invisible(quiet(NbClust::NbClust(X, method = "kmeans", index = "silhouette", min.nc = 2, max.nc = 4))); u2 <- runif(1)
cat("original NbClust changes the caller's stream:", !identical(u1, u2), "\n")
