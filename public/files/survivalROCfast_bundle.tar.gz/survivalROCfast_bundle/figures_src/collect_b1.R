library(survivalROCfast); S <- asNamespace("survivalROC")
# left-truncated cohort: delayed entry independent of survival, only patients still under observation at entry are seen
set.seed(3); N <- 600; m <- rnorm(N); t <- rexp(N, exp(m)); c <- rexp(N, .5); en <- runif(N, 0, 0.4); tm <- pmin(t, c); st <- as.numeric(t <= c); keep <- tm > en
m <- m[keep]; tm <- tm[keep]; st <- st[keep]; en <- en[keep]; n <- length(tm); cat("n", n, "\n")
sh <- t(sapply(1:300, function(i) { p <- sample(n); c(orig = S$survivalROC(tm[p], st[p], m[p], entry = en[p], predict.time = 1, method = "KM")$AUC, corrected = survivalROC(tm[p], st[p], m[p], entry = en[p], predict.time = 1, method = "KM", corrected = TRUE)$AUC) }))
o <- order(tm); sorted <- S$survivalROC(tm[o], st[o], m[o], entry = en[o], predict.time = 1, method = "KM")$AUC
cat(sprintf("orig range %.4f-%.4f; corrected range %.6f-%.6f; orig on time-sorted input %.6f; n=%d\n", min(sh[, 1]), max(sh[, 1]), min(sh[, 2]), max(sh[, 2]), sorted, n))
write.csv(data.frame(sh, n = n, sorted = sorted), "results/defect_entry_shuffle.csv", row.names = FALSE)
