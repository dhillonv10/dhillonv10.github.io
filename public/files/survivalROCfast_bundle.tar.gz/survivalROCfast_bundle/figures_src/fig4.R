source("figs_common.R")
cv <- read.csv("results/nhanes_curves.csv"); sub <- read.csv("results/nhanes_subsample.csv"); nf <- read.csv("results/nhanes_fast.csv"); full <- read.csv("results/nhanes_full_stock.csv")
open_png("survivalroc_Fig4_nhanes.png", 10, 4.8)
layout(matrix(1:2, 1), widths = c(1, 1.35)); par(mar = c(4, 4.4, 4.2, 1.2), oma = c(0, 0, 1.8, 0))
plot(NA, xlim = c(0, 1), ylim = c(0, 1), xlab = "False-positive fraction (1 − specificity)", ylab = "True-positive fraction (sensitivity)", axes = FALSE, asp = 1)
axis(1, col = NA, col.ticks = COL["grey"]); axis(2, col = NA, col.ticks = COL["grey"]); abline(h = seq(0, 1, 0.2), v = seq(0, 1, 0.2), col = COL["light"], lwd = 0.5); abline(0, 1, col = COL["grey"], lty = 3)
for (k in list(c("KM", "grey", 1), c("NNE", "orig", 1), c("NNE corrected", "corr", 1))) { d <- cv[cv$curve == k[1], ]; lines(d$FP, d$TP, col = COL[k[2]], lwd = 1.8) }
legend("bottomright", sprintf("%s  AUC %.3f", c("KM", "NNE, original R function", "NNE, corrected"), nf$AUC[match(c("KM", "NNE", "NNE corrected"), nf$fun)]), col = COL[c("grey", "orig", "corr")], lwd = 2, bty = "n", cex = 0.78, text.col = COL["ink"])
ttl("10-year mortality from a simple risk score", "NHANES 1999–2018: 49,554 adults, 6,822 deaths")
par(mar = c(4, 4.6, 4.2, 8))
plot(NA, log = "xy", xlim = c(450, 60000), ylim = c(2e-4, 4e4), xlab = "Adults in the analysis (random subsamples, then the full cohort)", ylab = "", axes = FALSE, xaxs = "i", yaxs = "i")
time_axis(2, c(2e-4, 4e4)); axis(1, at = c(500, 1000, 2000, 4000, 8000, 16000, 49554), labels = c("500", "1k", "2k", "4k", "8k", "16k", "49,554"), col = NA, col.ticks = COL["grey"], gap.axis = 0.1)
sty <- list(KM = 16, NNE = 17, C = 15)
for (f in c("KM", "NNE", "C")) { s <- sub[sub$fun == f, ]; fu <- full[full$fun == f, ]
  xs <- c(s$n, 49554); lines(xs, c(s$fast, nf$fast[nf$fun == f]), col = COL["fast"], lwd = 1.4); points(xs, c(s$fast, nf$fast[nf$fun == f]), pch = sty[[f]], col = COL["fast"], cex = 1)
  lines(s$n, s$stock, col = COL["orig"], lwd = 1.4); points(s$n, s$stock, pch = sty[[f]], col = COL["orig"], cex = 1)
  segments(max(s$n), s$stock[which.max(s$n)], 49554, fu$stock, col = COL["orig"], lwd = 1.4, lty = if (fu$measured) 1 else 3); points(49554, fu$stock, pch = if (fu$measured) sty[[f]] else c(KM = 1, NNE = 2, C = 0)[[f]], col = COL["orig"], cex = 1.1)
  oy <- c(KM = 0.62, NNE = 1.7, C = 1)[[f]]; ny <- c(KM = 0.7, NNE = 1.25, C = 1)[[f]]; nm <- c(KM = "KM", NNE = "NNE", C = "C routine")[[f]]
  text(49554 * 1.12, fu$stock * oy, sprintf("%s: %s%s", nm, fmt_time(fu$stock), if (fu$measured) "" else " †"), adj = c(0, 0.5), cex = 0.72, col = COL["orig"], font = 2, xpd = NA)
  text(49554 * 1.12, nf$fast[nf$fun == f] * ny, sprintf("%s: %s", nm, fmt_time(nf$fast[nf$fun == f])), adj = c(0, 0.5), cex = 0.72, col = COL["fast"], font = 2, xpd = NA) }
text(520, 1.5e4, "Original", col = COL["orig"], font = 2, cex = 0.85, adj = 0); text(6000, 9e-4, "New code", col = COL["fast"], font = 2, cex = 0.85, adj = 0)
ttl("Run time as the cohort grows", "Circles: KM. Triangles: NNE. Squares: Compiled routine. Open symbol and †: Original timed on Google Colab")
mtext("The largest cohort: 49,554 US adults followed for mortality", outer = TRUE, adj = 0.01, font = 2, cex = 0.95, col = COL["ink"], line = 0.4)
dev.off()
