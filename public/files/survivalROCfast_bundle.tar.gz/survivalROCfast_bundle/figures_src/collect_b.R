# Defect diagnostics: original behaviour vs corrected = TRUE
library(survivalROCfast); S <- asNamespace("survivalROC")
set.seed(3); n <- 300; m <- rnorm(n); t <- rexp(n, exp(m)); c <- rexp(n, .5); tm <- pmin(t, c); st <- as.numeric(t <= c); en <- runif(n, 0, 0.5) * tm
# 1. row order with entry times
sh <- t(sapply(1:300, function(i) { p <- sample(n); c(orig = S$survivalROC(tm[p], st[p], m[p], entry = en[p], predict.time = 1, method = "KM")$AUC, corrected = survivalROC(tm[p], st[p], m[p], entry = en[p], predict.time = 1, method = "KM", corrected = TRUE)$AUC) }))
write.csv(sh, "results/defect_entry_shuffle.csv", row.names = FALSE)
# 2. lambda
lam <- 10^seq(-2, 1, length.out = 40)
la <- data.frame(lambda = lam, orig = sapply(lam, function(l) S$survivalROC(tm, st, m, predict.time = 1, method = "NNE", lambda = l)$AUC), corrected = sapply(lam, function(l) survivalROC(tm, st, m, predict.time = 1, method = "NNE", lambda = l, corrected = TRUE)$AUC))
la$members_orig <- sapply(lam, function(l) mean(sapply(m, function(u) mean(exp(-(m - u)^2 / l^2) != 0))))
write.csv(la, "results/defect_lambda.csv", row.names = FALSE)
# 3. R function vs C routine, same span
sp <- 0.25 * n^-0.2
cur <- function(r, lab) data.frame(curve = lab, FP = r$FP, TP = r$TP, AUC = r$AUC)
rc <- rbind(cur(S$survivalROC(tm, st, m, predict.time = 1, method = "NNE", span = sp), "orig R"), cur(S$survivalROC.C(tm, st, m, predict.time = 1, span = sp), "orig C"),
            cur(survivalROC(tm, st, m, predict.time = 1, method = "NNE", span = sp, corrected = TRUE), "corrected R"), cur(survivalROC.C(tm, st, m, predict.time = 1, span = sp, corrected = TRUE), "corrected C"))
write.csv(rc, "results/defect_r_vs_c.csv", row.names = FALSE)
spans <- seq(0.02, 0.5, length.out = 25)
gap <- data.frame(span = spans, orig = sapply(spans, function(s) abs(S$survivalROC(tm, st, m, predict.time = 1, method = "NNE", span = s)$AUC - S$survivalROC.C(tm, st, m, predict.time = 1, span = s)$AUC)),
                  corrected = sapply(spans, function(s) abs(survivalROC(tm, st, m, predict.time = 1, method = "NNE", span = s, corrected = TRUE)$AUC - survivalROC.C(tm, st, m, predict.time = 1, span = s, corrected = TRUE)$AUC)))
write.csv(gap, "results/defect_r_vs_c_gap.csv", row.names = FALSE)
# 4. window sizes: neighbours used per marker value (orig R, orig C, corrected), sorted by marker rank
o <- order(m); xs <- m[o]; K <- floor(n * sp + 0.5)
wr <- sapply(seq_len(n), function(j) { dd <- xs - xs[j]; l <- sort(dd)[min(sum(dd < 0) + 1 + trunc(n * sp + 0.5), n)]; sum(dd >= -l & dd <= l) })
wc <- sapply(seq_len(n), function(j) { first <- if (j == 1) n - 1 else j - 2; last <- j - 1; tg <- floor((first + last) / 2 + 0.5); i0 <- min(max(tg - K, 0), first); i1 <- max(min(tg + K, n - 1), last); i1 - i0 + 1 })
wcent <- sapply(seq_len(n), function(j) { first <- if (j == 1) n - 1 else j - 2; last <- j - 1; tg <- floor((first + last) / 2 + 0.5); i0 <- min(max(tg - K, 0), first); i1 <- max(min(tg + K, n - 1), last); (i0 + i1) / 2 + 1 })
wk <- sapply(seq_len(n), function(j) sum(abs(seq_len(n) - j) < sp * n))
write.csv(data.frame(rank = seq_len(n), orig_R = wr, orig_C = wc, orig_C_centre = wcent, corrected = wk), "results/defect_windows.csv", row.names = FALSE)
cat("done\n")
