# AML: corrected NNE per gene, and timing
suppressPackageStartupMessages(library(data.table)); library(survivalROCfast)
ex <- fread(cmd = "zcat data/LAML_HiSeqV2.gz"); sv <- fread("data/LAML_survival.txt"); sv <- sv[!is.na(OS) & !is.na(OS.time) & sample %in% names(ex)]
m <- as.matrix(ex[, sv$sample, with = FALSE]); rownames(m) <- ex$sample; m <- m[apply(m, 1, sd) > 0, ]; n <- nrow(sv); span <- 0.25 * n^(-0.2)
t <- system.time(auc <- sapply(seq_len(nrow(m)), function(g) survivalROC(sv$OS.time, sv$OS, m[g, ], predict.time = 730, method = "NNE", span = span, corrected = TRUE)$AUC))[3]
a <- readRDS("aml_stock_NNE.rds"); b <- readRDS("aml_fast_NNE.rds"); k1 <- readRDS("aml_stock_KM.rds"); k2 <- readRDS("aml_fast_KM.rds")
write.csv(data.frame(gene = rownames(m), stock_KM = sapply(k1$res, `[[`, "AUC"), fast_KM = sapply(k2$res, `[[`, "AUC"), stock_NNE = sapply(a$res, `[[`, "AUC"), fast_NNE = sapply(b$res, `[[`, "AUC"), corrected_NNE = auc), "results/aml_auc.csv", row.names = FALSE)
maxd <- max(sapply(seq_along(a$res), function(i) max(abs(a$res[[i]]$TP - b$res[[i]]$TP), abs(a$res[[i]]$FP - b$res[[i]]$FP))))
cat(sprintf("AML corrected NNE: %.1f s; max |TP/FP stock - fast| over all genes: %g; identical lists: %s %s\n", t, maxd, identical(a$res, b$res), identical(k1$res, k2$res)))
writeLines(sprintf("%.3f", t), "results/aml_corrected_seconds.txt")
