# NHANES subsamples: stock vs fast on real data, all three entry points
S <- asNamespace("survivalROC"); F <- asNamespace("survivalROCfast"); d0 <- readRDS("data/nhanes_cc.rds"); set.seed(1); out <- NULL
tm <- function(f) { t <- system.time(r <- f())[3]; if (t < 0.3) { k <- max(3, ceiling(0.3 / max(t, 1e-4))); t <- system.time(for (i in seq_len(k)) f())[3] / k }; list(t = unname(t), r = r) }
for (n in c(500, 1000, 2000, 4000, 8000, 16000)) { d <- d0[sample(nrow(d0), n), ]; sp <- 0.25 * n^(-0.2)
  calls <- list(KM = function(p) p$survivalROC(d$months, d$mortstat, d$score, predict.time = 120, method = "KM"), NNE = function(p) p$survivalROC(d$months, d$mortstat, d$score, predict.time = 120, method = "NNE", span = sp), C = function(p) p$survivalROC.C(d$months, d$mortstat, d$score, predict.time = 120, span = sp))
  for (nm in names(calls)) { f <- tm(function() calls[[nm]](F)); s <- tm(function() calls[[nm]](S))
    out <- rbind(out, data.frame(n = n, fun = nm, stock = s$t, fast = f$t, identical = identical(s$r, f$r))); cat(n, nm, s$t, f$t, identical(s$r, f$r), "\n"); write.csv(out, "results/nhanes_subsample.csv", row.names = FALSE) } }
