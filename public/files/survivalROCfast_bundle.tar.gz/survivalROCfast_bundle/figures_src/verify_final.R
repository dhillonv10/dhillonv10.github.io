# Re-verify every identity claim with the final build.
suppressPackageStartupMessages(library(data.table)); S <- asNamespace("survivalROC"); F <- asNamespace("survivalROCfast"); out <- NULL
add <- function(what, same, stock = NA, fast = NA) { out <<- rbind(out, data.frame(check = what, identical = same, stock_s = stock, fast_s = fast)); cat(sprintf("%-58s %s\n", what, same)) }
tmf <- function(f) { t <- system.time(r <- f())[3]; if (t < 0.3) { k <- max(3, ceiling(0.3 / max(t, 1e-4))); t <- system.time(for (i in seq_len(k)) f())[3] / k }; list(t = unname(t), r = r) }
# AML
ex <- fread(cmd = "zcat data/LAML_HiSeqV2.gz"); sv <- fread("data/LAML_survival.txt"); sv <- sv[!is.na(OS) & !is.na(OS.time) & sample %in% names(ex)]
m <- as.matrix(ex[, sv$sample, with = FALSE]); rownames(m) <- ex$sample; m <- m[apply(m, 1, sd) > 0, ]; n <- nrow(sv); sp <- 0.25 * n^(-0.2)
tk <- system.time(k <- lapply(seq_len(nrow(m)), function(g) F$survivalROC(sv$OS.time, sv$OS, m[g, ], predict.time = 730, method = "KM")))[3]; names(k) <- rownames(m)
tn <- system.time(nn <- lapply(seq_len(nrow(m)), function(g) F$survivalROC(sv$OS.time, sv$OS, m[g, ], predict.time = 730, method = "NNE", span = sp)))[3]; names(nn) <- rownames(m)
a <- readRDS("aml_stock_KM.rds"); b <- readRDS("aml_stock_NNE.rds")
add("AML 19,902 genes, KM", identical(a$res, k), a$seconds, tk); add("AML 19,902 genes, NNE", identical(b$res, nn), b$seconds, tn)
# simulated n = 5000
sim <- function(n, seed = 1) { set.seed(seed); m <- rnorm(n); t <- rexp(n, exp(m)); c <- rexp(n, 0.5); list(time = pmin(t, c), status = as.numeric(t <= c), marker = m) }
d <- sim(5000); f1 <- tmf(function() F$survivalROC(d$time, d$status, d$marker, predict.time = 1, method = "KM")); f2 <- tmf(function() F$survivalROC(d$time, d$status, d$marker, predict.time = 1, method = "NNE", span = 0.25 * 5000^-0.2))
add("Simulated n = 5,000, KM", identical(readRDS("stock5000_KM.rds"), f1$r), 980.3, f1$t); add("Simulated n = 5,000, NNE", identical(readRDS("stock5000_NNE.rds"), f2$r), 2499.2, f2$t)
# pan-cancer
p <- fread("data/pancan_survival.tsv"); p <- p[!is.na(OS) & !is.na(OS.time) & !is.na(age_at_initial_pathologic_diagnosis) & OS.time > 0]; x <- p$age_at_initial_pathologic_diagnosis + 0; sp <- 0.25 * nrow(p)^(-0.2)
for (mm in c("KM", "NNE")) { cl <- function(ns) if (mm == "KM") ns$survivalROC(p$OS.time, p$OS, x, predict.time = 1825, method = "KM") else ns$survivalROC(p$OS.time, p$OS, x, predict.time = 1825, method = "NNE", span = sp)
  st <- system.time(s <- cl(S))[3]; f <- tmf(function() cl(F)); add(sprintf("Pan-cancer 12,373 patients, age, %s", mm), identical(s, f$r), st, f$t) }
# NHANES
dn <- readRDS("data/nhanes_cc.rds"); spn <- 0.25 * nrow(dn)^(-0.2)
fk <- tmf(function() F$survivalROC(dn$months, dn$mortstat, dn$score, predict.time = 120, method = "KM")); sk <- readRDS("nhanes_stock_KM.rds"); add("NHANES 49,554, risk score, KM", identical(sk$r, fk$r), sk$seconds, fk$t)
fc <- tmf(function() F$survivalROC.C(dn$months, dn$mortstat, dn$score, predict.time = 120, span = spn)); sc <- readRDS("nhanes_stock_C.rds"); add("NHANES 49,554, risk score, C routine", identical(sc$r, fc$r), sc$seconds, fc$t)
xr <- round(dn$score, 2); st <- system.time(s <- S$survivalROC(dn$months, dn$mortstat, xr, predict.time = 120, method = "NNE", span = spn))[3]; f <- tmf(function() F$survivalROC(dn$months, dn$mortstat, xr, predict.time = 120, method = "NNE", span = spn))
add(sprintf("NHANES 49,554, score rounded to 2 dp (%d values), NNE", length(unique(xr))), identical(s, f$r), st, f$t)
st <- system.time(s <- S$survivalROC(dn$months, dn$mortstat, xr, predict.time = 120, method = "KM"))[3]; f <- tmf(function() F$survivalROC(dn$months, dn$mortstat, xr, predict.time = 120, method = "KM"))
add(sprintf("NHANES 49,554, score rounded to 2 dp (%d values), KM", length(unique(xr))), identical(s, f$r), st, f$t)
da <- readRDS("data/nhanes_all.rds"); spa <- 0.25 * nrow(da)^(-0.2)
for (mm in c("KM", "NNE")) { cl <- function(ns) if (mm == "KM") ns$survivalROC(da$months, da$mortstat, da$RIDAGEYR, predict.time = 120, method = "KM") else ns$survivalROC(da$months, da$mortstat, da$RIDAGEYR, predict.time = 120, method = "NNE", span = spa)
  st <- system.time(s <- cl(S))[3]; f <- tmf(function() cl(F)); add(sprintf("NHANES 59,064, age, %s", mm), identical(s, f$r), st, f$t) }
write.csv(out, "results/verify_final.csv", row.names = FALSE)
