# NHANES full cohort: fast timings (median of 5), curves, corrected estimator, and age as marker on all adults
library(survivalROCfast); d <- readRDS("data/nhanes_cc.rds"); n <- nrow(d); sp <- 0.25 * n^(-0.2)
med <- function(f) { ts <- sapply(1:5, function(i) system.time(r <<- f())[3]); list(t = median(ts), r = r) }
r <- NULL
k <- med(function() survivalROC(d$months, d$mortstat, d$score, predict.time = 120, method = "KM"))
nn <- med(function() survivalROC(d$months, d$mortstat, d$score, predict.time = 120, method = "NNE", span = sp))
cc <- med(function() survivalROC.C(d$months, d$mortstat, d$score, predict.time = 120, span = sp))
co <- med(function() survivalROC(d$months, d$mortstat, d$score, predict.time = 120, method = "NNE", span = sp, corrected = TRUE))
write.csv(data.frame(fun = c("KM", "NNE", "C", "NNE corrected"), fast = c(k$t, nn$t, cc$t, co$t), AUC = c(k$r$AUC, nn$r$AUC, cc$r$AUC, co$r$AUC)), "results/nhanes_fast.csv", row.names = FALSE)
thin <- function(x, lab) { i <- unique(round(seq(1, length(x$FP), length.out = 1500))); data.frame(curve = lab, FP = x$FP[i], TP = x$TP[i]) }
write.csv(rbind(thin(k$r, "KM"), thin(nn$r, "NNE"), thin(cc$r, "C"), thin(co$r, "NNE corrected")), "results/nhanes_curves.csv", row.names = FALSE)
saveRDS(list(KM = k$r, NNE = nn$r, C = cc$r), "results/nhanes_fast_full.rds")
a <- readRDS("data/nhanes_all.rds"); na <- nrow(a)
ta <- med(function() survivalROC(a$months, a$mortstat, a$RIDAGEYR, predict.time = 120, method = "NNE", span = 0.25 * na^(-0.2)))
sa <- system.time(s <- survivalROC::survivalROC(a$months, a$mortstat, a$RIDAGEYR, predict.time = 120, method = "NNE", span = 0.25 * na^(-0.2)))[3]
cat(sprintf("all adults n=%d, age marker (%d values): stock NNE %.1f s, fast %.4f s, identical %s, AUC %.4f\n", na, length(unique(a$RIDAGEYR)), sa, ta$t, identical(s, ta$r), s$AUC))
writeLines(sprintf("%d,%d,%.3f,%.5f,%s,%.5f", na, length(unique(a$RIDAGEYR)), sa, ta$t, identical(s, ta$r), s$AUC), "results/nhanes_age.csv")
print(read.csv("results/nhanes_fast.csv"))
