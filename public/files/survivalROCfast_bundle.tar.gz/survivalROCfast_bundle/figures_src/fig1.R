source("figs_common.R")
st <- read.csv("results/scaling_stock.csv"); fa <- read.csv("results/scaling_fast.csv")
open_png("survivalroc_Fig1_scaling_simulated.png", 10, 4.3)
par(mfrow = c(1, 3), mar = c(3.6, 4.4, 3.2, 0.8), oma = c(0, 0, 1.6, 0))
panels <- list(c("KM", "survivalROC(), KM method"), c("NNE", "survivalROC(), NNE method"), c("C", "survivalROC.C(), compiled routine"))
for (p in panels) { s <- st[st$fun == p[1], ]; f <- fa[fa$fun == p[1], ]
  plot(NA, log = "xy", xlim = c(220, 130000), ylim = c(1e-4, 1e5), xlab = "Patients (n)", ylab = "", axes = FALSE, xaxs = "i", yaxs = "i")
  time_axis(2, c(1e-4, 1e5)); n_axis(1, c(250, 100000))
  title(main = p[2], adj = 0, cex.main = 1.0, font.main = 2, col.main = COL["ink"], line = 1.4)
  fit <- lm(log(seconds) ~ log(n), s[s$n >= 1000, ])
  lines(s$n, s$seconds, col = COL["orig"], lwd = 1.6); points(s$n, s$seconds, pch = 16, col = COL["orig"], cex = 1.1)
  lines(f$n, f$seconds, col = COL["fast"], lwd = 1.6); points(f$n, f$seconds, pch = 16, col = COL["fast"], cex = 1.1)
  nb <- max(s$n); sb <- s$seconds[s$n == nb]; fb <- f$seconds[f$n == nb]
  segments(nb, fb * 1.6, nb, sb / 1.6, col = COL["grey"], lwd = 0.8); text(nb * 0.86, exp((log(sb) + log(fb)) / 2), paste0(fmt_x(sb / fb), "\nfaster"), adj = c(1, 0.5), cex = 0.85, col = COL["ink"], font = 2)
  text(nb, sb * 3.2, sprintf("Original\n%s", fmt_time(sb)), col = COL["orig"], cex = 0.8, adj = c(0.5, 0), font = 2)
  text(100000, 2.5e-3, sprintf("New code: %s\nat 100,000 patients", fmt_time(f$seconds[f$n == 1e5])), col = COL["fast"], cex = 0.8, adj = c(1, 0.5), font = 2)
  mtext(sprintf("Original: Time grows as n^%.1f", coef(fit)[2]), side = 3, line = 0.25, adj = 0, cex = 0.62, col = COL["grey"]) }
mtext("Run time on simulated cohorts: The original grows with the cube of cohort size", outer = TRUE, adj = 0.01, font = 2, cex = 0.95, col = COL["ink"], line = 0.3)
dev.off()
