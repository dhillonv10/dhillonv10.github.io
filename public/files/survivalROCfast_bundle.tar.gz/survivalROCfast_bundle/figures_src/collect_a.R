library(survivalROCfast)
sim <- function(n, seed = 1) { set.seed(seed); m <- rnorm(n); t <- rexp(n, exp(m)); c <- rexp(n, 0.5); list(time = pmin(t, c), status = as.numeric(t <= c), marker = m) }
tm <- function(f) { t <- system.time(f())[3]; if (t < 0.3) { k <- max(3, ceiling(0.3 / max(t, 1e-4))); t <- system.time(for (i in seq_len(k)) f())[3] / k }; unname(t) }
out <- NULL
for (n in c(250, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000)) { d <- sim(n); sp <- 0.25 * n^(-0.2)
  out <- rbind(out, data.frame(n = n, impl = "fast", fun = c("KM", "NNE", "C", "NNE corrected"), seconds = c(
    tm(function() survivalROC(d$time, d$status, d$marker, predict.time = 1, method = "KM")),
    tm(function() survivalROC(d$time, d$status, d$marker, predict.time = 1, method = "NNE", span = sp)),
    tm(function() survivalROC.C(d$time, d$status, d$marker, predict.time = 1, span = sp)),
    tm(function() survivalROC(d$time, d$status, d$marker, predict.time = 1, method = "NNE", span = sp, corrected = TRUE)))))
  cat(n, "\n") }
write.csv(out, "results/scaling_fast.csv", row.names = FALSE)
