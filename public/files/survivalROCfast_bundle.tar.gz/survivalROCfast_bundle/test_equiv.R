# Randomised bit-for-bit comparison of survivalROCfast against survivalROC 1.0.3.1.
# Usage: Rscript test_equiv.R <n cases> <seed> <max n>
a <- commandArgs(TRUE); N <- as.integer(a[1]); seed <- as.integer(a[2]); maxn <- as.integer(a[3])
fast <- asNamespace("survivalROCfast"); ref <- asNamespace("survivalROC")
run <- function(f, args) { out <- NULL; txt <- capture.output(r <- tryCatch(do.call(f, args), error = function(e) structure(list(msg = "ERROR"), class = "err"))); list(r = r, txt = txt) }
set.seed(seed); stats <- c(identical = 0, both_error = 0, mismatch = 0); kinds <- table(character(0)); fastpath <- table(character(0)); errk <- table(character(0)); bad <- list()
for (it in seq_len(N)) {
  n <- sample(c(2:12, sample(13:maxn, 6)), 1)
  x <- switch(sample(4, 1), rnorm(n), round(rnorm(n), 1), sample(1:5, n, TRUE), as.numeric(sample(1:3, n, TRUE)))
  tt <- rexp(n, exp(0.7 * as.numeric(scale(x + rnorm(n, sd = 0.01), scale = FALSE)))); cc <- rexp(n, runif(1, 0.1, 2))
  tm <- pmin(tt, cc); st <- as.numeric(tt <= cc)
  if (runif(1) < 0.4) tm <- ceiling(tm * sample(c(2, 5, 20), 1)) / 10            # tied times
  if (runif(1) < 0.1) st <- sample(0:2, n, TRUE)
  if (runif(1) < 0.05) st <- st == 1
  if (runif(1) < 0.1) st[] <- sample(0:1, 1)
  if (runif(1) < 0.15) { x[sample(n, 1)] <- NA; if (runif(1) < 0.5) tm[sample(n, 1)] <- NA }
  pt <- if (runif(1) < 0.85) as.numeric(quantile(tm, runif(1), na.rm = TRUE)) else sample(c(0, min(tm, na.rm = TRUE) / 2, max(tm, na.rm = TRUE) * 2, median(tm, na.rm = TRUE)), 1)
  which_fun <- sample(c("R", "R", "R", "C"), 1); if (nzchar(Sys.getenv("ONLY"))) which_fun <- Sys.getenv("ONLY"); if (nzchar(Sys.getenv("TRACE"))) saveRDS(list(it = it, tm = tm, st = st, x = x, pt = pt), "last_case.rds")
  if (which_fun == "C") {
    args <- list(Stime = tm, status = as.numeric(st), marker = x, predict.time = pt, span = sample(c(0.05, runif(1, 0, 1), 0.25 * n^-0.2, 0, 1.2), 1))
    kind <- "survivalROC.C"; A <- run(ref$survivalROC.C, args); B <- run(fast$survivalROC.C, args)
  } else {
    args <- list(Stime = tm, status = st, marker = x, predict.time = pt)
    m <- sample(c("KM", "NNE-span-sym", "NNE-span-asym", "NNE-lambda"), 1); kind <- m
    if (m == "KM") args$method <- "KM" else { args$method <- "NNE"
      if (m == "NNE-lambda") args$lambda <- sample(c(0.01, 0.05, 0.3, 5, runif(1, 0, 0.2)), 1) else { args$span <- sample(c(0.05, 0.25 * n^-0.2, runif(1), 0, 1.5), 1); if (m == "NNE-span-asym") args$window <- "asymmetric" } }
    if (runif(1) < 0.2) { args$entry <- pmax(0, tm - rexp(n, 1) * sample(c(0.2, 1, 5), 1)); if (runif(1) < 0.3) args$entry <- args$entry * 0; kind <- paste0(kind, "+entry") }
    if (runif(1) < 0.2) { args$cut.values <- sample(c(quantile(x, c(0.2, 0.5, 0.8), na.rm = TRUE), 0, 0, 10, -10), sample(1:5, 1)); kind <- paste0(kind, "+cuts") }
    A <- run(ref$survivalROC, args); f0 <- fast$.counts$fast; B <- run(fast$survivalROC, args)
    if (fast$.counts$fast > f0) fastpath[kind] <- ifelse(is.na(fastpath[kind]), 0, fastpath[kind]) + 1
  }
  kinds[kind] <- ifelse(is.na(kinds[kind]), 0, kinds[kind]) + 1
  if (inherits(A$r, "err") && inherits(B$r, "err")) { stats["both_error"] <- stats["both_error"] + 1; errk[kind] <- ifelse(is.na(errk[kind]), 0, errk[kind]) + 1 }
  else if (identical(A$r, B$r) && identical(A$txt, B$txt)) stats["identical"] <- stats["identical"] + 1
  else { stats["mismatch"] <- stats["mismatch"] + 1; if (length(bad) < 5) bad[[length(bad) + 1]] <- list(kind = kind, args = args, A = A, B = B) }
}
print(stats); nm <- sort(names(kinds)); mk <- table(character(0)); if (length(bad)) for (b in bad) mk[b$kind] <- ifelse(is.na(mk[b$kind]), 0, mk[b$kind]) + 1; write.csv(data.frame(kind = nm, cases = as.integer(kinds[nm]), fast_path = as.integer(fastpath[nm]), both_error = as.integer(errk[nm]), mismatch = stats["mismatch"]), sprintf("results/equiv_seed%d.csv", seed), row.names = FALSE); print(data.frame(cases = as.integer(kinds[nm]), fast_path = as.integer(fastpath[nm]), both_error = as.integer(errk[nm]), row.names = nm))
if (length(bad)) { saveRDS(bad, sprintf("bad_%d.rds", seed)); for (b in bad) { cat("\nMISMATCH", b$kind, "n =", length(b$args$Stime), "\n"); if (inherits(b$A$r, "err") || inherits(b$B$r, "err")) cat("  ref error:", inherits(b$A$r, "err"), " fast error:", inherits(b$B$r, "err"), "\n") else print(all.equal(b$A$r, b$B$r, tolerance = 0)); str(b$args[setdiff(names(b$args), c("Stime", "status", "marker", "entry"))]) } }
