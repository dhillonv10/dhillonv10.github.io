#!/usr/bin/env bash
# Install stock survivalROC + survivalROCfast, check bit-identity, test the corrected mode, time both.
# Usage: bash run_all.sh [largest n at which to also time the stock R code, default 2000]
# Needs R (>= 4.0) with a C compiler.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p lib results
Rscript -e 'if (!requireNamespace("survivalROC", quietly = TRUE)) install.packages("survivalROC", repos = "https://cloud.r-project.org")'
R CMD INSTALL --no-docs --library=lib survivalROCfast > install.log 2>&1 || { cat install.log; exit 1; }
export R_LIBS=$PWD/lib${R_LIBS:+:$R_LIBS}
echo "== 1. bit-identity of the default mode on 5,000 randomised inputs"
Rscript test_equiv.R 5000 1 300 > equiv.log 2>&1; head -2 equiv.log
echo "== 2. corrected mode against a slow reference written from the published formulas"
Rscript test_corrected.R
echo "== 3. timing, stock vs fast (stock R code is cubic: n = 2000 takes a few minutes)"
Rscript bench_compare.R "${1:-2000}"
