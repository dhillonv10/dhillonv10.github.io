# Genome-wide prognostic screen in AML (TCGA-LAML): 2-year overall-survival AUC for every gene.
# Usage: Rscript demo_aml.R <stock|fast> <KM|NNE> [max genes]
a <- commandArgs(TRUE); impl <- a[1]; method <- a[2]; maxg <- if (length(a) > 2) as.integer(a[3]) else Inf
f <- if (impl == "stock") survivalROC::survivalROC else survivalROCfast::survivalROC
suppressPackageStartupMessages(library(data.table))
ex <- fread(cmd = "zcat data/LAML_HiSeqV2.gz"); sv <- fread("data/LAML_survival.txt")
sv <- sv[!is.na(OS) & !is.na(OS.time) & sample %in% names(ex)]
m <- as.matrix(ex[, sv$sample, with = FALSE]); rownames(m) <- ex$sample
m <- m[apply(m, 1, sd) > 0, ]; if (is.finite(maxg)) m <- m[seq_len(min(maxg, nrow(m))), ]
n <- nrow(sv); span <- 0.25 * n^(-0.2)
t0 <- proc.time()[3]
res <- lapply(seq_len(nrow(m)), function(g) if (method == "KM") f(sv$OS.time, sv$OS, m[g, ], predict.time = 730, method = "KM") else f(sv$OS.time, sv$OS, m[g, ], predict.time = 730, method = "NNE", span = span))
el <- proc.time()[3] - t0
names(res) <- rownames(m); auc <- sapply(res, `[[`, "AUC")
saveRDS(list(res = res, seconds = el), sprintf("aml_%s_%s.rds", impl, method))
cat(sprintf("%s %s: %d patients (%d deaths), %d genes, %.1f s (%.2f ms per gene)\n", impl, method, n, sum(sv$OS), nrow(m), el, 1000 * el / nrow(m)))
o <- order(-abs(auc - 0.5))[1:8]; print(round(auc[o], 3))
