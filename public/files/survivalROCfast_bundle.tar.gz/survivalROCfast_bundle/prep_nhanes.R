# NHANES 1999-2018 adults with public-use linked mortality (follow-up through 31 Dec 2019).
suppressPackageStartupMessages({library(foreign); library(survival)})
yrs <- seq(1999, 2017, 2); suf <- c("", paste0("_", LETTERS[2:10])); dd <- "data/nhanes"
all <- list()
for (i in seq_along(yrs)) {
  demo <- read.xport(file.path(dd, paste0("DEMO", suf[i], ".xpt")))[, c("SEQN", "RIDAGEYR", "RIAGENDR")]
  bmx <- read.xport(file.path(dd, paste0("BMX", suf[i], ".xpt")))[, c("SEQN", "BMXBMI")]
  bpx <- read.xport(file.path(dd, paste0("BPX", suf[i], ".xpt")))[, c("SEQN", "BPXSY1")]
  mf <- file.path(dd, sprintf("NHANES_%d_%d_MORT_2019_PUBLIC.dat", yrs[i], yrs[i] + 1)); L <- readLines(mf)
  num <- function(a, b) suppressWarnings(as.numeric(trimws(substr(L, a, b))))
  mort <- data.frame(SEQN = num(1, 6), eligstat = num(15, 15), mortstat = num(16, 16), permth_exm = num(46, 48), permth_int = num(43, 45))
  d <- Reduce(function(a, b) merge(a, b, by = "SEQN", all.x = TRUE), list(demo, bmx, bpx, mort)); d$cycle <- yrs[i]; all[[i]] <- d
}
d <- do.call(rbind, all)
cat(sprintf("participants %d | adults 18+ %d | mortality-eligible adults %d\n", nrow(d), sum(d$RIDAGEYR >= 18), sum(d$RIDAGEYR >= 18 & d$eligstat %in% 1)))
d <- d[d$RIDAGEYR >= 18 & d$eligstat %in% 1 & !is.na(d$mortstat), ]
d$months <- ifelse(is.na(d$permth_exm), d$permth_int, d$permth_exm); d <- d[!is.na(d$months), ]
cat(sprintf("all eligible adults with follow-up: %d, deaths %d, median follow-up %.0f months\n", nrow(d), sum(d$mortstat), median(d$months)))
saveRDS(d, "data/nhanes_all.rds")
cc <- d[complete.cases(d[, c("BMXBMI", "BPXSY1")]), ]
fit <- coxph(Surv(months, mortstat) ~ RIDAGEYR + factor(RIAGENDR) + BMXBMI + I(BMXBMI^2) + BPXSY1, data = cc)
cc$score <- as.numeric(predict(fit, type = "lp"))
cat(sprintf("complete cases (age, sex, BMI, systolic BP): %d, deaths %d, distinct scores %d, distinct ages %d, distinct follow-up times %d\n", nrow(cc), sum(cc$mortstat), length(unique(cc$score)), length(unique(cc$RIDAGEYR)), length(unique(cc$months))))
saveRDS(cc, "data/nhanes_cc.rds")
