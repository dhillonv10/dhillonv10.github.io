# Large-cohort identity tests: big n with few cut-offs / few marker values keeps the original affordable.
# Usage: Rscript test_large.R <cases> <seed>
a <- commandArgs(TRUE); N <- as.integer(a[1]); set.seed(as.integer(a[2])); S <- asNamespace("survivalROC"); F <- asNamespace("survivalROCfast")
ok <- 0; bad <- 0; kinds <- c()
for (it in seq_len(N)) {
  n <- sample(c(12373L, 49554L, sample(3000:60000, 3)), 1); x <- rnorm(n); tt <- rexp(n, exp(0.6 * x)); cc <- rexp(n, 0.5)
  tm <- ceiling(pmin(tt, cc) * 12) ; st <- as.numeric(tt <= cc); pt <- sample(3:20, 1)
  kind <- sample(c("KM", "NNE", "C"), 1)
  if (kind == "KM") { cuts <- sort(runif(25, -2, 2)); r1 <- S$survivalROC(tm, st, x, predict.time = pt, cut.values = cuts, method = "KM"); r2 <- F$survivalROC(tm, st, x, predict.time = pt, cut.values = cuts, method = "KM") }
  else { xd <- round(x * 4) / 4; sp <- 0.25 * n^-0.2
    if (kind == "NNE") { r1 <- S$survivalROC(tm, st, xd, predict.time = pt, method = "NNE", span = sp); r2 <- F$survivalROC(tm, st, xd, predict.time = pt, method = "NNE", span = sp) }
    else { r1 <- S$survivalROC.C(tm, st, xd, predict.time = pt, span = sp); r2 <- F$survivalROC.C(tm, st, xd, predict.time = pt, span = sp) } }
  if (identical(r1, r2)) ok <- ok + 1 else { bad <- bad + 1; cat("MISMATCH", kind, n, "\n") }; kinds <- c(kinds, kind)
}
cat(sprintf("large-cohort tests: %d identical, %d mismatches (KM %d, NNE %d, C %d; n from 3,000 to 60,000)\n", ok, bad, sum(kinds == "KM"), sum(kinds == "NNE"), sum(kinds == "C")))
writeLines(sprintf("%d,%d,%d,%d,%d", ok, bad, sum(kinds == "KM"), sum(kinds == "NNE"), sum(kinds == "C")), sprintf("results/large_seed%s.csv", a[2]))
