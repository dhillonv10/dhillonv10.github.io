# survivalROCfast

Bit-identical, much faster replacements for `survivalROC::survivalROC()` and
`survivalROC::survivalROC.C()` (time-dependent ROC curves for censored survival data;
Heagerty, Lumley & Pepe, Biometrics 2000; survivalROC 1.0.3.1 on CRAN), plus an opt-in
`corrected = TRUE` mode that fixes four defects of the original.

    bash run_all.sh          # install both, identity checks, corrected-mode tests, timing table
    bash run_all.sh 5000     # also time the stock R code at n = 5000 (about an hour)
    bash get_data.sh         # download the public TCGA and NHANES data used in the benchmarks

Needs R (>= 4.0) with a C compiler.

## Use

    library(survivalROCfast)        # in place of library(survivalROC)
    survivalROC(Stime, status, marker, predict.time = t, method = "KM")
    survivalROC(Stime, status, marker, predict.time = t, method = "NNE", span = s, corrected = TRUE)

## What changes

- KM method: One pass in time order updates the running Kaplan-Meier product of every cut-off.
- NNE method: Each neighbourhood is a contiguous range of marker ranks, so a time-ordered member
  list slides along the marker axis and each product only visits its members.
- Sums and proportions use the same extended-precision arithmetic and order as R's `sum()` and `mean()`.
- Inputs outside the fast path go to an embedded verbatim copy of the original R function.

## Measured (4-core cloud machine, single-threaded, `identical()` TRUE on every row)

| Input | Function | Original | New | Speedup |
|---|---|---|---|---|
| TCGA-LAML, 161 patients x 19,902 genes | survivalROC KM | 514 s | 3.4 s | 150x |
| TCGA-LAML, 161 patients x 19,902 genes | survivalROC NNE | 1,323 s | 6.9 s | 190x |
| TCGA pan-cancer, 12,373 patients, age | survivalROC KM | 24.7 s | 0.003 s | 9,300x |
| TCGA pan-cancer, 12,373 patients, age | survivalROC NNE | 37.9 s | 0.008 s | 5,000x |
| NHANES, 59,064 adults, age | survivalROC NNE | 18.4 s | 0.029 s | 630x |
| NHANES, 49,554 adults, risk score | survivalROC KM | 4,166 s | 0.11 s | 38,000x |
| NHANES, 49,554 adults, risk score | survivalROC.C | 51.7 s | 0.68 s | 76x |
| NHANES, 16,000-adult subsample, risk score | survivalROC NNE | 1,195 s | 0.43 s | 2,800x |
| simulated, n = 5,000 | survivalROC KM | 980 s | 0.009 s | 110,000x |
| simulated, n = 5,000 | survivalROC NNE | 2,499 s | 0.05 s | 50,000x |
| simulated, n = 20,000 | survivalROC.C | 293 s | 0.17 s | 1,800x |

Some original timings ran while other jobs shared the machine. The original's NNE run on the
full 49,554-adult cohort was not completed (projected about 3.1 hours; new code 4.1 s).

Identity tests with the final build: 32,000 random inputs (28,061 identical, 3,939 where both
versions stop with an error, 0 mismatches); 150 large-cohort inputs (3,000 to 60,000 patients),
all identical; all 19,902 AML gene results identical for both methods.

## Defects of the original fixed by `corrected = TRUE`

1. `entry` (left truncation) is not sorted with the other columns, so the result depends on row order.
2. With `lambda`, the Gaussian weights only enter as "weight != 0" (a hard window of about 27 x lambda).
3. `survivalROC()` and `survivalROC.C()` give different curves for the same data and span.
4. Neighbourhood size differs from the published kernel 1{|F(x_i) - F(u)| < span}.

The default mode reproduces all four so that results stay bit-identical to the original.
The corrected mode agrees with a slow reference written from the published formulas to 1e-15.

Licence: GPL (>= 2), as the original, because a verbatim copy of its R function is embedded.
