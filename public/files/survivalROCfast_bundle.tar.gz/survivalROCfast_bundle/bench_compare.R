# Stock vs fast on the same simulated inputs. Usage: Rscript bench_compare.R [largest n for the stock R code]
nmax <- as.integer(c(commandArgs(TRUE), 2000)[1])
sim <- function(n, seed = 1) { set.seed(seed); m <- rnorm(n); t <- rexp(n, exp(m)); c <- rexp(n, 0.5); list(time = pmin(t, c), status = as.numeric(t <= c), marker = m) }
tm <- function(f) { t <- system.time(r <- f())[3]; if (t < 0.3) { k <- max(3, ceiling(0.3 / max(t, 1e-4))); t <- system.time(for (i in seq_len(k)) f())[3] / k }; list(t = t, r = r) }
cat(sprintf("%7s | %-33s | %-33s | %-33s\n", "n", "survivalROC KM   stock / fast", "survivalROC NNE  stock / fast", "survivalROC.C    stock / fast"))
for (n in c(250, 500, 1000, 2000, 5000, 20000)) {
  d <- sim(n); sp <- 0.25 * n^(-0.2); row <- sprintf("%7d", n)
  calls <- list(function(p) p$survivalROC(d$time, d$status, d$marker, predict.time = 1, method = "KM"),
                function(p) p$survivalROC(d$time, d$status, d$marker, predict.time = 1, method = "NNE", span = sp),
                function(p) p$survivalROC.C(d$time, d$status, d$marker, predict.time = 1, span = sp))
  for (i in 1:3) {
    fa <- tm(function() calls[[i]](asNamespace("survivalROCfast")))
    if (n <= nmax || i == 3) { st <- tm(function() calls[[i]](asNamespace("survivalROC")))
      row <- paste0(row, sprintf(" | %8.2fs / %7.4fs %7.0fx %s", st$t, fa$t, st$t / fa$t, if (identical(st$r, fa$r)) "same" else "DIFF"))
    } else row <- paste0(row, sprintf(" | %9s / %7.4fs %13s", "(skipped)", fa$t, ""))
  }
  cat(row, "\n")
}
