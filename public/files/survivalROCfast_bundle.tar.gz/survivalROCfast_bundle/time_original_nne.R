# Colab: Runtime > Change runtime type > R. Paste this whole cell and run it.
# Times the ORIGINAL survivalROC (CRAN 1.0.3.1), NNE method, on the 49,554-adult NHANES cohort.
# Prints exactly one line: the elapsed time in seconds.
suppressWarnings(suppressMessages({
  options(timeout = 3600)
  if (!requireNamespace("survivalROC", quietly = TRUE)) install.packages("survivalROC", repos = "https://cloud.r-project.org", quiet = TRUE)
  library(foreign); library(survival)
  dir.create("nhanes", showWarnings = FALSE)
  get <- function(url, dest) { for (i in 1:5) { if (file.exists(dest) && file.size(dest) > 1000) return(invisible()); try(download.file(url, dest, mode = "wb", quiet = TRUE), silent = TRUE) }; stop("download failed: ", url) }
  yrs <- seq(1999, 2017, 2); suf <- c("", paste0("_", LETTERS[2:10])); all <- list()
  for (i in seq_along(yrs)) {
    for (f in c("DEMO", "BMX", "BPX")) get(sprintf("https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/%d/DataFiles/%s%s.xpt", yrs[i], f, suf[i]), sprintf("nhanes/%s%s.xpt", f, suf[i]))
    mf <- sprintf("NHANES_%d_%d_MORT_2019_PUBLIC.dat", yrs[i], yrs[i] + 1)
    get(paste0("https://ftp.cdc.gov/pub/Health_Statistics/NCHS/datalinkage/linked_mortality/", mf), file.path("nhanes", mf))
    demo <- read.xport(sprintf("nhanes/DEMO%s.xpt", suf[i]))[, c("SEQN", "RIDAGEYR", "RIAGENDR")]
    bmx <- read.xport(sprintf("nhanes/BMX%s.xpt", suf[i]))[, c("SEQN", "BMXBMI")]
    bpx <- read.xport(sprintf("nhanes/BPX%s.xpt", suf[i]))[, c("SEQN", "BPXSY1")]
    L <- readLines(file.path("nhanes", mf)); num <- function(a, b) as.numeric(trimws(substr(L, a, b)))
    mort <- data.frame(SEQN = num(1, 6), eligstat = num(15, 15), mortstat = num(16, 16), permth_exm = num(46, 48), permth_int = num(43, 45))
    all[[i]] <- Reduce(function(a, b) merge(a, b, by = "SEQN", all.x = TRUE), list(demo, bmx, bpx, mort))
  }
  d <- do.call(rbind, all)
  d <- d[d$RIDAGEYR >= 18 & d$eligstat %in% 1 & !is.na(d$mortstat), ]
  d$months <- ifelse(is.na(d$permth_exm), d$permth_int, d$permth_exm); d <- d[!is.na(d$months), ]
  cc <- d[complete.cases(d[, c("BMXBMI", "BPXSY1")]), ]
  fit <- coxph(Surv(months, mortstat) ~ RIDAGEYR + factor(RIAGENDR) + BMXBMI + I(BMXBMI^2) + BPXSY1, data = cc)
  cc$score <- as.numeric(predict(fit, type = "lp"))
  stopifnot(nrow(cc) == 49554, sum(cc$mortstat) == 6822)
  n <- nrow(cc)
  elapsed <- system.time(
    roc <- survivalROC::survivalROC(Stime = cc$months, status = cc$mortstat, marker = cc$score,
                                    predict.time = 120, method = "NNE", span = 0.25 * n^(-0.2))
  )[["elapsed"]]
  saveRDS(list(roc = roc, seconds = elapsed), "nhanes_original_NNE.rds")   # written to disk, not printed
}))
cat(sprintf("%.1f\n", elapsed))
