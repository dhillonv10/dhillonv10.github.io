#!/usr/bin/env bash
# Download the public data used in the benchmarks (TCGA via UCSC Xena, NHANES via CDC).
set -euo pipefail
cd "$(dirname "$0")"; mkdir -p data/nhanes
X=https://tcga-xena-hub.s3.us-east-1.amazonaws.com/download
P=https://tcga-pancan-atlas-hub.s3.us-east-1.amazonaws.com/download
[ -s data/LAML_survival.txt ] || curl -sS -o data/LAML_survival.txt "$X/survival%2FLAML_survival.txt"
[ -s data/LAML_HiSeqV2.gz ] || curl -sS -o data/LAML_HiSeqV2.gz "$X/TCGA.LAML.sampleMap%2FHiSeqV2.gz"
[ -s data/pancan_survival.tsv ] || curl -sS -o data/pancan_survival.tsv "$P/Survival_SupplementalTable_S1_20171025_xena_sp"
yrs=(1999 2001 2003 2005 2007 2009 2011 2013 2015 2017); suf=("" _B _C _D _E _F _G _H _I _J)
for i in "${!yrs[@]}"; do y=${yrs[$i]}; s=${suf[$i]}
  for f in DEMO BMX BPX; do [ -s data/nhanes/${f}${s}.xpt ] || curl -sS -o data/nhanes/${f}${s}.xpt "https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/$y/DataFiles/${f}${s}.xpt"; done
  m=NHANES_${y}_$((y+1))_MORT_2019_PUBLIC.dat
  [ -s data/nhanes/$m ] || curl -sS -o data/nhanes/$m "https://ftp.cdc.gov/pub/Health_Statistics/NCHS/datalinkage/linked_mortality/$m"
done
echo "data ready in $(pwd)/data"
