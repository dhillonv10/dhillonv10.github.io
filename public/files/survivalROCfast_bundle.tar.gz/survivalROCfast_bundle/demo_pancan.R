# Large cohort: TCGA Pan-Cancer Atlas, age at diagnosis as a marker of 5-year overall survival.
suppressPackageStartupMessages(library(data.table))
d <- fread("data/pancan_survival.tsv"); d <- d[!is.na(OS) & !is.na(OS.time) & !is.na(age_at_initial_pathologic_diagnosis) & OS.time > 0]
n <- nrow(d); span <- 0.25 * n^(-0.2); cat(sprintf("%d patients, %d deaths, %d distinct ages\n", n, sum(d$OS), length(unique(d$age_at_initial_pathologic_diagnosis))))
tm <- function(f) { t <- system.time(r <- f())[3]; list(t = t, r = r) }
x <- d$age_at_initial_pathologic_diagnosis + 0
set.seed(1); xj <- x + runif(n, -0.5, 0.5)      # continuous version: age with sub-year jitter (no ties)
for (lab in c("age in whole years", "continuous marker (jittered age)")) {
  mk <- if (lab == "age in whole years") x else xj
  fk <- tm(function() survivalROCfast::survivalROC(d$OS.time, d$OS, mk, predict.time = 1825, method = "KM"))
  fn <- tm(function() survivalROCfast::survivalROC(d$OS.time, d$OS, mk, predict.time = 1825, method = "NNE", span = span))
  fc <- tm(function() survivalROCfast::survivalROC.C(d$OS.time, d$OS, mk, predict.time = 1825, span = span))
  sc <- tm(function() survivalROC::survivalROC.C(d$OS.time, d$OS, mk, predict.time = 1825, span = span))
  cat(sprintf("%s: fast KM %.3f s (AUC %.4f) | fast NNE %.3f s (AUC %.4f) | C routine: stock %.2f s, fast %.3f s, speedup %.0fx, identical %s\n",
              lab, fk$t, fk$r$AUC, fn$t, fn$r$AUC, sc$t, fc$t, sc$t / fc$t, identical(sc$r, fc$r)))
  if (lab == "age in whole years") {
    sk <- tm(function() survivalROC::survivalROC(d$OS.time, d$OS, mk, predict.time = 1825, method = "KM"))
    sn <- tm(function() survivalROC::survivalROC(d$OS.time, d$OS, mk, predict.time = 1825, method = "NNE", span = span))
    cat(sprintf("   stock R on whole-year ages (only %d cut-offs): KM %.1f s -> %.0fx, identical %s | NNE %.1f s -> %.0fx, identical %s\n", length(unique(mk)), sk$t, sk$t / fk$t, identical(sk$r, fk$r), sn$t, sn$t / fn$t, identical(sn$r, fn$r)))
  }
}
