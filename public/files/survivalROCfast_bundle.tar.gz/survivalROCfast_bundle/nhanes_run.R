# 10-year all-cause mortality ROC in NHANES. Usage: Rscript nhanes_run.R <stock|fast> <KM|NNE|C>
a <- commandArgs(TRUE); ns <- asNamespace(if (a[1] == "stock") "survivalROC" else "survivalROCfast")
d <- readRDS("data/nhanes_cc.rds"); n <- nrow(d); span <- 0.25 * n^(-0.2)
t <- system.time(r <- switch(a[2],
  KM = ns$survivalROC(d$months, d$mortstat, d$score, predict.time = 120, method = "KM"),
  NNE = ns$survivalROC(d$months, d$mortstat, d$score, predict.time = 120, method = "NNE", span = span),
  C = ns$survivalROC.C(d$months, d$mortstat, d$score, predict.time = 120, span = span)))[3]
saveRDS(list(r = r, seconds = unname(t)), sprintf("nhanes_%s_%s.rds", a[1], a[2]))
cat(sprintf("NHANES n=%d %s %s: %.3f s AUC %.6f\n", n, a[1], a[2], t, r$AUC))
