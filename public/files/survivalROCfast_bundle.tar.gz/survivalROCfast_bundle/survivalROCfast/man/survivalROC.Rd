\name{survivalROC}
\alias{survivalROC}
\alias{survivalROC.C}
\title{Fast exact time-dependent ROC curves}
\description{Drop-in replacements for \code{survivalROC::survivalROC} and
\code{survivalROC::survivalROC.C}. With \code{corrected = FALSE} (the default) results are
bit-identical to survivalROC 1.0.3.1. With \code{corrected = TRUE} four defects of the original
are fixed (see Details).}
\usage{
survivalROC(Stime, status, marker, entry = NULL, predict.time, cut.values = NULL,
            method = "NNE", lambda = NULL, span = NULL, window = "symmetric",
            corrected = FALSE)
survivalROC.C(Stime, status, marker, predict.time, span = 0.05, corrected = FALSE)
}
\arguments{
\item{Stime, status, marker, entry, predict.time, cut.values, method, lambda, span, window}{As in the survivalROC package.}
\item{corrected}{If \code{TRUE}: entry times are sorted with the data; the NNE span kernel is
the published one, \eqn{1\{|F(x_i) - F(u)| < span\}} on the empirical distribution function of
the marker; \code{lambda} weights are used as weights in a weighted Kaplan-Meier estimate; and
both functions return the same NNE curve.}
}
\value{The same list as the survivalROC package: cut.values, TP, FP, predict.time, Survival, AUC.}
\references{Heagerty PJ, Lumley T, Pepe MS (2000). Time-dependent ROC curves for censored
survival data and a diagnostic marker. Biometrics 56:337-344.}
