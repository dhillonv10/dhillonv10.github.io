/* survivalROCfast: exact, fast kernels for the estimators in the survivalROC package.
 *
 * Every kernel reproduces the arithmetic of the original code operation for operation
 * (same operands, same order), so results are bit-identical; only the bookkeeping that
 * finds those operands is different.
 */
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ---- Kaplan-Meier product over a member list ------------------------------------------
 * win[0..W-1]: indices (into the time-sorted data) of the members, ascending.
 * tg[i]: id of the distinct time value of observation i (non-decreasing in i).
 * ev[i]: 1 if status == 1.  m_pre: number of observations with time <= predict.time.
 * Returns prod over distinct member times t <= predict.time with d > 0 of (1 - d/n),
 * n = #members with entry <= t and time >= t, d = #members with entry <= t, time == t, event.
 * Time points with d == 0 contribute a factor of exactly 1 in the original and are skipped.
 */
static double km_members(const int *win, int W, const int *tg, const int *ev, int m_pre,
                         int use_entry, const double *times, const double *entry)
{
    double s = 1.0;
    int p = 0;
    while (p < W && win[p] < m_pre) {
        int g = tg[win[p]], q = p, d = 0;
        if (!use_entry) {
            while (q < W && tg[win[q]] == g) { d += ev[win[q]]; q++; }
            if (d > 0) s = s * (1.0 - (double) d / (double) (W - p));
        } else {
            double tv = times[win[p]];
            while (q < W && tg[win[q]] == g) { if (ev[win[q]] && entry[win[q]] <= tv) d++; q++; }
            if (d > 0) {
                int n = 0;
                for (int r = p; r < W; r++) if (entry[win[r]] <= tv) n++;
                if (n > 0) s = s * (1.0 - (double) d / (double) n);
            }
        }
        p = q;
    }
    return s;
}

static int cmp_int(const void *a, const void *b) { int x = *(const int *) a, y = *(const int *) b; return (x > y) - (x < y); }

static int lower_pos(const int *a, int n, int v) { int lo = 0, hi = n; while (lo < hi) { int mid = (lo + hi) >> 1; if (a[mid] < v) lo = mid + 1; else hi = mid; } return lo; }

/* sorted int set with insert / remove by memmove */
typedef struct { int *a; int n; } iset;
static void iset_insert(iset *s, int v) { int p = lower_pos(s->a, s->n, v); memmove(s->a + p + 1, s->a + p, (size_t) (s->n - p) * sizeof(int)); s->a[p] = v; s->n++; }
static void iset_remove(iset *s, int v) { int p = lower_pos(s->a, s->n, v); memmove(s->a + p, s->a + p + 1, (size_t) (s->n - p - 1) * sizeof(int)); s->n--; }

/* Move the member set from x-rank range [cl, cr] to [L, R]; tix maps x-rank -> time index. */
static void window_move(iset *s, const int *tix, int *cl, int *cr, int L, int R)
{
    int W = R - L + 1;
    int rebuild = (*cr < *cl || L > *cr || R < *cl);            /* empty or disjoint */
    if (!rebuild) rebuild = (labs((long) L - *cl) + labs((long) R - *cr)) > (long) W / 6 + 8;
    if (rebuild) {
        memcpy(s->a, tix + L, (size_t) W * sizeof(int));
        s->n = W;
        qsort(s->a, (size_t) W, sizeof(int), cmp_int);
    } else {
        for (int q = *cl; q < L; q++) iset_remove(s, tix[q]);
        for (int q = R + 1; q <= *cr; q++) iset_remove(s, tix[q]);
        for (int q = L; q < *cl; q++) iset_insert(s, tix[q]);
        for (int q = *cr + 1; q <= R; q++) iset_insert(s, tix[q]);
    }
    *cl = L; *cr = R;
}

/* ---- survivalROC(method = "NNE") --------------------------------------------------------
 * mode 1: span, symmetric window; mode 2: span, asymmetric window; mode 3: lambda.
 * xs: marker sorted ascending; tix[q]: time index of the observation at x-rank q;
 * xu: distinct marker values ascending; K: trunc(n*span + 0.5) (mode 1) or trunc(n*span) (mode 2).
 * Returns the conditional survival estimate S(predict.time | x) for each distinct x.
 */
SEXP C_nne(SEXP s_xs, SEXP s_tix, SEXP s_xu, SEXP s_tg, SEXP s_ev, SEXP s_mpre, SEXP s_mode,
           SEXP s_K, SEXP s_lambda, SEXP s_use_entry, SEXP s_times, SEXP s_entry)
{
    const double *xs = REAL(s_xs), *xu = REAL(s_xu), *times = REAL(s_times), *entry = REAL(s_entry);
    const int *tix = INTEGER(s_tix), *tg = INTEGER(s_tg), *ev = INTEGER(s_ev);
    int n = LENGTH(s_xs), nu = LENGTH(s_xu), m_pre = asInteger(s_mpre), mode = asInteger(s_mode);
    int use_entry = asInteger(s_use_entry);
    double K = asReal(s_K), lam = asReal(s_lambda);
    SEXP out = PROTECT(allocVector(REALSXP, nu));
    double *S = REAL(out);
    iset set; set.a = (int *) R_alloc((size_t) n + 1, sizeof(int)); set.n = 0;
    int cl = 0, cr = -1, less = 0, ecdf_L = 0, ecdf_R = 0;
    int *cpos = NULL;
    if (mode == 4 || mode == 5) {
        cpos = (int *) R_alloc((size_t) n + 1, sizeof(int));
        for (int q = n - 1; q >= 0; q--) cpos[q] = (q < n - 1 && xs[q + 1] == xs[q]) ? cpos[q + 1] : q + 1;
    }

    for (int j = 0; j < nu; j++) {
        double u = xu[j], l;
        while (less < n && xs[less] < u) less++;          /* number of x strictly below u */
        int L, R, lo, hi;
        if (mode == 4 || mode == 5) {
            /* corrected kernel (as published): member iff |F(x_i) - F(u)| < span, F the
               empirical distribution function; mode 5 keeps only 0 <= F(x_i) - F(u) < span.
               cpos[q] = #{x <= xs[q]}; K carries span * n. */
            int leq = less; while (leq < n && xs[leq] <= u) leq++;
            double cu = (double) leq;
            if (mode == 4) { while (ecdf_L < less && !(cu - (double) cpos[ecdf_L] < K)) ecdf_L++; L = ecdf_L; }
            else L = less;
            if (ecdf_R < leq - 1) ecdf_R = leq - 1;
            while (ecdf_R + 1 < n && ((double) cpos[ecdf_R + 1] - cu < K)) ecdf_R++;
            R = ecdf_R;
        } else if (mode == 3) {
            /* weights exp(-(x-u)^2/lambda^2) enter the original only through "weight != 0" */
            lo = 0; hi = less;                            /* first q with nonzero weight */
            while (lo < hi) { int mid = (lo + hi) >> 1; double dd = xs[mid] - u;
                if (exp(-(dd * dd) / (lam * lam)) != 0.0) hi = mid; else lo = mid + 1; }
            L = lo;
            lo = less; hi = n - 1;                        /* last q with nonzero weight */
            while (lo < hi) { int mid = (lo + hi + 1) >> 1; double dd = xs[mid] - u;
                if (exp(-(dd * dd) / (lam * lam)) != 0.0) lo = mid; else hi = mid - 1; }
            R = lo;
        } else {
            double idx = (double) (less + 1) + K;          /* 1-based index into sorted differences */
            if (idx > (double) n) idx = (double) n;
            int i1 = (int) idx - 1;
            l = xs[i1] - u;
            lo = i1; hi = n - 1;                          /* last q with (x - u) <= l */
            while (lo < hi) { int mid = (lo + hi + 1) >> 1; if (xs[mid] - u <= l) lo = mid; else hi = mid - 1; }
            R = lo;
            if (mode == 1) {
                lo = 0; hi = less;                        /* first q with (x - u) >= -l */
                while (lo < hi) { int mid = (lo + hi) >> 1; if (xs[mid] - u >= -l) hi = mid; else lo = mid + 1; }
                L = lo;
            } else L = less;
        }
        window_move(&set, tix, &cl, &cr, L, R);
        S[j] = km_members(set.a, set.n, tg, ev, m_pre, use_entry, times, entry);
        if ((j & 1023) == 0) R_CheckUserInterrupt();
    }
    UNPROTECT(1);
    return out;
}

/* ---- corrected lambda method: Gaussian kernel weights used as weights -------------------
 * x, tg, ev, times, entry in time order.  S(t | u) = prod (1 - d_w / n_w) with
 * n_w = sum of weights at risk, d_w = sum of weights of events at that time.
 */
SEXP C_nne_gauss(SEXP s_x, SEXP s_xu, SEXP s_tg, SEXP s_ev, SEXP s_mpre, SEXP s_lambda,
                 SEXP s_use_entry, SEXP s_times, SEXP s_entry)
{
    const double *x = REAL(s_x), *xu = REAL(s_xu), *times = REAL(s_times), *entry = REAL(s_entry);
    const int *tg = INTEGER(s_tg), *ev = INTEGER(s_ev);
    int n = LENGTH(s_x), nu = LENGTH(s_xu), m_pre = asInteger(s_mpre), use_entry = asInteger(s_use_entry);
    double lam = asReal(s_lambda), l2 = lam * lam;
    SEXP out = PROTECT(allocVector(REALSXP, nu));
    double *w = (double *) R_alloc((size_t) n + 1, sizeof(double));
    double *suf = (double *) R_alloc((size_t) n + 2, sizeof(double));
    for (int j = 0; j < nu; j++) {
        double u = xu[j], s = 1.0;
        for (int i = 0; i < n; i++) { double dd = x[i] - u; w[i] = exp(-(dd * dd) / l2); }
        if (!use_entry) { suf[n] = 0.0; for (int i = n - 1; i >= 0; i--) suf[i] = suf[i + 1] + w[i]; }
        int p = 0;
        while (p < m_pre) {
            int g = tg[p], q = p; double d = 0.0, tv = times[p];
            while (q < n && tg[q] == g) { if (ev[q] && (!use_entry || entry[q] <= tv)) d += w[q]; q++; }
            if (d > 0.0) {
                double nn;
                if (!use_entry) nn = suf[p];
                else { nn = 0.0; for (int r = p; r < n; r++) if (entry[r] <= tv) nn += w[r]; }
                if (nn > 0.0) s = s * (1.0 - d / nn);
            }
            p = q;
        }
        REAL(out)[j] = s;
        if ((j & 255) == 0) R_CheckUserInterrupt();
    }
    UNPROTECT(1);
    return out;
}

/* ---- sum(v[x > cut_c]) for every cut, with R's long double accumulation order ------------
 * k[i]: number of cuts (among the nc used) strictly below x_i, so observation i belongs
 * to cuts 0 .. k[i]-1.  Observations are visited in data order, as sum() visits them.
 */
SEXP C_cut_sums(SEXP s_v, SEXP s_k, SEXP s_nc, SEXP s_ld)
{
    const double *v = REAL(s_v); const int *k = INTEGER(s_k);
    int n = LENGTH(s_v), nc = asInteger(s_nc), use_ld = asInteger(s_ld);
    SEXP out = PROTECT(allocVector(REALSXP, nc));
    if (use_ld) {                       /* R built with long double: sum() accumulates in it */
        long double *acc = (long double *) R_alloc((size_t) nc + 1, sizeof(long double));
        for (int c = 0; c < nc; c++) acc[c] = 0.0;
        for (int i = 0; i < n; i++) {
            long double vi = v[i]; int ki = k[i];
            for (int c = 0; c < ki; c++) acc[c] += vi;
            if ((i & 4095) == 0) R_CheckUserInterrupt();
        }
        for (int c = 0; c < nc; c++) REAL(out)[c] = (double) acc[c];
    } else {
        double *acc = REAL(out);
        for (int c = 0; c < nc; c++) acc[c] = 0.0;
        for (int i = 0; i < n; i++) {
            double vi = v[i]; int ki = k[i];
            for (int c = 0; c < ki; c++) acc[c] += vi;
            if ((i & 4095) == 0) R_CheckUserInterrupt();
        }
    }
    UNPROTECT(1);
    return out;
}

/* ---- survivalROC(method = "KM"): KM estimate among {x > cut_c} for every cut -------------
 * Data in time order; k[i] as above; cnt[c] = #{i : x_i > cut_c}.
 */
SEXP C_km_cuts(SEXP s_k, SEXP s_cnt, SEXP s_tg, SEXP s_ev, SEXP s_mpre, SEXP s_use_entry,
               SEXP s_times, SEXP s_entry)
{
    const int *k = INTEGER(s_k), *cnt = INTEGER(s_cnt), *tg = INTEGER(s_tg), *ev = INTEGER(s_ev);
    const double *times = REAL(s_times), *entry = REAL(s_entry);
    int n = LENGTH(s_k), nc = LENGTH(s_cnt), m_pre = asInteger(s_mpre), use_entry = asInteger(s_use_entry);
    SEXP out = PROTECT(allocVector(REALSXP, nc));
    double *s = REAL(out);
    for (int c = 0; c < nc; c++) s[c] = 1.0;

    if (!use_entry) {
        int *before = (int *) R_alloc((size_t) nc + 1, sizeof(int));   /* members already passed */
        int *d = (int *) R_alloc((size_t) nc + 1, sizeof(int));
        memset(before, 0, (size_t) (nc + 1) * sizeof(int));
        memset(d, 0, (size_t) (nc + 1) * sizeof(int));
        int p = 0;
        while (p < m_pre) {
            int g = tg[p], q = p, kmax = 0, nev = 0, kev = 0;
            while (q < n && tg[q] == g) { if (ev[q]) { nev++; kev = k[q]; if (k[q] > kmax) kmax = k[q]; } q++; }
            if (nev == 1) {
                for (int c = 0; c < kev; c++) s[c] = s[c] * (1.0 - 1.0 / (double) (cnt[c] - before[c]));
            } else if (nev > 1) {
                for (int r = p; r < q; r++) if (ev[r]) { int kr = k[r]; for (int c = 0; c < kr; c++) d[c]++; }
                for (int c = 0; c < kmax; c++) { s[c] = s[c] * (1.0 - (double) d[c] / (double) (cnt[c] - before[c])); d[c] = 0; }
            }
            for (int r = p; r < q; r++) { int kr = k[r]; for (int c = 0; c < kr; c++) before[c]++; }
            p = q;
            if ((p & 1023) == 0) R_CheckUserInterrupt();
        }
    } else {
        int *win = (int *) R_alloc((size_t) n + 1, sizeof(int));
        for (int c = 0; c < nc; c++) {
            int W = 0;
            for (int i = 0; i < n; i++) if (k[i] > c) win[W++] = i;
            s[c] = km_members(win, W, tg, ev, m_pre, 1, times, entry);
            if ((c & 255) == 0) R_CheckUserInterrupt();
        }
    }
    UNPROTECT(1);
    return out;
}

/* ---- mean() of a logical vector with cnt TRUE values out of n ----------------------------
 * R computes it as (double)((long double) cnt / n): the quotient is formed in extended
 * precision and then rounded, which is not always the same double as cnt / n.
 */
SEXP C_mean_count(SEXP s_cnt, SEXP s_n, SEXP s_ld)
{
    int m = LENGTH(s_cnt), use_ld = asInteger(s_ld);
    double n = asReal(s_n);
    const int *cnt = INTEGER(s_cnt);
    SEXP out = PROTECT(allocVector(REALSXP, m));
    for (int i = 0; i < m; i++) {
        if (use_ld) { long double sv = (long double) cnt[i]; REAL(out)[i] = (double) (sv / (long double) n); }
        else REAL(out)[i] = (double) cnt[i] / n;
    }
    UNPROTECT(1);
    return out;
}

/* ---- pooled KM estimate over all observations ------------------------------------------- */
SEXP C_km_all(SEXP s_tg, SEXP s_ev, SEXP s_mpre, SEXP s_use_entry, SEXP s_times, SEXP s_entry)
{
    int n = LENGTH(s_tg);
    int *win = (int *) R_alloc((size_t) n + 1, sizeof(int));
    for (int i = 0; i < n; i++) win[i] = i;
    return ScalarReal(km_members(win, n, INTEGER(s_tg), INTEGER(s_ev), asInteger(s_mpre),
                                 asInteger(s_use_entry), REAL(s_times), REAL(s_entry)));
}

/* ---- survivalROC.C(): the package's compiled NNE routine ---------------------------------
 * Data sorted by marker.  torder[r]: x-rank of the observation with time rank r is not
 * needed; instead tix[q] gives, for x-rank q, the index of that observation in time order.
 */
SEXP C_nne_c(SEXP s_x, SEXP s_xu, SEXP s_tix, SEXP s_tg, SEXP s_ev, SEXP s_mpre, SEXP s_span)
{
    const double *X = REAL(s_x), *U = REAL(s_xu);
    const int *tix = INTEGER(s_tix), *tg = INTEGER(s_tg), *ev = INTEGER(s_ev);
    int n = LENGTH(s_x), q = LENGTH(s_xu), m_pre = asInteger(s_mpre);
    double span = asReal(s_span);
    SEXP out = PROTECT(allocVector(VECSXP, 3));
    SEXP s_TP = PROTECT(allocVector(REALSXP, q)), s_FP = PROTECT(allocVector(REALSXP, q));
    double *TP = REAL(s_TP), *FP = REAL(s_FP);
    double *SgivenX = (double *) R_alloc((size_t) q + 1, sizeof(double));
    double *pX = (double *) R_alloc((size_t) q + 1, sizeof(double));
    double *cdfX = (double *) R_alloc((size_t) q + 1, sizeof(double));
    double *rep = (double *) R_alloc((size_t) n + 2, sizeof(double));   /* 1/n added m times */
    double inc = 1.0 / ((double) (n));
    rep[0] = 0.0;
    for (int m = 1; m <= n; m++) rep[m] = rep[m - 1] + inc;
    int IndexSpan = (int) floor(((double) (n) * span + 0.5));
    iset set; set.a = (int *) R_alloc((size_t) n + 1, sizeof(int)); set.n = 0;
    int cl = 0, cr = -1, less = 0, leq = 0;

    for (int i = 0; i < q; i++) {
        while (less < n && X[less] < U[i]) less++;
        if (leq < less) leq = less;
        while (leq < n && X[leq] <= U[i]) leq++;
        pX[i] = rep[leq - less];
        cdfX[i] = rep[leq];
        int FirstIndex = n - 1, LastIndex = n - 1, TargetIndex, index0, index1;
        if (less >= 1 && less <= n - 1) FirstIndex = less - 1;
        if (leq >= 1 && leq <= n - 1) LastIndex = leq - 1;
        TargetIndex = floor(((double) FirstIndex + (double) LastIndex) / 2.0 + 0.5);
        index0 = TargetIndex - IndexSpan;
        if (index0 < 0) index0 = 0;
        if (index0 > FirstIndex) index0 = FirstIndex;
        index1 = TargetIndex + IndexSpan;
        if (index1 >= n) index1 = (n - 1);
        if (index1 < LastIndex) index1 = LastIndex;
        window_move(&set, tix, &cl, &cr, index0, index1);
        SgivenX[i] = km_members(set.a, set.n, tg, ev, m_pre, 0, NULL, NULL);
        if ((i & 1023) == 0) R_CheckUserInterrupt();
    }

    double alt_St = 0.0, St;
    for (int j = 0; j < q; j++) {
        if (j > 0) pX[j] = cdfX[j] - cdfX[j - 1];
        alt_St += SgivenX[j] * pX[j];
    }
    St = alt_St;

    /* STX[i] = sum_{j>i} SgivenX[j]*pX[j] and p1[i] = sum_{j>i} pX[j], each accumulated in
       increasing j exactly as in the original double loop */
    double *STX = (double *) R_alloc((size_t) q + 1, sizeof(double));
    double *p1 = (double *) R_alloc((size_t) q + 1, sizeof(double));
    for (int i = 0; i < q; i++) { STX[i] = 0.0; p1[i] = 0.0; }
    for (int j = 1; j < q; j++) {
        double term = SgivenX[j] * pX[j], pj = pX[j];
        for (int i = 0; i < j; i++) { STX[i] += term; p1[i] += pj; }
        if ((j & 1023) == 0) R_CheckUserInterrupt();
    }
    for (int i = 0; i < q; i++) { TP[i] = 0.0; FP[i] = 0.0; }
    for (int i = 0; i < (q - 1); i++) { TP[i] = (p1[i] - STX[i]) / (1.0 - St); FP[i] = STX[i] / St; }

    SET_VECTOR_ELT(out, 0, s_TP); SET_VECTOR_ELT(out, 1, s_FP); SET_VECTOR_ELT(out, 2, ScalarReal(St));
    UNPROTECT(3);
    return out;
}

static const R_CallMethodDef callMethods[] = {
    {"C_nne", (DL_FUNC) &C_nne, 12}, {"C_cut_sums", (DL_FUNC) &C_cut_sums, 4},
    {"C_km_cuts", (DL_FUNC) &C_km_cuts, 8}, {"C_km_all", (DL_FUNC) &C_km_all, 6},
    {"C_nne_c", (DL_FUNC) &C_nne_c, 7}, {"C_nne_gauss", (DL_FUNC) &C_nne_gauss, 9}, {"C_mean_count", (DL_FUNC) &C_mean_count, 3}, {NULL, NULL, 0}
};
void R_init_survivalROCfast(DllInfo *dll) { R_registerRoutines(dll, NULL, callMethods, NULL, NULL); R_useDynamicSymbols(dll, FALSE); }
