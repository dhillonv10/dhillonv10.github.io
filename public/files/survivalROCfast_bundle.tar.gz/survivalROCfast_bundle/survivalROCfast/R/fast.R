## Drop-in replacements for survivalROC::survivalROC and survivalROC::survivalROC.C.
## Pre- and post-processing lines are kept as in the original so that every value handed to
## and taken from the kernels is formed by the same operations.

.counts <- new.env(parent = emptyenv()); .counts$fast <- 0L   # calls served by the fast path

.tie_groups <- function(times_sorted) {
    n <- length(times_sorted)
    if (n == 0L) return(integer(0))
    cumsum(c(TRUE, times_sorted[-1L] != times_sorted[-n]))
}

survivalROC <- function(Stime, status, marker, entry = NULL, predict.time, cut.values = NULL,
                        method = "NNE", lambda = NULL, span = NULL, window = "symmetric",
                        corrected = FALSE) {
    if (isTRUE(corrected))
        return(.survivalROC_corrected(Stime, status, marker, entry, predict.time, cut.values,
                                      method, lambda, span, window))
    args0 <- list(Stime = Stime, status = status, marker = marker, entry = entry, predict.time = predict.time,
                  cut.values = cut.values, method = method, lambda = lambda, span = span, window = window)
    orig <- function() do.call(.survivalROC_orig, args0)
    ## inputs outside the plain numeric case are left to the reference implementation
    ok <- is.numeric(Stime) && is.numeric(marker) && (is.numeric(status) || is.logical(status)) &&
        is.null(dim(Stime)) && is.null(dim(marker)) && is.null(dim(status)) &&
        length(Stime) == length(marker) && length(Stime) == length(status) &&
        (is.null(entry) || (is.numeric(entry) && length(entry) == length(Stime))) &&
        is.numeric(predict.time) && length(predict.time) == 1L && is.finite(predict.time) &&
        is.character(method) && length(method) == 1L && method %in% c("KM", "NNE") &&
        (is.null(cut.values) || (is.numeric(cut.values) && !anyNA(cut.values)))
    if (!ok) return(orig())

    times = Stime
    x <- marker
    has_entry <- !is.null(entry)
    if (is.null(entry))
        entry <- rep(0, length(times))
    bad <- is.na(times) | is.na(status) | is.na(x) | is.na(entry)
    entry <- entry[!bad]
    times <- times[!bad]
    status <- status[!bad]
    x <- x[!bad]
    n_obs <- length(times)
    if (n_obs < 2L || any(!is.finite(times)) || any(!is.finite(x)) || any(!is.finite(entry)) ||
        n_obs > .Machine$integer.max / 4) return(orig())
    if (is.null(cut.values))
        cut.values <- unique(x)
    cut.values <- cut.values[order(cut.values)]
    ncuts <- length(cut.values)
    ooo <- order(times)
    times <- times[ooo]
    status <- status[ooo]
    x <- x[ooo]
    ## note: as in the original, 'entry' is not reordered here

    m_pre <- sum(times <= predict.time)
    n_ev_pre <- sum(times <= predict.time & status == 1)
    if (ncuts < 2L || m_pre < 1L) return(orig())
    if (method == "NNE") {
        if (is.null(lambda) & is.null(span)) return(orig())
        if (n_ev_pre < 1L) return(orig())
        if (!is.null(span)) {
            if (!(is.numeric(span) && length(span) == 1L && is.finite(span) && span >= 0 &&
                  is.character(window) && length(window) == 1L && window %in% c("symmetric", "asymmetric")))
                return(orig())
        } else if (!(is.numeric(lambda) && length(lambda) == 1L && is.finite(lambda) && lambda != 0 &&
                     is.finite(lambda^2) && lambda^2 > 0)) return(orig())
    }

    ## all fall-backs are decided; from here the fast path produces the result
    .counts$fast <- .counts$fast + 1L
    if (sum(bad) > 0)
        cat(paste("\n", sum(bad), "records with missing values dropped. \n"))

    tg <- .tie_groups(times)
    ev <- as.integer(status == 1)
    use_entry <- has_entry && (max(entry) > times[1L])
    dtimes <- as.double(times); dentry <- as.double(entry)

    s.pooled <- .Call(C_km_all, tg, ev, m_pre, use_entry, dtimes, dentry)

    roc.matrix <- matrix(NA, ncuts, 2)
    roc.matrix[ncuts, 1] <- 0
    roc.matrix[ncuts, 2] <- 1
    cc <- seq_len(ncuts - 1L)
    ## k[i]: number of the first ncuts-1 cut values strictly below x[i]
    k <- findInterval(x, cut.values[cc], left.open = TRUE)
    cnt <- (n_obs - cumsum(tabulate(k + 1L, nbins = ncuts)))[cc]      # #{x > cut.values[c]}

    if (method == "KM") {
        s0 <- .Call(C_km_cuts, k, cnt, tg, ev, m_pre, use_entry, dtimes, dentry)
        ## mean(x > cut) as R computes it for a logical vector (see C_mean_count)
        p0 <- .Call(C_mean_count, as.integer(cnt), as.double(n_obs), isTRUE(capabilities("long.double")))
        roc.matrix[cc, 1] <- (1 - s0) * p0/(1 - s.pooled)
        roc.matrix[cc, 2] <- 1 - s0 * p0/s.pooled
    }
    if (method == "NNE") {
        x.unique <- unique(x)
        x.unique <- x.unique[order(x.unique)]
        ox <- order(x)
        if (!is.null(span)) {
            if (window == "symmetric") { mode <- 1L; K <- trunc(n_obs * span + 0.5) }
            else { mode <- 2L; K <- trunc(n_obs * span) }
            lam <- 0
        } else { mode <- 3L; K <- 0; lam <- as.double(lambda) }
        S.t.x <- .Call(C_nne, as.double(x[ox]), ox - 1L, as.double(x.unique), tg, ev, m_pre, mode,
                       as.double(K), lam, use_entry, dtimes, dentry)
        S.all.x <- S.t.x[match(x, x.unique)]
        n <- length(times)
        S.marginal <- sum(S.all.x)/n
        p1 <- cnt/n
        Sx <- .Call(C_cut_sums, S.all.x, k, ncuts - 1L, isTRUE(capabilities("long.double")))/n
        roc.matrix[cc, 1] <- (p1 - Sx)/(1 - S.marginal)
        roc.matrix[cc, 2] <- 1 - Sx/S.marginal
    }
    sensitivity = roc.matrix[, 1]
    specificity = roc.matrix[, 2]
    x <- 1 - c(0, specificity)
    y <- c(1, sensitivity)
    n <- length(x)
    dx <- x[-n] - x[-1]
    mid.y <- (y[-n] + y[-1])/2
    area <- sum(dx * mid.y)
    list(cut.values = c(-Inf, cut.values), TP = y, FP = x, predict.time = predict.time,
         Survival = s.pooled, AUC = area)
}

## Corrected estimators.  Differences from the original, all opt-in via corrected = TRUE:
##  1. 'entry' is sorted together with the other columns (the original leaves it unsorted).
##  2. NNE with 'span' uses the published kernel 1{ |F(x_i) - F(u)| < span } on the empirical
##     distribution function F of the marker ("asymmetric": 0 <= F(x_i) - F(u) < span).
##  3. NNE with 'lambda' uses exp(-(x_i - u)^2 / lambda^2) as weights in a weighted
##     Kaplan-Meier estimate (the original only tests whether the weight is non-zero).
##  4. survivalROC.C(corrected = TRUE) returns the same curve as survivalROC(method = "NNE").
.survivalROC_corrected <- function(Stime, status, marker, entry, predict.time, cut.values,
                                   method, lambda, span, window, marginal_survival = FALSE) {
    stopifnot(is.numeric(Stime), is.numeric(marker), is.numeric(status) || is.logical(status),
              length(Stime) == length(marker), length(Stime) == length(status),
              is.numeric(predict.time), length(predict.time) == 1L, is.finite(predict.time),
              is.character(method), length(method) == 1L, method %in% c("KM", "NNE"))
    times <- Stime; x <- marker
    has_entry <- !is.null(entry)
    if (!has_entry) entry <- rep(0, length(times))
    stopifnot(is.numeric(entry), length(entry) == length(times))
    bad <- is.na(times) | is.na(status) | is.na(x) | is.na(entry)
    if (sum(bad) > 0) cat(paste("\n", sum(bad), "records with missing values dropped. \n"))
    entry <- entry[!bad]; times <- times[!bad]; status <- status[!bad]; x <- x[!bad]
    n <- length(times)
    if (n < 2L || any(!is.finite(times)) || any(!is.finite(x)) || any(!is.finite(entry)))
        stop("need at least two complete records with finite time, marker and entry")
    if (is.null(cut.values)) cut.values <- unique(x)
    stopifnot(is.numeric(cut.values), !anyNA(cut.values))
    cut.values <- sort(cut.values); ncuts <- length(cut.values)
    ooo <- order(times)
    times <- times[ooo]; status <- status[ooo]; x <- x[ooo]; entry <- entry[ooo]
    m_pre <- sum(times <= predict.time)
    tg <- .tie_groups(times); ev <- as.integer(status == 1)
    if (sum(ev[seq_len(m_pre)]) < 1L) stop("no events at or before predict.time")
    use_entry <- has_entry && (max(entry) > times[1L])
    dtimes <- as.double(times); dentry <- as.double(entry)
    s.pooled <- .Call(C_km_all, tg, ev, m_pre, use_entry, dtimes, dentry)
    k <- findInterval(x, cut.values, left.open = TRUE)                 # cuts strictly below x
    cnt <- n - cumsum(tabulate(k + 1L, nbins = ncuts + 1L))[seq_len(ncuts)]   # #{x > cut}
    if (method == "KM") {
        s0 <- .Call(C_km_cuts, k, cnt, tg, ev, m_pre, use_entry, dtimes, dentry)
        p0 <- .Call(C_mean_count, as.integer(cnt), as.double(n), isTRUE(capabilities("long.double")))
        sens <- (1 - s0) * p0 / (1 - s.pooled); spec <- 1 - s0 * p0 / s.pooled
        surv <- s.pooled
    } else {
        if (is.null(lambda) && is.null(span)) stop("method = NNE requires either lambda or span")
        x.unique <- sort(unique(x)); ox <- order(x)
        if (!is.null(span)) {
            stopifnot(is.numeric(span), length(span) == 1L, is.finite(span), span > 0,
                      window %in% c("symmetric", "asymmetric"))
            S.t.x <- .Call(C_nne, as.double(x[ox]), ox - 1L, as.double(x.unique), tg, ev, m_pre,
                           if (window == "symmetric") 4L else 5L, as.double(span * n), 0, use_entry, dtimes, dentry)
        } else {
            stopifnot(is.numeric(lambda), length(lambda) == 1L, is.finite(lambda), lambda > 0)
            S.t.x <- .Call(C_nne_gauss, as.double(x), as.double(x.unique), tg, ev, m_pre,
                           as.double(lambda), use_entry, dtimes, dentry)
        }
        S.all.x <- S.t.x[match(x, x.unique)]
        S.marginal <- sum(S.all.x) / n
        Sx <- .Call(C_cut_sums, S.all.x, k, ncuts, isTRUE(capabilities("long.double"))) / n
        sens <- (cnt / n - Sx) / (1 - S.marginal); spec <- 1 - Sx / S.marginal
        surv <- if (marginal_survival) S.marginal else s.pooled
    }
    ## the largest cut-off always has sensitivity 0 and specificity 1, as in the original
    sens[ncuts] <- 0; spec[ncuts] <- 1
    FP <- 1 - c(0, spec); TP <- c(1, sens); m <- length(FP)
    list(cut.values = c(-Inf, cut.values), TP = TP, FP = FP, predict.time = predict.time,
         Survival = surv, AUC = sum((FP[-m] - FP[-1]) * (TP[-m] + TP[-1]) / 2))
}

survivalROC.C <- function(Stime, status, marker, predict.time, span = 0.05, corrected = FALSE) {
    if (isTRUE(corrected))
        return(.survivalROC_corrected(Stime, status, marker, NULL, predict.time, NULL, "NNE", NULL,
                                      span, "symmetric", marginal_survival = TRUE))
    PredictTime = predict.time
    x <- marker
    drop <- is.na(Stime) | is.na(status) | is.na(x)
    if (sum(drop) > 0) {
        ndrop <- sum(drop)
        cat(paste("\n cases dropped due to missing values:", ndrop, "\n\n"))
        Stime <- Stime[!drop]
        status <- status[!drop]
        x <- x[!drop]
    }
    unique.Stimes <- unique(Stime[status == 1])
    unique.Stimes <- unique.Stimes[order(unique.Stimes)]
    unique.x <- unique(x)
    unique.x <- unique.x[order(unique.x)]
    ooo <- order(x)
    Stime <- Stime[ooo]
    status <- status[ooo]
    x <- x[ooo]
    n <- length(x)
    q <- length(unique.x)
    ## time order of the marker-sorted data
    ot <- order(Stime)
    tix <- integer(n); tix[ot] <- seq_len(n) - 1L
    ts <- as.double(Stime)[ot]
    z <- .Call(C_nne_c, as.double(x), as.double(unique.x), tix, .tie_groups(ts),
               as.integer(as.double(status)[ot] == 1), sum(ts <= as.double(PredictTime)), as.double(span))
    area <- function(x, y) {
        if (NROW(x) != NROW(y)) {
            print("ERROR: variables of different length")
            return(0)
        }
        else {
            nr <- NROW(x)
            nr1 <- nr - 1
            a <- sum(y[1:nr1] * (x[2:nr] - x[1:nr1]))
            b <- sum(y[2:nr] * (x[2:nr] - x[1:nr1]))
            temp <- (a + b)/2
            return(temp)
        }
    }
    TP <- c(1, z[[1]])
    FP <- c(1, z[[2]])
    AUC = area(FP[NROW(FP):1], TP[NROW(TP):1])
    out <- list(cut.values = c(-Inf, unique.x), TP = c(1, z[[1]]), FP = c(1, z[[2]]),
                predict.time = PredictTime, Survival = z[[3]], AUC = AUC)
    out
}
