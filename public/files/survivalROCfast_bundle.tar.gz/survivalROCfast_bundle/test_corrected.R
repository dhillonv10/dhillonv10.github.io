# Tests of corrected = TRUE against a slow reference written directly from the published definitions.
library(survivalROCfast)
ref <- function(time, status, x, entry = NULL, pt, method, span = NULL, lambda = NULL, window = "symmetric") {
  n <- length(time); if (is.null(entry)) entry <- rep(0, n)
  km <- function(w) { s <- 1; for (t in sort(unique(time[status == 1 & time <= pt]))) { nn <- sum(w * (entry <= t & time >= t)); d <- sum(w * (entry <= t & time == t & status == 1)); if (nn > 0) s <- s * (1 - d / nn) }; s }
  cuts <- sort(unique(x)); Fx <- ecdf(x)
  if (method == "KM") { sp <- km(rep(1, n)); s0 <- sapply(cuts, function(c) km(as.numeric(x > c))); p0 <- sapply(cuts, function(c) mean(x > c)); sens <- (1 - s0) * p0 / (1 - sp); spec <- 1 - s0 * p0 / sp }
  else { S <- sapply(seq_len(n), function(i) km(if (!is.null(span)) { dF <- Fx(x) - Fx(x[i]); as.numeric(if (window == "symmetric") abs(dF) * n < span * n else dF >= 0 & dF * n < span * n) } else exp(-(x - x[i])^2 / lambda^2)))
    Sm <- mean(S); Sx <- sapply(cuts, function(c) sum(S[x > c]) / n); p1 <- sapply(cuts, function(c) mean(x > c)); sens <- (p1 - Sx) / (1 - Sm); spec <- 1 - Sx / Sm }
  sens[length(cuts)] <- 0; spec[length(cuts)] <- 1
  list(TP = c(1, sens), FP = 1 - c(0, spec))
}
set.seed(42); worst <- 0; nfail <- 0; ncase <- 0; inv <- 0
for (it in 1:400) {
  n <- sample(8:90, 1); x <- if (runif(1) < 0.5) rnorm(n) else round(rnorm(n), 1)
  tt <- rexp(n, exp(0.7 * x)); cc <- rexp(n, 0.6); tm <- pmin(tt, cc); st <- as.numeric(tt <= cc); if (runif(1) < 0.4) tm <- ceiling(tm * 5) / 5
  pt <- as.numeric(quantile(tm, runif(1, 0.3, 0.9))); if (sum(st == 1 & tm <= pt) < 1) next
  en <- if (runif(1) < 0.4) tm * runif(n, 0, 0.9) else NULL
  m <- sample(c("KM", "span", "asym", "lambda"), 1)
  args <- switch(m, KM = list(method = "KM"), span = list(method = "NNE", span = runif(1, 0.03, 0.6)), asym = list(method = "NNE", span = runif(1, 0.03, 0.6), window = "asymmetric"), lambda = list(method = "NNE", lambda = runif(1, 0.05, 2)))
  f <- do.call(survivalROC, c(list(Stime = tm, status = st, marker = x, entry = en, predict.time = pt, corrected = TRUE), args))
  r <- do.call(ref, c(list(time = tm, status = st, x = x, entry = en, pt = pt), args))
  mx <- function(a, b) { if (!identical(is.na(a), is.na(b))) return(Inf); if (all(is.na(a))) 0 else max(abs(a - b), na.rm = TRUE) }; dd <- max(mx(f$TP, r$TP), mx(f$FP, r$FP)); ncase <- ncase + 1; worst <- max(worst, dd); if (!is.finite(dd) || dd > 1e-10) { nfail <- nfail + 1; if (nfail <= 3) cat("FAIL", m, "n", n, "diff", dd, "entry", !is.null(en), "\n") }
  p <- sample(n); g <- do.call(survivalROC, c(list(Stime = tm[p], status = st[p], marker = x[p], entry = en[p], predict.time = pt, corrected = TRUE), args))
  inv <- max(inv, mx(g$TP, f$TP), mx(g$FP, f$FP))
  if (m == "span" && is.null(en)) { cr <- survivalROC.C(tm, st, x, pt, span = args$span, corrected = TRUE); if (!identical(cr$TP, f$TP) || !identical(cr$FP, f$FP)) { nfail <- nfail + 1; cat("R/C corrected differ\n") } }
}
cat(sprintf("corrected vs reference: %d cases, %d failures, largest difference %.2e\n", ncase, nfail, worst))
cat(sprintf("row-shuffle invariance (corrected): largest change %.2e\n", inv))
# entry fix agrees with the original whenever the original happens to be right (input already sorted by time)
set.seed(7); okk <- TRUE
for (it in 1:100) { n <- 60; x <- rnorm(n); tt <- rexp(n, exp(x)); cc <- rexp(n, .5); tm <- pmin(tt, cc); st <- as.numeric(tt <= cc); o <- order(tm); tm <- tm[o]; st <- st[o]; x <- x[o]; en <- tm * runif(n, 0, .8)
  a <- survivalROC::survivalROC(tm, st, x, entry = en, predict.time = median(tm), method = "KM"); b <- survivalROC(tm, st, x, entry = en, predict.time = median(tm), method = "KM", corrected = TRUE)
  okk <- okk && isTRUE(all.equal(a$TP, b$TP, tolerance = 1e-12)) && isTRUE(all.equal(a$FP, b$FP, tolerance = 1e-12)) }
cat("KM with entry: corrected equals original on time-sorted input:", okk, "\n")
